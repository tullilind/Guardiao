# 📝 Changelog - Versão 1.2.3

**Data:** 23 de Novembro de 2024

---

## ✅ Correções Implementadas

### 1. **Erro 500 na API de Biometria - CORRIGIDO**

**Problema:** A API `GET /api/verificacao/usuario/:id/biometria` retornava erro 500 porque a coluna `face_token` não existia na tabela `biometria_usuario`.

**Solução:** 
- ✅ Adicionada coluna `face_token TEXT NOT NULL` na tabela `biometria_usuario`
- ✅ Implementada migração automática para bancos existentes
- ✅ Agora a tabela tem todas as colunas necessárias

**Arquivo Modificado:** `src/config/addBiometria.js`

```javascript
// Estrutura corrigida da tabela
CREATE TABLE IF NOT EXISTS biometria_usuario (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  usuario_id INTEGER UNIQUE NOT NULL,
  face_token TEXT NOT NULL,  // ← ADICIONADO
  dados_biometria TEXT NOT NULL,
  data_cadastro DATETIME DEFAULT CURRENT_TIMESTAMP,
  data_atualizacao DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
)

// Migração automática para bancos existentes
ALTER TABLE biometria_usuario ADD COLUMN face_token TEXT
```

---

## 📋 Arquivos Modificados

| Arquivo | Mudanças |
|---------|----------|
| `src/config/addBiometria.js` | Adicionada coluna `face_token` + migração |
| `src/server.js` | Versão atualizada para 1.2.3 |

---

## 🚀 Instruções de Atualização

Se você já tem um banco de dados existente:

1. **Extrair o novo ZIP**
2. **Executar a migração:**
   ```bash
   node src/config/addBiometria.js
   ```
3. **Iniciar o servidor:**
   ```bash
   npm start
   ```

Se for uma instalação nova, a tabela será criada corretamente automaticamente.

---

## ✅ Testes Realizados

- ✅ GET `/api/verificacao/usuario/:id/biometria` sem erro 500
- ✅ POST `/api/verificacao/usuario/:id/biometria` (cadastrar biometria)
- ✅ POST `/api/verificacao/usuario/:id/biometria/autenticar` (autenticar)
- ✅ Migração automática de banco existente

---

## 📊 Histórico de Versões

| Versão | Data | Mudanças Principais |
|--------|------|-------------------|
| 1.2.0 | 23/11/2024 | CORS corrigido |
| 1.2.1 | 23/11/2024 | Upload de documentos corrigido |
| 1.2.2 | 23/11/2024 | Biometria facial ajustada |
| 1.2.3 | 23/11/2024 | Banco de dados corrigido |

---

**Status:** ✅ Pronto para Uso  
**Compatibilidade:** Node.js 14+, Express 4.x+  
**Banco de Dados:** SQLite3

-- Migração: Adicionar campos sexo e endereço completo aos usuários
-- Data: 2025-11-23

-- Adicionar campo sexo à tabela usuarios
ALTER TABLE usuarios ADD COLUMN sexo VARCHAR(20);

-- Adicionar campos de endereço à tabela usuarios
ALTER TABLE usuarios ADD COLUMN rua VARCHAR(255);
ALTER TABLE usuarios ADD COLUMN cidade VARCHAR(100);
ALTER TABLE usuarios ADD COLUMN estado VARCHAR(2);
ALTER TABLE usuarios ADD COLUMN bairro VARCHAR(100);
ALTER TABLE usuarios ADD COLUMN cep VARCHAR(10);

-- Criar índice para busca por cidade
CREATE INDEX IF NOT EXISTS idx_usuarios_cidade ON usuarios(cidade);

-- Criar índice para busca por estado
CREATE INDEX IF NOT EXISTS idx_usuarios_estado ON usuarios(estado);

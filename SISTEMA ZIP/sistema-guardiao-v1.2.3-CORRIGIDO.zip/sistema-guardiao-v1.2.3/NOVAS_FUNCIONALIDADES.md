# 🚀 Novas Funcionalidades Implementadas

## Data: 23 de Novembro de 2025

---

## 📦 1. Sistema de Backup Aprimorado

### ✅ Correções Aplicadas

#### 1.1 Download de Backup com Token de Administrador
- **Problema Resolvido**: Erro "Token de administrador não fornecido" ao fazer download
- **Solução**: A rota `/api/backup/download/:nome_arquivo` agora valida corretamente o token de administrador via middleware `authenticateAdmin`
- **Como usar**: Incluir o token JWT no header `Authorization: Bearer {token}`

#### 1.2 Nova Funcionalidade: Upload e Restauração de Backup
- **Endpoint**: `POST /api/backup/upload-restaurar`
- **Descrição**: Permite fazer upload de um arquivo de backup externo (.db) e restaurá-lo automaticamente
- **Autenticação**: Requer token de administrador
- **Parâmetros**:
  - `backup_file` (multipart/form-data): Arquivo .db do backup
- **Resposta de Sucesso**:
```json
{
  "sucesso": true,
  "mensagem": "Backup importado e restaurado com sucesso",
  "dados": {
    "backup_restaurado": "uploaded_backup_2025-11-23T15-30-00-000Z.db",
    "backup_anterior": "pre_upload_restore_2025-11-23T15-30-00-000Z.db",
    "tamanho_mb": "2.45"
  }
}
```

### 📋 Rotas de Backup Atualizadas

| Método | Endpoint | Descrição | Autenticação |
|--------|----------|-----------|--------------|
| POST | `/api/backup/admin/criar` | Criar primeiro admin | Pública |
| POST | `/api/backup/admin/login` | Login de admin | Pública |
| POST | `/api/backup/criar` | Criar novo backup | Admin |
| GET | `/api/backup/listar` | Listar backups disponíveis | Admin |
| POST | `/api/backup/restaurar` | Restaurar backup existente | Admin |
| **POST** | **`/api/backup/upload-restaurar`** | **Upload e restaurar backup externo** | **Admin** |
| GET | `/api/backup/download/:nome_arquivo` | Download de backup | Admin |
| DELETE | `/api/backup/:nome_arquivo` | Deletar backup | Admin |
| GET | `/api/backup/estatisticas` | Estatísticas do sistema | Admin |

---

## 📧 2. Sistema de Envio de E-mails

### ✅ Integração com API Guardião Mais

**API Base**: `https://script.google.com/macros/s/AKfycbwN8jiiMzm0Win5XRYUqmE11CXEiuoMzeROmYPz8MxcvutXBhGtr-LxjtXB18stlAD_jQ/exec`

### 📨 Eventos que Disparam E-mails

#### 2.1 Cadastro de Novo Usuário
- **Quando**: Ao criar uma nova conta via `POST /api/auth/register`
- **E-mail enviado**: Código de verificação de 6 dígitos
- **Conteúdo**:
  - Mensagem de boas-vindas
  - Código de verificação (válido por 15 minutos)
  - Nome do usuário

#### 2.2 Recuperação de Senha
- **Quando**: Ao solicitar recuperação via `POST /api/auth/recuperar-senha`
- **E-mail enviado**: Código de recuperação de senha
- **Conteúdo**:
  - Código de recuperação de 6 dígitos
  - Validade de 15 minutos
  - Instruções de segurança

#### 2.3 Atualização de Dados Cadastrais
- **Quando**: Ao atualizar dados via `PUT /api/usuarios/:id`
- **E-mail enviado**: Notificação de alteração
- **Conteúdo**:
  - Lista de campos alterados (Nome, E-mail, Celular, Endereço, etc.)
  - Alerta de segurança

### 🛠️ Helper de E-mail

Arquivo: `src/utils/emailHelper.js`

**Funções disponíveis**:
- `enviarEmail(email, mensagem)` - Envio genérico
- `enviarCodigoVerificacao(email, codigo, nomeUsuario)` - Código de cadastro
- `enviarCodigoRecuperacao(email, codigo, nomeUsuario)` - Código de recuperação
- `enviarNotificacaoAtualizacao(email, nomeUsuario, dadosAlterados)` - Notificação de alteração
- `enviarCodigoConfirmacao(email, codigo, nomeUsuario, tipoAlteracao)` - Confirmação de alteração sensível
- `gerarCodigoVerificacao()` - Gera código de 6 dígitos

---

## 🔐 3. Sistema de Reconhecimento Facial com Face++

### ✅ Integração Completa com Face++ API

**Credenciais**:
- **API Key**: `lOHREhzgNbKmjGyEE_-UmVvQnkpTVolo`
- **API Secret**: `yI_Cu6m1m_8C7BQESyvd7VIbUs0yVCUz`
- **Base URL**: `https://api-us.faceplusplus.com/facepp/v3`

### 📸 Funcionalidades Implementadas

#### 3.1 Cadastro de Biometria Facial
- **Endpoint**: `POST /api/verificacao/usuario/:id/biometria`
- **Descrição**: Cadastra a face do usuário usando Face++ API
- **Autenticação**: Token JWT do usuário
- **Parâmetros**:
```json
{
  "foto_base64": "data:image/jpeg;base64,/9j/4AAQSkZJRg..."
}
```
- **Resposta de Sucesso**:
```json
{
  "sucesso": true,
  "mensagem": "Biometria facial cadastrada com sucesso",
  "dados": {
    "id": 1,
    "face_token": "abc123xyz...",
    "face_rectangle": {
      "top": 100,
      "left": 150,
      "width": 200,
      "height": 220
    }
  }
}
```

#### 3.2 Verificar Biometria Cadastrada
- **Endpoint**: `GET /api/verificacao/usuario/:id/biometria`
- **Descrição**: Verifica se o usuário tem biometria facial cadastrada
- **Resposta**:
```json
{
  "sucesso": true,
  "dados": {
    "tem_biometria_facial": true,
    "data_cadastro": "2025-11-23T15:30:00.000Z",
    "data_atualizacao": "2025-11-23T16:45:00.000Z"
  }
}
```

#### 3.3 Autenticar por Reconhecimento Facial
- **Endpoint**: `POST /api/verificacao/usuario/:id/biometria/autenticar`
- **Descrição**: Autentica o usuário comparando a foto enviada com a cadastrada
- **Parâmetros**:
```json
{
  "foto_base64": "data:image/jpeg;base64,/9j/4AAQSkZJRg..."
}
```
- **Resposta de Sucesso**:
```json
{
  "sucesso": true,
  "mensagem": "Autenticação facial bem-sucedida",
  "dados": {
    "autenticado": true,
    "confianca": 85.67,
    "usuario_id": 123
  }
}
```
- **Resposta de Falha**:
```json
{
  "sucesso": false,
  "mensagem": "Face não corresponde ao usuário cadastrado",
  "codigo": 401
}
```

#### 3.4 Comparar Duas Fotos
- **Endpoint**: `POST /api/verificacao/comparar-fotos`
- **Descrição**: Compara duas fotos faciais para verificar se são da mesma pessoa
- **Parâmetros**:
```json
{
  "foto_base64_1": "data:image/jpeg;base64,/9j/4AAQSkZJRg...",
  "foto_base64_2": "data:image/jpeg;base64,/9j/4AAQSkZJRg..."
}
```
- **Resposta**:
```json
{
  "sucesso": true,
  "mensagem": "As faces correspondem à mesma pessoa",
  "dados": {
    "mesma_pessoa": true,
    "confianca": 92.34,
    "thresholds": {
      "1e-3": 62.327,
      "1e-4": 69.101,
      "1e-5": 74.399
    },
    "face1": {
      "face_token": "abc123...",
      "face_rectangle": { "top": 100, "left": 150, "width": 200, "height": 220 }
    },
    "face2": {
      "face_token": "xyz789...",
      "face_rectangle": { "top": 95, "left": 145, "width": 205, "height": 225 }
    }
  }
}
```

#### 3.5 Remover Biometria Facial
- **Endpoint**: `DELETE /api/verificacao/usuario/:id/biometria`
- **Descrição**: Remove a biometria facial cadastrada do usuário

### 🗄️ Banco de Dados

#### Nova Tabela: `biometria_usuario`

```sql
CREATE TABLE biometria_usuario (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  usuario_id INTEGER NOT NULL UNIQUE,
  face_token TEXT NOT NULL,
  dados_biometria TEXT,
  data_cadastro DATETIME DEFAULT CURRENT_TIMESTAMP,
  data_atualizacao DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
);
```

#### Atualização na Tabela: `logs_acesso`

Nova coluna adicionada:
- `tipo_autenticacao VARCHAR(50) DEFAULT 'Senha'`
  - Valores possíveis: 'Senha', 'Biometria Facial'

### 🛠️ Helper Face++

Arquivo: `src/utils/facePlusPlusHelper.js`

**Funções disponíveis**:
- `detectarFace(imagemBuffer)` - Detecta face em uma imagem e retorna face_token
- `compararFaces(faceToken1, faceToken2)` - Compara dois face_tokens
- `cadastrarFaceInicial(imagemBuffer)` - Cadastra face inicial do usuário
- `autenticarPorFace(faceTokenCadastrado, novaImagem)` - Autentica usuário por face

### 📊 Limiar de Confiança

- **Confiança mínima para autenticação**: 70%
- Valores acima de 70% indicam que as faces correspondem à mesma pessoa
- Valores abaixo de 70% indicam que são pessoas diferentes

---

## 📋 Resumo das Rotas Novas/Atualizadas

### Backup
- ✅ `POST /api/backup/upload-restaurar` - Upload e restaurar backup externo

### Reconhecimento Facial
- ✅ `POST /api/verificacao/usuario/:id/biometria` - Cadastrar biometria facial
- ✅ `GET /api/verificacao/usuario/:id/biometria` - Verificar biometria cadastrada
- ✅ `POST /api/verificacao/usuario/:id/biometria/autenticar` - Autenticar por face
- ✅ `POST /api/verificacao/comparar-fotos` - Comparar duas fotos
- ✅ `DELETE /api/verificacao/usuario/:id/biometria` - Remover biometria

---

## 🔧 Dependências Adicionadas

```json
{
  "axios": "^1.7.9",
  "form-data": "^4.0.1"
}
```

---

## 📝 Notas Importantes

### Envio de E-mails
- Os e-mails são enviados de forma **assíncrona** e **não bloqueante**
- Se o envio falhar, o sistema registra o erro mas **não interrompe** a operação principal
- Logs são gerados para monitoramento: ✅ sucesso ou ⚠️ erro

### Reconhecimento Facial
- Imagens devem estar em formato **base64** com prefixo `data:image/...`
- Formatos suportados: JPEG, PNG, WebP
- Tamanho máximo recomendado: 5MB
- A API Face++ detecta automaticamente a face na imagem
- Se múltiplas faces forem detectadas, apenas a primeira é utilizada

### Backup
- Backups podem ter até **100MB** de tamanho
- Antes de restaurar, o sistema cria automaticamente um backup de segurança
- Arquivos de backup são armazenados em `database/backups/`

---

## 🚀 Como Testar

### 1. Testar Envio de E-mail
```bash
# Registrar novo usuário (dispara e-mail de boas-vindas)
curl -X POST http://localhost:3000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "nome_completo": "João Silva",
    "email": "joao@exemplo.com",
    "celular": "11999999999",
    "senha": "senha123",
    "cpf_cnpj": "12345678901",
    "sexo": "Masculino"
  }'
```

### 2. Testar Reconhecimento Facial
```bash
# 1. Cadastrar biometria facial
curl -X POST http://localhost:3000/api/verificacao/usuario/1/biometria \
  -H "Authorization: Bearer {seu_token}" \
  -H "Content-Type: application/json" \
  -d '{
    "foto_base64": "data:image/jpeg;base64,/9j/4AAQ..."
  }'

# 2. Autenticar por face
curl -X POST http://localhost:3000/api/verificacao/usuario/1/biometria/autenticar \
  -H "Authorization: Bearer {seu_token}" \
  -H "Content-Type: application/json" \
  -d '{
    "foto_base64": "data:image/jpeg;base64,/9j/4AAQ..."
  }'
```

### 3. Testar Upload de Backup
```bash
# Upload e restaurar backup
curl -X POST http://localhost:3000/api/backup/upload-restaurar \
  -H "Authorization: Bearer {admin_token}" \
  -F "backup_file=@/caminho/para/backup.db"
```

---

## ✅ Checklist de Implementação

- [x] Sistema de backup com upload e restauração
- [x] Correção do download de backup com token
- [x] Integração com API de e-mail Guardião Mais
- [x] Envio de e-mail no cadastro de usuário
- [x] Envio de e-mail na recuperação de senha
- [x] Envio de e-mail na atualização de dados
- [x] Integração completa com Face++ API
- [x] Cadastro de biometria facial
- [x] Verificação de biometria cadastrada
- [x] Autenticação por reconhecimento facial
- [x] Comparação de duas fotos
- [x] Remoção de biometria facial
- [x] Criação da tabela `biometria_usuario`
- [x] Atualização da tabela `logs_acesso`
- [x] Instalação de dependências (axios, form-data)
- [x] Documentação completa

---

## 📞 Suporte

Para dúvidas ou problemas, consulte:
- `API_COMPLETA.md` - Documentação completa de todas as APIs
- `README.md` - Instruções de instalação e uso
- Logs do sistema em tempo real

---

**Desenvolvido com ❤️ para o Sistema Guardião Mais**

/**
 * Utilitário para respostas padronizadas da API
 */

class ResponseHandler {
  /**
   * Resposta de sucesso
   */
  static success(res, data = null, message = 'Operação realizada com sucesso', statusCode = 200) {
    return res.status(statusCode).json({
      success: true,
      message,
      data,
      timestamp: new Date().toISOString()
    });
  }

  /**
   * Resposta de erro
   */
  static error(res, message = 'Erro ao processar requisição', statusCode = 500, errors = null) {
    return res.status(statusCode).json({
      success: false,
      message,
      errors,
      timestamp: new Date().toISOString()
    });
  }

  /**
   * Resposta de validação (erro 400)
   */
  static validationError(res, errors) {
    return res.status(400).json({
      success: false,
      message: 'Erro de validação',
      errors,
      timestamp: new Date().toISOString()
    });
  }

  /**
   * Resposta de não autorizado (erro 401)
   */
  static unauthorized(res, message = 'Não autorizado') {
    return res.status(401).json({
      success: false,
      message,
      timestamp: new Date().toISOString()
    });
  }

  /**
   * Resposta de proibido (erro 403)
   */
  static forbidden(res, message = 'Acesso negado') {
    return res.status(403).json({
      success: false,
      message,
      timestamp: new Date().toISOString()
    });
  }

  /**
   * Resposta de não encontrado (erro 404)
   */
  static notFound(res, message = 'Recurso não encontrado') {
    return res.status(404).json({
      success: false,
      message,
      timestamp: new Date().toISOString()
    });
  }

  /**
   * Resposta de conflito (erro 409)
   */
  static conflict(res, message = 'Conflito de dados') {
    return res.status(409).json({
      success: false,
      message,
      timestamp: new Date().toISOString()
    });
  }

  /**
   * Resposta de criação bem-sucedida (201)
   */
  static created(res, data = null, message = 'Recurso criado com sucesso') {
    return res.status(201).json({
      success: true,
      message,
      data,
      timestamp: new Date().toISOString()
    });
  }
}

module.exports = ResponseHandler;

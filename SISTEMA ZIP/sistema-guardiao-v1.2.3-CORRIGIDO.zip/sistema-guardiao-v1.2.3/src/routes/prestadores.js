const express = require('express');
const router = express.Router();
const prestadorController = require('../controllers/prestadorController');
const { authenticateToken } = require('../middlewares/auth');

// Todas as rotas requerem autenticação
router.use(authenticateToken);

// Rotas específicas ANTES das rotas parametrizadas
router.get('/verificados', prestadorController.listarVerificados);
router.get('/buscar', prestadorController.buscar);

// Rotas parametrizadas
router.get('/', prestadorController.listar);
router.get('/:id', prestadorController.obterPorId);
router.get('/:id/servicos', prestadorController.listarServicos);
router.get('/:id/estatisticas', prestadorController.obterEstatisticas);

module.exports = router;

const express = require('express');
const router = express.Router();
const contratacaoController = require('../controllers/contratacaoController');
const { authenticateToken } = require('../middlewares/auth');

// Todas as rotas requerem autenticação
router.use(authenticateToken);

// Rotas específicas ANTES das rotas parametrizadas
router.post('/', contratacaoController.criar);
router.get('/', contratacaoController.listar);

// Rotas parametrizadas (mais específicas primeiro)
router.put('/:id/status-servico', contratacaoController.atualizarStatusServico);
router.put('/:id/status-pagamento', contratacaoController.atualizarStatusPagamento);
router.get('/prestador/:id_prestador', contratacaoController.listarPorPrestador);
router.get('/solicitante/:id_solicitante', contratacaoController.listarPorSolicitante);
router.get('/:id', contratacaoController.obterPorId);
router.put('/:id', contratacaoController.atualizar);

module.exports = router;

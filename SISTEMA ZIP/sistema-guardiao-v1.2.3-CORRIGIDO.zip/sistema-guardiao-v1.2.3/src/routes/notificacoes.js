const express = require('express');
const router = express.Router();
const notificacaoController = require('../controllers/notificacaoController');
const { authenticateToken } = require('../middlewares/auth');

// Todas as rotas requerem autenticação
router.use(authenticateToken);

// Rotas específicas ANTES das rotas parametrizadas
router.get('/nao-lidas', notificacaoController.listarNaoLidas);
router.get('/contagem', notificacaoController.obterContagem);
router.put('/marcar-todas-lidas', notificacaoController.marcarTodasComoLidas);
router.delete('/lidas/limpar', notificacaoController.deletarLidas);

// Rotas parametrizadas
router.post('/', notificacaoController.criar);
router.get('/usuario/:usuario_id', notificacaoController.listarPorUsuario);
router.put('/:id/marcar-lida', notificacaoController.marcarComoLida);
router.delete('/:id', notificacaoController.deletar);

module.exports = router;

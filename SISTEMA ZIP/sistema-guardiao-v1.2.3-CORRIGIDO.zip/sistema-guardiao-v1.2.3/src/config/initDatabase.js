const database = require('./database');

async function initDatabase() {
  try {
    await database.connect();
    console.log('Iniciando criação das tabelas...\n');

    // 1. Tabela usuarios (Mestra)
    await database.run(`
      CREATE TABLE IF NOT EXISTS usuarios (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nome_completo VARCHAR(255) NOT NULL,
        email VARCHAR(255) UNIQUE NOT NULL,
        celular VARCHAR(20) UNIQUE NOT NULL,
        senha_hash VARCHAR(255) NOT NULL,
        cpf_cnpj VARCHAR(18) UNIQUE NOT NULL,
        tipo_acesso VARCHAR(50) DEFAULT 'usuario',
        sexo VARCHAR(20),
        rua VARCHAR(255),
        cidade VARCHAR(100),
        estado VARCHAR(2),
        bairro VARCHAR(100),
        cep VARCHAR(10),
        latitude DECIMAL(10,8),
        longitude DECIMAL(11,8),
        guardiao_token VARCHAR(500),
        perfil_verificado BOOLEAN DEFAULT 0,
        media_avaliacao DECIMAL(3,2) DEFAULT 0.00,
        foto_perfil_id INTEGER,
        data_cadastro DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (foto_perfil_id) REFERENCES midia_usuarios(id)
      )
    `);
    console.log('✓ Tabela usuarios criada');

    // 2. Tabela logs_acesso (Auditoria)
    await database.run(`
      CREATE TABLE IF NOT EXISTS logs_acesso (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        usuario_id INTEGER NOT NULL,
        ip_origem VARCHAR(50),
        dispositivo TEXT,
        status_login VARCHAR(20) NOT NULL,
        data_hora DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
      )
    `);
    console.log('✓ Tabela logs_acesso criada');

    // 3. Tabela midia_usuarios (Banco de Fotos, PDFs e Arquivos)
    await database.run(`
      CREATE TABLE IF NOT EXISTS midia_usuarios (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        usuario_id INTEGER NOT NULL,
        tipo_midia VARCHAR(50) NOT NULL,
        nome_arquivo VARCHAR(255) NOT NULL,
        conteudo_blob BLOB NOT NULL,
        mime_type VARCHAR(100) NOT NULL,
        tamanho_kb DECIMAL(10,2) NOT NULL,
        latitude DECIMAL(10,8),
        longitude DECIMAL(11,8),
        endereco_completo TEXT,
        data_upload DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
      )
    `);
    console.log('✓ Tabela midia_usuarios criada');

    // 3.1. Tabela arquivos_sistema (O Cofre - Mantida para compatibilidade)
    await database.run(`
      CREATE TABLE IF NOT EXISTS arquivos_sistema (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        usuario_id INTEGER NOT NULL,
        conteudo_blob BLOB NOT NULL,
        mime_type VARCHAR(100) NOT NULL,
        tamanho_kb DECIMAL(10,2) NOT NULL,
        data_upload DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
      )
    `);
    console.log('✓ Tabela arquivos_sistema criada');

    // 4. Tabela documentos_validacao (Verificação)
    await database.run(`
      CREATE TABLE IF NOT EXISTS documentos_validacao (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        usuario_id INTEGER NOT NULL,
        arquivo_id INTEGER NOT NULL,
        tipo_documento VARCHAR(50) NOT NULL,
        status VARCHAR(20) DEFAULT 'Pendente',
        motivo_rejeicao TEXT,
        data_envio DATETIME DEFAULT CURRENT_TIMESTAMP,
        data_validacao DATETIME,
        FOREIGN KEY (usuario_id) REFERENCES usuarios(id),
        FOREIGN KEY (arquivo_id) REFERENCES midia_usuarios(id)
      )
    `);
    console.log('✓ Tabela documentos_validacao criada');

    // 5. Tabela contratacoes_servico (A O.S.)
    await database.run(`
      CREATE TABLE IF NOT EXISTS contratacoes_servico (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        id_prestador INTEGER NOT NULL,
        id_solicitante INTEGER NOT NULL,
        servico_nome VARCHAR(255) NOT NULL,
        servico_descricao TEXT,
        valor_acordado DECIMAL(10,2) NOT NULL,
        status_pagamento VARCHAR(20) DEFAULT 'Pendente',
        status_servico VARCHAR(30) DEFAULT 'Agendado',
        data_contrato DATETIME DEFAULT CURRENT_TIMESTAMP,
        data_conclusao DATETIME,
        FOREIGN KEY (id_prestador) REFERENCES usuarios(id),
        FOREIGN KEY (id_solicitante) REFERENCES usuarios(id)
      )
    `);
    console.log('✓ Tabela contratacoes_servico criada');

    // 6. Tabela registro_ponto_os (O Relógio)
    await database.run(`
      CREATE TABLE IF NOT EXISTS registro_ponto_os (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        contratacao_id INTEGER NOT NULL,
        tipo_registro VARCHAR(10) NOT NULL,
        latitude VARCHAR(50),
        longitude VARCHAR(50),
        data_hora DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (contratacao_id) REFERENCES contratacoes_servico(id)
      )
    `);
    console.log('✓ Tabela registro_ponto_os criada');

    // 7. Tabela notificacoes_usuario (O Alerta)
    await database.run(`
      CREATE TABLE IF NOT EXISTS notificacoes_usuario (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        usuario_id INTEGER NOT NULL,
        mensagem TEXT NOT NULL,
        lida BOOLEAN DEFAULT 0,
        link_acao VARCHAR(255),
        data_criacao DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
      )
    `);
    console.log('✓ Tabela notificacoes_usuario criada');

    // 8. Tabela avaliacoes_servico (O Feedback)
    await database.run(`
      CREATE TABLE IF NOT EXISTS avaliacoes_servico (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        contratacao_id INTEGER NOT NULL,
        id_avaliador INTEGER NOT NULL,
        id_avaliado INTEGER NOT NULL,
        nota_estrelas INTEGER NOT NULL CHECK(nota_estrelas >= 1 AND nota_estrelas <= 5),
        comentario TEXT,
        data_avaliacao DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (contratacao_id) REFERENCES contratacoes_servico(id),
        FOREIGN KEY (id_avaliador) REFERENCES usuarios(id),
        FOREIGN KEY (id_avaliado) REFERENCES usuarios(id)
      )
    `);
    console.log('✓ Tabela avaliacoes_servico criada');

    // 9. Tabela admin_backup (Para módulo de backup)
    await database.run(`
      CREATE TABLE IF NOT EXISTS admin_backup (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nome_usuario VARCHAR(100) UNIQUE NOT NULL,
        senha_hash VARCHAR(255) NOT NULL,
        data_criacao DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `);
    console.log('✓ Tabela admin_backup criada');

    // 10. Tabela historico_localizacao (Rastreamento de localização)
    await database.run(`
      CREATE TABLE IF NOT EXISTS historico_localizacao (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        usuario_id INTEGER NOT NULL,
        latitude DECIMAL(10,8) NOT NULL,
        longitude DECIMAL(11,8) NOT NULL,
        endereco_completo TEXT,
        precisao DECIMAL(10,2),
        data_hora DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
      )
    `);
    console.log('✓ Tabela historico_localizacao criada');

    // 11. Tabela compartilhamento_localizacao (Compartilhamento em tempo real)
    await database.run(`
      CREATE TABLE IF NOT EXISTS compartilhamento_localizacao (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        usuario_origem INTEGER NOT NULL,
        usuario_destino INTEGER NOT NULL,
        duracao_minutos INTEGER DEFAULT 60,
        data_inicio DATETIME DEFAULT CURRENT_TIMESTAMP,
        data_fim DATETIME,
        ativo BOOLEAN DEFAULT 1,
        FOREIGN KEY (usuario_origem) REFERENCES usuarios(id),
        FOREIGN KEY (usuario_destino) REFERENCES usuarios(id)
      )
    `);
    console.log('✓ Tabela compartilhamento_localizacao criada');

    // 12. Tabela assinaturas_digitais (Assinatura digital de documentos)
    await database.run(`
      CREATE TABLE IF NOT EXISTS assinaturas_digitais (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        arquivo_id INTEGER NOT NULL,
        usuario_id INTEGER NOT NULL,
        assinatura_hash VARCHAR(255) NOT NULL,
        data_assinatura DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (arquivo_id) REFERENCES midia_usuarios(id),
        FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
      )
    `);
    console.log('✓ Tabela assinaturas_digitais criada');

    // Criar índices para melhorar performance
    try {
      await database.run('CREATE INDEX IF NOT EXISTS idx_usuarios_cpf ON usuarios(cpf_cnpj)');
      await database.run('CREATE INDEX IF NOT EXISTS idx_usuarios_email ON usuarios(email)');
      await database.run('CREATE INDEX IF NOT EXISTS idx_midia_usuario ON midia_usuarios(usuario_id)');
      await database.run('CREATE INDEX IF NOT EXISTS idx_midia_tipo ON midia_usuarios(tipo_midia)');
      await database.run('CREATE INDEX IF NOT EXISTS idx_documentos_usuario ON documentos_validacao(usuario_id)');
      await database.run('CREATE INDEX IF NOT EXISTS idx_documentos_status ON documentos_validacao(status)');
      await database.run('CREATE INDEX IF NOT EXISTS idx_contratacoes_prestador ON contratacoes_servico(id_prestador)');
      await database.run('CREATE INDEX IF NOT EXISTS idx_contratacoes_solicitante ON contratacoes_servico(id_solicitante)');
      await database.run('CREATE INDEX IF NOT EXISTS idx_contratacoes_status ON contratacoes_servico(status_servico)');
      await database.run('CREATE INDEX IF NOT EXISTS idx_avaliacoes_avaliado ON avaliacoes_servico(id_avaliado)');
      await database.run('CREATE INDEX IF NOT EXISTS idx_notificacoes_usuario ON notificacoes_usuario(usuario_id)');
      await database.run('CREATE INDEX IF NOT EXISTS idx_historico_usuario ON historico_localizacao(usuario_id)');
      await database.run('CREATE INDEX IF NOT EXISTS idx_compartilhamento_origem ON compartilhamento_localizacao(usuario_origem)');
      await database.run('CREATE INDEX IF NOT EXISTS idx_assinaturas_arquivo ON assinaturas_digitais(arquivo_id)');
    } catch (indexErr) {
      console.warn('⚠ Aviso ao criar índices:', indexErr.message);
    }
    console.log('✓ Índices criados');

    console.log('\n✅ Banco de dados inicializado com sucesso!');
    
  } catch (error) {
    console.error('❌ Erro ao inicializar banco de dados:', error);
  } finally {
    await database.close();
  }
}

// Executar se chamado diretamente
if (require.main === module) {
  initDatabase();
}

module.exports = initDatabase;

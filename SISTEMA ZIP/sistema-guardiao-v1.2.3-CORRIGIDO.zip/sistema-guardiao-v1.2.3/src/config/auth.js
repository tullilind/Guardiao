require('dotenv').config();

module.exports = {
  jwtSecret: process.env.JWT_SECRET || '1526105',
  jwtExpiresIn: process.env.JWT_EXPIRES_IN || '7d',
  jwtTempExpiresIn: '1h', // Token temporário para recuperação de senha expira em 1 hora
};

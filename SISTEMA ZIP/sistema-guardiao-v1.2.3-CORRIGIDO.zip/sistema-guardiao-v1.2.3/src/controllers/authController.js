const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const database = require('../config/database');
const { jwtSecret, jwtExpiresIn, jwtTempExpiresIn } = require('../config/auth');
const ResponseHandler = require('../utils/responseHandler');
const { validarCPFouCNPJ, validarEmail, validarTelefone } = require('../utils/validators');
const { enviarCodigoVerificacao, enviarCodigoRecuperacao, gerarCodigoVerificacao } = require('../utils/emailHelper');

/**
 * Registrar novo usuário COM UPLOAD DE FOTO
 */
async function register(req, res) {
  try {
    const { 
      nome_completo, 
      email, 
      celular, 
      senha, 
      cpf_cnpj, 
      tipo_acesso,
      sexo,
      rua,
      cidade,
      estado,
      bairro,
      cep,
      latitude,
      longitude,
      foto_base64
    } = req.body;

    // Validações
    if (!nome_completo || !email || !celular || !senha || !cpf_cnpj || !sexo) {
      return ResponseHandler.validationError(res, ['Nome, email, celular, senha, CPF/CNPJ e sexo são obrigatórios']);
    }

    // Validar sexo
    const sexosValidos = ['Masculino', 'Feminino', 'Outro'];
    if (!sexosValidos.includes(sexo)) {
      return ResponseHandler.validationError(res, ['Sexo deve ser: Masculino, Feminino ou Outro']);
    }

    if (!validarEmail(email)) {
      return ResponseHandler.validationError(res, ['Email inválido']);
    }

    if (!validarTelefone(celular)) {
      return ResponseHandler.validationError(res, ['Telefone inválido']);
    }

    if (!validarCPFouCNPJ(cpf_cnpj)) {
      return ResponseHandler.validationError(res, ['CPF/CNPJ inválido']);
    }

    if (senha.length < 6) {
      return ResponseHandler.validationError(res, ['Senha deve ter no mínimo 6 caracteres']);
    }

    // Verificar se CPF já existe
    const cpfExiste = await database.get(
      'SELECT id FROM usuarios WHERE cpf_cnpj = ?',
      [cpf_cnpj.replace(/[^\d]/g, '')]
    );

    if (cpfExiste) {
      return ResponseHandler.conflict(res, 'CPF/CNPJ já cadastrado no sistema');
    }

    // Verificar se email já existe
    const emailExiste = await database.get(
      'SELECT id FROM usuarios WHERE email = ?',
      [email.toLowerCase()]
    );

    if (emailExiste) {
      return ResponseHandler.conflict(res, 'Email já cadastrado no sistema');
    }

    // Verificar se telefone já existe
    const telefoneExiste = await database.get(
      'SELECT id FROM usuarios WHERE celular = ?',
      [celular.replace(/[^\d]/g, '')]
    );

    if (telefoneExiste) {
      return ResponseHandler.conflict(res, 'Telefone já cadastrado no sistema');
    }

    // Hash da senha
    const senhaHash = await bcrypt.hash(senha, 10);

    // Processar upload de foto se fornecida
    let fotoPerfilId = null;
    if (foto_base64) {
      try {
        // Extrair dados do base64
        const matches = foto_base64.match(/^data:(.+);base64,(.+)$/);
        if (!matches) {
          return ResponseHandler.validationError(res, ['Formato de imagem inválido. Use base64 com prefixo data:image/...']);
        }

        const mimeType = matches[1];
        const base64Data = matches[2];
        const buffer = Buffer.from(base64Data, 'base64');
        const tamanhoKb = buffer.length / 1024;

        // Validar tamanho (máximo 5MB)
        if (tamanhoKb > 5120) {
          return ResponseHandler.validationError(res, ['Imagem muito grande. Tamanho máximo: 5MB']);
        }

        // Validar tipo de arquivo
        const tiposPermitidos = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];
        if (!tiposPermitidos.includes(mimeType)) {
          return ResponseHandler.validationError(res, ['Tipo de imagem não permitido. Use: JPEG, PNG ou WebP']);
        }

        // Salvar foto no banco (será feito após criar o usuário)
      } catch (err) {
        return ResponseHandler.validationError(res, ['Erro ao processar imagem']);
      }
    }

    // Inserir usuário COM LATITUDE E LONGITUDE
    const tipoAcessoValido = tipo_acesso || 'usuario';
    const result = await database.run(
      `INSERT INTO usuarios (nome_completo, email, celular, senha_hash, cpf_cnpj, tipo_acesso, sexo, rua, cidade, estado, bairro, cep, latitude, longitude)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        nome_completo,
        email.toLowerCase(),
        celular.replace(/[^\d]/g, ''),
        senhaHash,
        cpf_cnpj.replace(/[^\d]/g, ''),
        tipoAcessoValido,
        sexo,
        rua || null,
        cidade || null,
        estado || null,
        bairro || null,
        cep ? cep.replace(/[^\d]/g, '') : null,
        latitude || null,
        longitude || null
      ]
    );

    // Salvar foto se fornecida - NA TABELA midia_usuarios
    if (foto_base64 && result.id) {
      const matches = foto_base64.match(/^data:(.+);base64,(.+)$/);
      const mimeType = matches[1];
      const base64Data = matches[2];
      const buffer = Buffer.from(base64Data, 'base64');
      const tamanhoKb = buffer.length / 1024;

      const fotoResult = await database.run(
        `INSERT INTO midia_usuarios (usuario_id, tipo_midia, nome_arquivo, conteudo_blob, mime_type, tamanho_kb, latitude, longitude, endereco_completo)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          result.id, 
          'foto_perfil', 
          `foto_${result.id}_${Date.now()}`,
          buffer, 
          mimeType, 
          tamanhoKb,
          latitude || null,
          longitude || null,
          `${rua || ''}, ${cidade || ''}, ${estado || ''}`
        ]
      );

      fotoPerfilId = fotoResult.id;

      // Atualizar referência da foto no usuário
      await database.run(
        'UPDATE usuarios SET foto_perfil_id = ? WHERE id = ?',
        [fotoPerfilId, result.id]
      );
    }

    // Gerar token JWT
    const token = jwt.sign(
      { userId: result.id },
      jwtSecret,
      { expiresIn: jwtExpiresIn }
    );

    // Salvar guardiao_token
    await database.run(
      'UPDATE usuarios SET guardiao_token = ? WHERE id = ?',
      [token, result.id]
    );

    // Registrar log de acesso
    await database.run(
      `INSERT INTO logs_acesso (usuario_id, ip_origem, dispositivo, status_login)
       VALUES (?, ?, ?, ?)`,
      [result.id, req.ip, req.get('user-agent'), 'Sucesso']
    );

    // Enviar e-mail de boas-vindas com código de verificação
    const codigoVerificacao = gerarCodigoVerificacao();
    try {
      await enviarCodigoVerificacao(email.toLowerCase(), codigoVerificacao, nome_completo);
      console.log(`✅ E-mail de boas-vindas enviado para ${email}`);
    } catch (emailError) {
      console.error('⚠️ Erro ao enviar e-mail de boas-vindas:', emailError);
      // Não bloquear cadastro se e-mail falhar
    }

    return ResponseHandler.created(res, {
      usuario: {
        id: result.id,
        nome_completo,
        email: email.toLowerCase(),
        cpf_cnpj,
        sexo,
        endereco: {
          rua: rua || null,
          cidade: cidade || null,
          estado: estado || null,
          bairro: bairro || null,
          cep: cep || null
        },
        localizacao: {
          latitude: latitude || null,
          longitude: longitude || null
        },
        foto_perfil_id: fotoPerfilId
      },
      token
    }, 'Usuário cadastrado com sucesso');

  } catch (error) {
    console.error('Erro ao registrar usuário:', error);
    return ResponseHandler.serverError(res, 'Erro ao registrar usuário');
  }
}

/**
 * Login COM RETORNO DE FOTO E LOCALIZAÇÃO
 */
async function login(req, res) {
  try {
    const { cpf_cnpj, senha } = req.body;

    if (!cpf_cnpj || !senha) {
      return ResponseHandler.validationError(res, ['CPF/CNPJ e senha são obrigatórios']);
    }

    // Buscar usuário
    const usuario = await database.get(
      `SELECT * FROM usuarios WHERE cpf_cnpj = ?`,
      [cpf_cnpj.replace(/[^\d]/g, '')]
    );

    if (!usuario) {
      return ResponseHandler.unauthorized(res, 'CPF/CNPJ ou senha incorretos');
    }

    // Verificar senha
    const senhaValida = await bcrypt.compare(senha, usuario.senha_hash);
    if (!senhaValida) {
      return ResponseHandler.unauthorized(res, 'CPF/CNPJ ou senha incorretos');
    }

    // Buscar foto do usuário
    let fotoData = null;
    if (usuario.foto_perfil_id) {
      fotoData = await database.get(
        `SELECT id, conteudo_blob, mime_type, tipo_midia FROM midia_usuarios WHERE id = ?`,
        [usuario.foto_perfil_id]
      );
    }

    // Gerar token JWT
    const token = jwt.sign(
      { userId: usuario.id },
      jwtSecret,
      { expiresIn: jwtExpiresIn }
    );

    // Salvar guardiao_token
    await database.run(
      'UPDATE usuarios SET guardiao_token = ? WHERE id = ?',
      [token, usuario.id]
    );

    // Registrar log de acesso
    await database.run(
      `INSERT INTO logs_acesso (usuario_id, ip_origem, dispositivo, status_login)
       VALUES (?, ?, ?, ?)`,
      [usuario.id, req.ip, req.get('user-agent'), 'Sucesso']
    );

    // Preparar resposta com foto em base64
    let fotoBase64 = null;
    if (fotoData && fotoData.conteudo_blob) {
      const buffer = Buffer.from(fotoData.conteudo_blob);
      fotoBase64 = `data:${fotoData.mime_type};base64,${buffer.toString('base64')}`;
    }

    return ResponseHandler.success(res, {
      usuario: {
        id: usuario.id,
        nome_completo: usuario.nome_completo,
        email: usuario.email,
        cpf_cnpj: usuario.cpf_cnpj,
        tipo_acesso: usuario.tipo_acesso,
        sexo: usuario.sexo,
        perfil_verificado: usuario.perfil_verificado,
        media_avaliacao: usuario.media_avaliacao,
        endereco: {
          rua: usuario.rua,
          cidade: usuario.cidade,
          estado: usuario.estado,
          bairro: usuario.bairro,
          cep: usuario.cep
        },
        localizacao: {
          latitude: usuario.latitude,
          longitude: usuario.longitude
        },
        foto_perfil: fotoBase64,
        foto_perfil_id: usuario.foto_perfil_id
      },
      token
    }, 'Login realizado com sucesso');

  } catch (error) {
    console.error('Erro ao fazer login:', error);
    return ResponseHandler.serverError(res, 'Erro ao fazer login');
  }
}

/**
 * Obter dados do usuário logado COM FOTO
 */
async function getMe(req, res) {
  try {
    const userId = req.userId;

    const usuario = await database.get(
      `SELECT * FROM usuarios WHERE id = ?`,
      [userId]
    );

    if (!usuario) {
      return ResponseHandler.notFound(res, 'Usuário não encontrado');
    }

    // Buscar foto do usuário
    let fotoBase64 = null;
    if (usuario.foto_perfil_id) {
      const fotoData = await database.get(
        `SELECT conteudo_blob, mime_type FROM midia_usuarios WHERE id = ?`,
        [usuario.foto_perfil_id]
      );

      if (fotoData && fotoData.conteudo_blob) {
        const buffer = Buffer.from(fotoData.conteudo_blob);
        fotoBase64 = `data:${fotoData.mime_type};base64,${buffer.toString('base64')}`;
      }
    }

    return ResponseHandler.success(res, {
      id: usuario.id,
      nome_completo: usuario.nome_completo,
      email: usuario.email,
      celular: usuario.celular,
      cpf_cnpj: usuario.cpf_cnpj,
      tipo_acesso: usuario.tipo_acesso,
      sexo: usuario.sexo,
      endereco: {
        rua: usuario.rua,
        cidade: usuario.cidade,
        estado: usuario.estado,
        bairro: usuario.bairro,
        cep: usuario.cep
      },
      localizacao: {
        latitude: usuario.latitude,
        longitude: usuario.longitude
      },
      perfil_verificado: usuario.perfil_verificado,
      media_avaliacao: usuario.media_avaliacao,
      foto_perfil: fotoBase64,
      foto_perfil_id: usuario.foto_perfil_id,
      data_cadastro: usuario.data_cadastro
    }, 'Dados do usuário obtidos com sucesso');

  } catch (error) {
    console.error('Erro ao obter dados do usuário:', error);
    return ResponseHandler.serverError(res, 'Erro ao obter dados do usuário');
  }
}

/**
 * Recuperar Senha
 */
async function recuperarSenha(req, res) {
  try {
    const { nome_completo } = req.body;

    if (!nome_completo) {
      return ResponseHandler.validationError(res, ['Nome completo é obrigatório']);
    }

    const usuario = await database.get(
      'SELECT id, nome_completo, email FROM usuarios WHERE nome_completo = ? LIMIT 1',
      [nome_completo]
    );

    if (!usuario) {
      return ResponseHandler.notFound(res, 'Usuário não encontrado');
    }

    // Gerar token temporário e código de recuperação
    const tokenRecuperacao = jwt.sign(
      { userId: usuario.id, tipo: 'recuperacao' },
      jwtSecret,
      { expiresIn: jwtTempExpiresIn }
    );

    const codigoRecuperacao = gerarCodigoVerificacao();
    
    // Enviar e-mail com código de recuperação
    try {
      await enviarCodigoRecuperacao(usuario.email, codigoRecuperacao, usuario.nome_completo);
      console.log(`✅ E-mail de recuperação enviado para ${usuario.email}`);
    } catch (emailError) {
      console.error('⚠️ Erro ao enviar e-mail de recuperação:', emailError);
      // Continuar mesmo se e-mail falhar
    }

    return ResponseHandler.success(res, {
      token_recuperacao: tokenRecuperacao,
      usuario: {
        id: usuario.id,
        nome_completo: usuario.nome_completo,
        email: usuario.email.replace(/(.{2})(.*)(@.*)/, '$1***$3')
      }
    }, 'Token de recuperação gerado com sucesso. Use-o para redefinir sua senha');

  } catch (error) {
    console.error('Erro ao recuperar senha:', error);
    return ResponseHandler.serverError(res, 'Erro ao recuperar senha');
  }
}

/**
 * Redefinir Senha
 */
async function redefinirSenha(req, res) {
  try {
    const { token_recuperacao, nova_senha } = req.body;

    if (!token_recuperacao || !nova_senha) {
      return ResponseHandler.validationError(res, ['Token e nova senha são obrigatórios']);
    }

    if (nova_senha.length < 6) {
      return ResponseHandler.validationError(res, ['Senha deve ter no mínimo 6 caracteres']);
    }

    // Verificar token
    let decoded;
    try {
      decoded = jwt.verify(token_recuperacao, jwtSecret);
    } catch (err) {
      return ResponseHandler.unauthorized(res, 'Token inválido ou expirado');
    }

    if (decoded.tipo !== 'recuperacao') {
      return ResponseHandler.unauthorized(res, 'Token inválido');
    }

    // Hash da nova senha
    const senhaHash = await bcrypt.hash(nova_senha, 10);

    // Atualizar senha
    await database.run(
      'UPDATE usuarios SET senha_hash = ? WHERE id = ?',
      [senhaHash, decoded.userId]
    );

    // Gerar novo token de login
    const token = jwt.sign(
      { userId: decoded.userId },
      jwtSecret,
      { expiresIn: jwtExpiresIn }
    );

    return ResponseHandler.success(res, {
      token
    }, 'Senha redefinida com sucesso');

  } catch (error) {
    console.error('Erro ao redefinir senha:', error);
    return ResponseHandler.serverError(res, 'Erro ao redefinir senha');
  }
}

/**
 * Logout
 */
async function logout(req, res) {
  try {
    const userId = req.userId;

    await database.run(
      'UPDATE usuarios SET guardiao_token = NULL WHERE id = ?',
      [userId]
    );

    return ResponseHandler.success(res, null, 'Logout realizado com sucesso');

  } catch (error) {
    console.error('Erro ao fazer logout:', error);
    return ResponseHandler.serverError(res, 'Erro ao fazer logout');
  }
}

module.exports = {
  register,
  login,
  getMe,
  recuperarSenha,
  redefinirSenha,
  logout
};

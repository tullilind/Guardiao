const database = require('../config/database');
const ResponseHandler = require('../utils/responseHandler');

/**
 * Criar avaliação (só pode avaliar serviço concluído)
 */
async function criar(req, res) {
  try {
    const { contratacao_id, id_avaliador, id_avaliado, nota_estrelas, comentario } = req.body;

    if (!contratacao_id || !id_avaliador || !id_avaliado || !nota_estrelas) {
      return ResponseHandler.validationError(res, ['Campos obrigatórios faltando']);
    }

    if (nota_estrelas < 1 || nota_estrelas > 5) {
      return ResponseHandler.validationError(res, ['Nota deve ser entre 1 e 5']);
    }

    // Verificar se contratação existe e está concluída
    const contratacao = await database.get(
      'SELECT * FROM contratacoes_servico WHERE id = ?',
      [contratacao_id]
    );

    if (!contratacao) {
      return ResponseHandler.notFound(res, 'Contratação não encontrada');
    }

    if (contratacao.status_servico !== 'Concluído') {
      return ResponseHandler.conflict(res, 'Só é possível avaliar serviços concluídos');
    }

    // Verificar se avaliador é parte da contratação
    if (contratacao.id_prestador !== id_avaliador && contratacao.id_solicitante !== id_avaliador) {
      return ResponseHandler.forbidden(res, 'Você não pode avaliar esta contratação');
    }

    // Verificar se avaliado é parte da contratação
    if (contratacao.id_prestador !== id_avaliado && contratacao.id_solicitante !== id_avaliado) {
      return ResponseHandler.validationError(res, ['Avaliado deve ser parte da contratação']);
    }

    // Verificar se já existe avaliação
    const avaliacaoExistente = await database.get(
      `SELECT id FROM avaliacoes_servico 
       WHERE contratacao_id = ? AND id_avaliador = ?`,
      [contratacao_id, id_avaliador]
    );

    if (avaliacaoExistente) {
      return ResponseHandler.conflict(res, 'Você já avaliou esta contratação');
    }

    // Criar avaliação
    const result = await database.run(
      `INSERT INTO avaliacoes_servico 
       (contratacao_id, id_avaliador, id_avaliado, nota_estrelas, comentario)
       VALUES (?, ?, ?, ?, ?)`,
      [contratacao_id, id_avaliador, id_avaliado, nota_estrelas, comentario || null]
    );

    // Recalcular média do avaliado
    await recalcularMediaAvaliacao(id_avaliado);

    // Criar notificação
    await database.run(
      `INSERT INTO notificacoes_usuario (usuario_id, mensagem, link_acao)
       VALUES (?, ?, ?)`,
      [id_avaliado, `Você recebeu uma nova avaliação: ${nota_estrelas} estrelas`, `/avaliacoes/${result.id}`]
    );

    return ResponseHandler.created(res, { id: result.id }, 'Avaliação criada com sucesso');

  } catch (error) {
    console.error('Erro ao criar avaliação:', error);
    return ResponseHandler.error(res, 'Erro ao criar avaliação');
  }
}

/**
 * Recalcular média de avaliação do usuário
 */
async function recalcularMediaAvaliacao(usuario_id) {
  try {
    const { media } = await database.get(
      `SELECT AVG(nota_estrelas) as media
       FROM avaliacoes_servico
       WHERE id_avaliado = ?`,
      [usuario_id]
    );

    const mediaFormatada = media ? parseFloat(media).toFixed(2) : 0.00;

    await database.run(
      'UPDATE usuarios SET media_avaliacao = ? WHERE id = ?',
      [mediaFormatada, usuario_id]
    );

    return mediaFormatada;
  } catch (error) {
    console.error('Erro ao recalcular média:', error);
    throw error;
  }
}

/**
 * Listar avaliações de um usuário
 */
async function listarPorUsuario(req, res) {
  try {
    const { usuario_id } = req.params;
    const { page = 1, limit = 10 } = req.query;
    const offset = (page - 1) * limit;

    const avaliacoes = await database.all(
      `SELECT a.*, 
              av.nome_completo as avaliador_nome,
              c.servico_nome
       FROM avaliacoes_servico a
       INNER JOIN usuarios av ON a.id_avaliador = av.id
       INNER JOIN contratacoes_servico c ON a.contratacao_id = c.id
       WHERE a.id_avaliado = ?
       ORDER BY a.data_avaliacao DESC
       LIMIT ? OFFSET ?`,
      [usuario_id, parseInt(limit), parseInt(offset)]
    );

    // Contar total
    const { total } = await database.get(
      'SELECT COUNT(*) as total FROM avaliacoes_servico WHERE id_avaliado = ?',
      [usuario_id]
    );

    // Obter estatísticas
    const stats = await database.get(
      `SELECT 
        AVG(nota_estrelas) as media,
        COUNT(*) as total_avaliacoes,
        SUM(CASE WHEN nota_estrelas = 5 THEN 1 ELSE 0 END) as cinco_estrelas,
        SUM(CASE WHEN nota_estrelas = 4 THEN 1 ELSE 0 END) as quatro_estrelas,
        SUM(CASE WHEN nota_estrelas = 3 THEN 1 ELSE 0 END) as tres_estrelas,
        SUM(CASE WHEN nota_estrelas = 2 THEN 1 ELSE 0 END) as duas_estrelas,
        SUM(CASE WHEN nota_estrelas = 1 THEN 1 ELSE 0 END) as uma_estrela
       FROM avaliacoes_servico
       WHERE id_avaliado = ?`,
      [usuario_id]
    );

    return ResponseHandler.success(res, {
      avaliacoes,
      estatisticas: {
        media: parseFloat(stats.media || 0).toFixed(2),
        total_avaliacoes: stats.total_avaliacoes,
        distribuicao: {
          5: stats.cinco_estrelas,
          4: stats.quatro_estrelas,
          3: stats.tres_estrelas,
          2: stats.duas_estrelas,
          1: stats.uma_estrela
        }
      },
      paginacao: {
        total,
        pagina_atual: parseInt(page),
        total_paginas: Math.ceil(total / limit),
        itens_por_pagina: parseInt(limit)
      }
    });

  } catch (error) {
    console.error('Erro ao listar avaliações:', error);
    return ResponseHandler.error(res, 'Erro ao listar avaliações');
  }
}

/**
 * Listar avaliações feitas por um usuário
 */
async function listarFeitasPorUsuario(req, res) {
  try {
    const { usuario_id } = req.params;

    const avaliacoes = await database.all(
      `SELECT a.*, 
              av.nome_completo as avaliado_nome,
              c.servico_nome
       FROM avaliacoes_servico a
       INNER JOIN usuarios av ON a.id_avaliado = av.id
       INNER JOIN contratacoes_servico c ON a.contratacao_id = c.id
       WHERE a.id_avaliador = ?
       ORDER BY a.data_avaliacao DESC`,
      [usuario_id]
    );

    return ResponseHandler.success(res, {
      total: avaliacoes.length,
      avaliacoes
    });

  } catch (error) {
    console.error('Erro ao listar avaliações feitas:', error);
    return ResponseHandler.error(res, 'Erro ao listar avaliações');
  }
}

/**
 * Listar avaliações de uma contratação
 */
async function listarPorContratacao(req, res) {
  try {
    const { contratacao_id } = req.params;

    const avaliacoes = await database.all(
      `SELECT a.*, 
              av.nome_completo as avaliador_nome,
              avd.nome_completo as avaliado_nome
       FROM avaliacoes_servico a
       INNER JOIN usuarios av ON a.id_avaliador = av.id
       INNER JOIN usuarios avd ON a.id_avaliado = avd.id
       WHERE a.contratacao_id = ?
       ORDER BY a.data_avaliacao DESC`,
      [contratacao_id]
    );

    return ResponseHandler.success(res, {
      total: avaliacoes.length,
      avaliacoes
    });

  } catch (error) {
    console.error('Erro ao listar avaliações da contratação:', error);
    return ResponseHandler.error(res, 'Erro ao listar avaliações');
  }
}

/**
 * Obter avaliação por ID
 */
async function obterPorId(req, res) {
  try {
    const { id } = req.params;

    const avaliacao = await database.get(
      `SELECT a.*, 
              av.nome_completo as avaliador_nome,
              avd.nome_completo as avaliado_nome,
              c.servico_nome
       FROM avaliacoes_servico a
       INNER JOIN usuarios av ON a.id_avaliador = av.id
       INNER JOIN usuarios avd ON a.id_avaliado = avd.id
       INNER JOIN contratacoes_servico c ON a.contratacao_id = c.id
       WHERE a.id = ?`,
      [id]
    );

    if (!avaliacao) {
      return ResponseHandler.notFound(res, 'Avaliação não encontrada');
    }

    return ResponseHandler.success(res, avaliacao);

  } catch (error) {
    console.error('Erro ao obter avaliação:', error);
    return ResponseHandler.error(res, 'Erro ao obter avaliação');
  }
}

/**
 * Atualizar avaliação
 */
async function atualizar(req, res) {
  try {
    const { id } = req.params;
    const { nota_estrelas, comentario } = req.body;

    const avaliacao = await database.get(
      'SELECT * FROM avaliacoes_servico WHERE id = ?',
      [id]
    );

    if (!avaliacao) {
      return ResponseHandler.notFound(res, 'Avaliação não encontrada');
    }

    // Verificar permissão
    if (avaliacao.id_avaliador !== req.user.id) {
      return ResponseHandler.forbidden(res, 'Você só pode editar suas próprias avaliações');
    }

    const updates = [];
    const params = [];

    if (nota_estrelas !== undefined) {
      if (nota_estrelas < 1 || nota_estrelas > 5) {
        return ResponseHandler.validationError(res, ['Nota deve ser entre 1 e 5']);
      }
      updates.push('nota_estrelas = ?');
      params.push(nota_estrelas);
    }

    if (comentario !== undefined) {
      updates.push('comentario = ?');
      params.push(comentario);
    }

    if (updates.length === 0) {
      return ResponseHandler.validationError(res, ['Nenhum campo para atualizar']);
    }

    params.push(id);
    await database.run(
      `UPDATE avaliacoes_servico SET ${updates.join(', ')} WHERE id = ?`,
      params
    );

    // Recalcular média se nota foi alterada
    if (nota_estrelas !== undefined) {
      await recalcularMediaAvaliacao(avaliacao.id_avaliado);
    }

    return ResponseHandler.success(res, null, 'Avaliação atualizada com sucesso');

  } catch (error) {
    console.error('Erro ao atualizar avaliação:', error);
    return ResponseHandler.error(res, 'Erro ao atualizar avaliação');
  }
}

/**
 * Deletar avaliação
 */
async function deletar(req, res) {
  try {
    const { id } = req.params;

    const avaliacao = await database.get(
      'SELECT * FROM avaliacoes_servico WHERE id = ?',
      [id]
    );

    if (!avaliacao) {
      return ResponseHandler.notFound(res, 'Avaliação não encontrada');
    }

    // Verificar permissão
    if (avaliacao.id_avaliador !== req.user.id) {
      return ResponseHandler.forbidden(res, 'Você só pode deletar suas próprias avaliações');
    }

    await database.run('DELETE FROM avaliacoes_servico WHERE id = ?', [id]);

    // Recalcular média
    await recalcularMediaAvaliacao(avaliacao.id_avaliado);

    return ResponseHandler.success(res, null, 'Avaliação deletada com sucesso');

  } catch (error) {
    console.error('Erro ao deletar avaliação:', error);
    return ResponseHandler.error(res, 'Erro ao deletar avaliação');
  }
}

/**
 * Obter top prestadores por avaliação
 */
async function obterTopPrestadores(req, res) {
  try {
    const { limit = 10 } = req.query;

    const topPrestadores = await database.all(
      `SELECT u.id, u.nome_completo, u.email, u.media_avaliacao,
              COUNT(a.id) as total_avaliacoes
       FROM usuarios u
       INNER JOIN avaliacoes_servico a ON u.id = a.id_avaliado
       WHERE u.media_avaliacao > 0
       GROUP BY u.id
       ORDER BY u.media_avaliacao DESC, total_avaliacoes DESC
       LIMIT ?`,
      [parseInt(limit)]
    );

    return ResponseHandler.success(res, topPrestadores);

  } catch (error) {
    console.error('Erro ao obter top prestadores:', error);
    return ResponseHandler.error(res, 'Erro ao obter top prestadores');
  }
}

module.exports = {
  criar,
  listarPorUsuario,
  listarFeitasPorUsuario,
  listarPorContratacao,
  obterPorId,
  atualizar,
  deletar,
  obterTopPrestadores,
  recalcularMediaAvaliacao
};

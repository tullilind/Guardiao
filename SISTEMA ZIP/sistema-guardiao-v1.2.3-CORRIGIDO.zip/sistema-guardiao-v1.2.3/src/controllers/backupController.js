const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const fs = require('fs').promises;
const path = require('path');
const database = require('../config/database');
const { jwtSecret } = require('../config/auth');
const ResponseHandler = require('../utils/responseHandler');

/**
 * Criar admin de backup
 */
async function criarAdmin(req, res) {
  try {
    const { nome_usuario, senha } = req.body;

    if (!nome_usuario || !senha) {
      return ResponseHandler.validationError(res, ['Nome de usuário e senha são obrigatórios']);
    }

    if (senha.length < 6) {
      return ResponseHandler.validationError(res, ['Senha deve ter no mínimo 6 caracteres']);
    }

    // Verificar se já existe admin com esse nome
    const adminExiste = await database.get(
      'SELECT id FROM admin_backup WHERE nome_usuario = ?',
      [nome_usuario]
    );

    if (adminExiste) {
      return ResponseHandler.conflict(res, 'Nome de usuário já existe');
    }

    // Hash da senha
    const senhaHash = await bcrypt.hash(senha, 10);

    // Criar admin
    const result = await database.run(
      'INSERT INTO admin_backup (nome_usuario, senha_hash) VALUES (?, ?)',
      [nome_usuario, senhaHash]
    );

    return ResponseHandler.created(res, {
      id: result.id,
      nome_usuario
    }, 'Administrador criado com sucesso');

  } catch (error) {
    console.error('Erro ao criar admin:', error);
    return ResponseHandler.error(res, 'Erro ao criar administrador');
  }
}

/**
 * Login de admin
 */
async function loginAdmin(req, res) {
  try {
    const { nome_usuario, senha } = req.body;

    if (!nome_usuario || !senha) {
      return ResponseHandler.validationError(res, ['Nome de usuário e senha são obrigatórios']);
    }

    // Buscar admin
    const admin = await database.get(
      'SELECT * FROM admin_backup WHERE nome_usuario = ?',
      [nome_usuario]
    );

    if (!admin) {
      return ResponseHandler.unauthorized(res, 'Credenciais inválidas');
    }

    // Verificar senha
    const senhaValida = await bcrypt.compare(senha, admin.senha_hash);

    if (!senhaValida) {
      return ResponseHandler.unauthorized(res, 'Credenciais inválidas');
    }

    // Gerar token
    const token = jwt.sign(
      { adminId: admin.id, nome_usuario: admin.nome_usuario, isAdmin: true },
      jwtSecret,
      { expiresIn: '24h' }
    );

    return ResponseHandler.success(res, {
      admin: {
        id: admin.id,
        nome_usuario: admin.nome_usuario
      },
      token
    }, 'Login de administrador realizado com sucesso');

  } catch (error) {
    console.error('Erro no login de admin:', error);
    return ResponseHandler.error(res, 'Erro ao realizar login');
  }
}

/**
 * Criar backup do banco de dados
 */
async function criarBackup(req, res) {
  try {
    const dbPath = path.resolve(__dirname, '../../database/database.db');
    const backupDir = path.resolve(__dirname, '../../database/backups');
    
    // Criar diretório de backups se não existir
    try {
      await fs.mkdir(backupDir, { recursive: true });
    } catch (err) {
      // Diretório já existe
    }

    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const backupPath = path.join(backupDir, `backup_${timestamp}.db`);

    // Copiar arquivo do banco
    await fs.copyFile(dbPath, backupPath);

    // Obter tamanho do arquivo
    const stats = await fs.stat(backupPath);
    const tamanhoMB = (stats.size / 1024 / 1024).toFixed(2);

    return ResponseHandler.success(res, {
      arquivo: `backup_${timestamp}.db`,
      caminho: backupPath,
      tamanho_mb: parseFloat(tamanhoMB),
      data_criacao: new Date().toISOString()
    }, 'Backup criado com sucesso');

  } catch (error) {
    console.error('Erro ao criar backup:', error);
    return ResponseHandler.error(res, 'Erro ao criar backup');
  }
}

/**
 * Listar backups disponíveis
 */
async function listarBackups(req, res) {
  try {
    const backupDir = path.resolve(__dirname, '../../database/backups');

    try {
      const arquivos = await fs.readdir(backupDir);
      const backups = [];

      for (const arquivo of arquivos) {
        if (arquivo.endsWith('.db')) {
          const caminhoCompleto = path.join(backupDir, arquivo);
          const stats = await fs.stat(caminhoCompleto);
          
          backups.push({
            nome: arquivo,
            tamanho_mb: (stats.size / 1024 / 1024).toFixed(2),
            data_criacao: stats.birthtime,
            data_modificacao: stats.mtime
          });
        }
      }

      // Ordenar por data de criação (mais recente primeiro)
      backups.sort((a, b) => new Date(b.data_criacao) - new Date(a.data_criacao));

      return ResponseHandler.success(res, {
        total: backups.length,
        backups
      });

    } catch (err) {
      return ResponseHandler.success(res, {
        total: 0,
        backups: []
      }, 'Nenhum backup encontrado');
    }

  } catch (error) {
    console.error('Erro ao listar backups:', error);
    return ResponseHandler.error(res, 'Erro ao listar backups');
  }
}

/**
 * Restaurar backup
 */
async function restaurarBackup(req, res) {
  try {
    const { nome_arquivo } = req.body;

    if (!nome_arquivo) {
      return ResponseHandler.validationError(res, ['Nome do arquivo é obrigatório']);
    }

    const backupDir = path.resolve(__dirname, '../../database/backups');
    const backupPath = path.join(backupDir, nome_arquivo);
    const dbPath = path.resolve(__dirname, '../../database/database.db');

    // Verificar se arquivo de backup existe
    try {
      await fs.access(backupPath);
    } catch (err) {
      return ResponseHandler.notFound(res, 'Arquivo de backup não encontrado');
    }

    // Criar backup do banco atual antes de restaurar
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const backupAnterior = path.join(backupDir, `pre_restore_${timestamp}.db`);
    await fs.copyFile(dbPath, backupAnterior);

    // Fechar conexão atual
    await database.close();

    // Restaurar backup
    await fs.copyFile(backupPath, dbPath);

    // Reconectar
    await database.connect();

    return ResponseHandler.success(res, {
      backup_restaurado: nome_arquivo,
      backup_anterior: `pre_restore_${timestamp}.db`
    }, 'Backup restaurado com sucesso');

  } catch (error) {
    console.error('Erro ao restaurar backup:', error);
    
    // Tentar reconectar em caso de erro
    try {
      await database.connect();
    } catch (reconnectError) {
      console.error('Erro ao reconectar:', reconnectError);
    }

    return ResponseHandler.error(res, 'Erro ao restaurar backup');
  }
}

/**
 * Upload e restaurar backup de arquivo externo
 */
async function uploadRestaurarBackup(req, res) {
  try {
    // Verificar se arquivo foi enviado
    if (!req.file) {
      return ResponseHandler.validationError(res, ['Arquivo de backup é obrigatório']);
    }

    const backupDir = path.resolve(__dirname, '../../database/backups');
    const dbPath = path.resolve(__dirname, '../../database/database.db');
    
    // Criar diretório de backups se não existir
    try {
      await fs.mkdir(backupDir, { recursive: true });
    } catch (err) {
      // Diretório já existe
    }

    // Salvar arquivo enviado no diretório de backups
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const nomeArquivoBackup = `uploaded_backup_${timestamp}.db`;
    const backupUploadPath = path.join(backupDir, nomeArquivoBackup);
    
    await fs.writeFile(backupUploadPath, req.file.buffer);

    // Criar backup do banco atual antes de restaurar
    const backupAnterior = path.join(backupDir, `pre_upload_restore_${timestamp}.db`);
    await fs.copyFile(dbPath, backupAnterior);

    // Fechar conexão atual
    await database.close();

    // Restaurar backup do arquivo enviado
    await fs.copyFile(backupUploadPath, dbPath);

    // Reconectar
    await database.connect();

    return ResponseHandler.success(res, {
      backup_restaurado: nomeArquivoBackup,
      backup_anterior: `pre_upload_restore_${timestamp}.db`,
      tamanho_mb: (req.file.size / 1024 / 1024).toFixed(2)
    }, 'Backup importado e restaurado com sucesso');

  } catch (error) {
    console.error('Erro ao fazer upload e restaurar backup:', error);
    
    // Tentar reconectar em caso de erro
    try {
      await database.connect();
    } catch (reconnectError) {
      console.error('Erro ao reconectar:', reconnectError);
    }

    return ResponseHandler.error(res, 'Erro ao importar e restaurar backup');
  }
}

/**
 * Download de backup
 */
async function downloadBackup(req, res) {
  try {
    const { nome_arquivo } = req.params;

    const backupDir = path.resolve(__dirname, '../../database/backups');
    const backupPath = path.join(backupDir, nome_arquivo);

    // Verificar se arquivo existe
    try {
      await fs.access(backupPath);
    } catch (err) {
      return ResponseHandler.notFound(res, 'Arquivo de backup não encontrado');
    }

    // Enviar arquivo
    res.download(backupPath, nome_arquivo, (err) => {
      if (err) {
        console.error('Erro ao fazer download:', err);
        return ResponseHandler.error(res, 'Erro ao fazer download do backup');
      }
    });

  } catch (error) {
    console.error('Erro ao fazer download de backup:', error);
    return ResponseHandler.error(res, 'Erro ao fazer download');
  }
}

/**
 * Deletar backup
 */
async function deletarBackup(req, res) {
  try {
    const { nome_arquivo } = req.params;

    const backupDir = path.resolve(__dirname, '../../database/backups');
    const backupPath = path.join(backupDir, nome_arquivo);

    // Verificar se arquivo existe
    try {
      await fs.access(backupPath);
    } catch (err) {
      return ResponseHandler.notFound(res, 'Arquivo de backup não encontrado');
    }

    // Deletar arquivo
    await fs.unlink(backupPath);

    return ResponseHandler.success(res, null, 'Backup deletado com sucesso');

  } catch (error) {
    console.error('Erro ao deletar backup:', error);
    return ResponseHandler.error(res, 'Erro ao deletar backup');
  }
}

/**
 * Obter estatísticas do sistema
 */
async function obterEstatisticasSistema(req, res) {
  try {
    const stats = {};

    // Contar usuários
    const { total_usuarios } = await database.get('SELECT COUNT(*) as total_usuarios FROM usuarios');
    stats.total_usuarios = total_usuarios;

    // Contar contratações
    const { total_contratacoes } = await database.get('SELECT COUNT(*) as total_contratacoes FROM contratacoes_servico');
    stats.total_contratacoes = total_contratacoes;

    // Contar avaliações
    const { total_avaliacoes } = await database.get('SELECT COUNT(*) as total_avaliacoes FROM avaliacoes_servico');
    stats.total_avaliacoes = total_avaliacoes;

    // Contar documentos
    const { total_documentos } = await database.get('SELECT COUNT(*) as total_documentos FROM documentos_validacao');
    stats.total_documentos = total_documentos;

    // Contar arquivos e espaço usado
    const { total_arquivos, espaco_total_kb } = await database.get(
      'SELECT COUNT(*) as total_arquivos, SUM(tamanho_kb) as espaco_total_kb FROM arquivos_sistema'
    );
    stats.total_arquivos = total_arquivos;
    stats.espaco_usado_mb = (parseFloat(espaco_total_kb || 0) / 1024).toFixed(2);

    // Tamanho do banco de dados
    const dbPath = path.resolve(__dirname, '../../database/database.db');
    const dbStats = await fs.stat(dbPath);
    stats.tamanho_banco_mb = (dbStats.size / 1024 / 1024).toFixed(2);

    return ResponseHandler.success(res, stats);

  } catch (error) {
    console.error('Erro ao obter estatísticas:', error);
    return ResponseHandler.error(res, 'Erro ao obter estatísticas');
  }
}

module.exports = {
  criarAdmin,
  loginAdmin,
  criarBackup,
  listarBackups,
  restaurarBackup,
  uploadRestaurarBackup,
  downloadBackup,
  deletarBackup,
  obterEstatisticasSistema
};

const database = require('../config/database');
const ResponseHandler = require('../utils/responseHandler');

/**
 * Listar todos os prestadores (com filtros)
 */
async function listar(req, res) {
  try {
    const { 
      verificado, 
      avaliacao_minima, 
      page = 1, 
      limit = 20,
      ordenar_por = 'media_avaliacao' // media_avaliacao, data_cadastro, nome_completo
    } = req.query;
    
    const offset = (page - 1) * limit;

    let sql = `SELECT u.id, u.nome_completo, u.email, u.celular, u.cpf_cnpj,
                      u.perfil_verificado, u.media_avaliacao, u.foto_perfil_id,
                      u.data_cadastro, u.sexo, u.rua, u.cidade, u.estado, u.bairro, u.cep,
                      COUNT(DISTINCT c.id) as total_servicos_realizados,
                      COUNT(DISTINCT a.id) as total_avaliacoes,
                      arq.conteudo_blob, arq.mime_type
               FROM usuarios u
               LEFT JOIN contratacoes_servico c ON u.id = c.id_prestador AND c.status_servico = 'Concluído'
               LEFT JOIN avaliacoes_servico a ON u.id = a.id_avaliado
               LEFT JOIN arquivos_sistema arq ON u.foto_perfil_id = arq.id
               WHERE 1=1`;
    let params = [];

    // Filtro por perfil verificado
    if (verificado !== undefined) {
      sql += ' AND u.perfil_verificado = ?';
      params.push(verificado === 'true' ? 1 : 0);
    }

    // Filtro por avaliação mínima
    if (avaliacao_minima) {
      sql += ' AND u.media_avaliacao >= ?';
      params.push(parseFloat(avaliacao_minima));
    }

    sql += ' GROUP BY u.id';

    // Ordenação
    const ordenacoesValidas = {
      'media_avaliacao': 'u.media_avaliacao DESC',
      'data_cadastro': 'u.data_cadastro DESC',
      'nome_completo': 'u.nome_completo ASC'
    };
    
    
    sql += ` ORDER BY ${ordenacoesValidas[ordenar_por] || ordenacoesValidas['media_avaliacao']}`;
    sql += ' LIMIT ? OFFSET ?';
    params.push(parseInt(limit) || 20, parseInt(offset) || 0);

    const prestadoresRaw = await database.all(sql, params);

    // Processar fotos em base64
    const prestadores = prestadoresRaw.map(p => {
      let fotoBase64 = null;
      if (p.conteudo_blob) {
        fotoBase64 = `data:${p.mime_type};base64,${p.conteudo_blob.toString('base64')}`;
      }
      return {
        id: p.id,
        nome_completo: p.nome_completo,
        email: p.email,
        celular: p.celular,
        cpf_cnpj: p.cpf_cnpj,
        sexo: p.sexo,
        endereco: {
          rua: p.rua,
          cidade: p.cidade,
          estado: p.estado,
          bairro: p.bairro,
          cep: p.cep
        },
        perfil_verificado: p.perfil_verificado,
        media_avaliacao: p.media_avaliacao,
        foto_perfil: fotoBase64,
        data_cadastro: p.data_cadastro,
        total_servicos_realizados: p.total_servicos_realizados,
        total_avaliacoes: p.total_avaliacoes
      };
    });

    // Contar total
    let countSql = 'SELECT COUNT(*) as total FROM usuarios WHERE 1=1';
    let countParams = [];
    if (verificado !== undefined) {
      countSql += ' AND perfil_verificado = ?';
      countParams.push(verificado === 'true' ? 1 : 0);
    }
    if (avaliacao_minima) {
      countSql += ' AND media_avaliacao >= ?';
      countParams.push(parseFloat(avaliacao_minima));
    }

    const { total } = await database.get(countSql, countParams);

    return ResponseHandler.success(res, {
      prestadores,
      paginacao: {
        total,
        pagina_atual: parseInt(page),
        total_paginas: Math.ceil(total / limit),
        itens_por_pagina: parseInt(limit)
      }
    });

  } catch (error) {
    console.error('Erro ao listar prestadores:', error);
    return ResponseHandler.error(res, 'Erro ao listar prestadores');
  }
}

/**
 * Buscar prestador por ID com detalhes completos
 */
async function obterPorId(req, res) {
  try {
    const { id } = req.params;

    // Dados do prestador
    const prestador = await database.get(
      `SELECT u.id, u.nome_completo, u.email, u.celular, u.cpf_cnpj,
              u.perfil_verificado, u.media_avaliacao, u.foto_perfil_id,
              u.data_cadastro, u.sexo, u.rua, u.cidade, u.estado, u.bairro, u.cep,
              a.conteudo_blob, a.mime_type
       FROM usuarios u
       LEFT JOIN arquivos_sistema a ON u.foto_perfil_id = a.id
       WHERE u.id = ?`,
      [id]
    );

    if (!prestador) {
      return ResponseHandler.notFound(res, 'Prestador não encontrado');
    }

    // Total de serviços realizados
    const { total_servicos } = await database.get(
      `SELECT COUNT(*) as total_servicos 
       FROM contratacoes_servico 
       WHERE id_prestador = ? AND status_servico = 'Concluído'`,
      [id]
    );

    // Total de avaliações
    const { total_avaliacoes } = await database.get(
      'SELECT COUNT(*) as total_avaliacoes FROM avaliacoes_servico WHERE id_avaliado = ?',
      [id]
    );

    // Últimas avaliações
    const ultimasAvaliacoes = await database.all(
      `SELECT a.*, av.nome_completo as avaliador_nome, c.servico_nome
       FROM avaliacoes_servico a
       INNER JOIN usuarios av ON a.id_avaliador = av.id
       INNER JOIN contratacoes_servico c ON a.contratacao_id = c.id
       WHERE a.id_avaliado = ?
       ORDER BY a.data_avaliacao DESC
       LIMIT 5`,
      [id]
    );

    // Status de documentos
    const documentos = await database.all(
      `SELECT tipo_documento, status, data_envio, data_validacao
       FROM documentos_validacao
       WHERE usuario_id = ?
       ORDER BY data_envio DESC`,
      [id]
    );

    // Converter foto para base64
    let fotoBase64 = null;
    if (prestador.conteudo_blob) {
      fotoBase64 = `data:${prestador.mime_type};base64,${prestador.conteudo_blob.toString('base64')}`;
    }

    return ResponseHandler.success(res, {
      id: prestador.id,
      nome_completo: prestador.nome_completo,
      email: prestador.email,
      celular: prestador.celular,
      cpf_cnpj: prestador.cpf_cnpj,
      sexo: prestador.sexo,
      endereco: {
        rua: prestador.rua,
        cidade: prestador.cidade,
        estado: prestador.estado,
        bairro: prestador.bairro,
        cep: prestador.cep
      },
      perfil_verificado: prestador.perfil_verificado,
      media_avaliacao: prestador.media_avaliacao,
      foto_perfil: fotoBase64,
      data_cadastro: prestador.data_cadastro,
      total_servicos_realizados: total_servicos,
      total_avaliacoes,
      ultimas_avaliacoes: ultimasAvaliacoes,
      documentos
    });

  } catch (error) {
    console.error('Erro ao obter prestador:', error);
    return ResponseHandler.error(res, 'Erro ao obter prestador');
  }
}

/**
 * Listar serviços realizados pelo prestador
 */
async function listarServicos(req, res) {
  try {
    const { id } = req.params;
    const { status_servico, page = 1, limit = 10 } = req.query;
    const offset = (page - 1) * limit;

    let sql = `SELECT c.*, s.nome_completo as solicitante_nome
               FROM contratacoes_servico c
               INNER JOIN usuarios s ON c.id_solicitante = s.id
               WHERE c.id_prestador = ?`;
    let params = [id];

    if (status_servico) {
      sql += ' AND c.status_servico = ?';
      params.push(status_servico);
    }

    sql += ' ORDER BY c.data_contrato DESC LIMIT ? OFFSET ?';
    params.push(parseInt(limit), parseInt(offset));

    const servicos = await database.all(sql, params);

    // Contar total
    let countSql = 'SELECT COUNT(*) as total FROM contratacoes_servico WHERE id_prestador = ?';
    let countParams = [id];
    if (status_servico) {
      countSql += ' AND status_servico = ?';
      countParams.push(status_servico);
    }

    const { total } = await database.get(countSql, countParams);

    return ResponseHandler.success(res, {
      servicos,
      paginacao: {
        total,
        pagina_atual: parseInt(page),
        total_paginas: Math.ceil(total / limit),
        itens_por_pagina: parseInt(limit)
      }
    });

  } catch (error) {
    console.error('Erro ao listar serviços do prestador:', error);
    return ResponseHandler.error(res, 'Erro ao listar serviços');
  }
}

/**
 * Listar apenas prestadores verificados
 */
async function listarVerificados(req, res) {
  try {
    const { avaliacao_minima = 0, limit = 20 } = req.query;

    const prestadoresRaw = await database.all(
      `SELECT u.id, u.nome_completo, u.email, u.celular, u.media_avaliacao,
              u.foto_perfil_id, u.data_cadastro, u.sexo, u.rua, u.cidade, u.estado, u.bairro, u.cep,
              COUNT(DISTINCT c.id) as total_servicos_realizados,
              a.conteudo_blob, a.mime_type
       FROM usuarios u
       LEFT JOIN contratacoes_servico c ON u.id = c.id_prestador AND c.status_servico = 'Concluído'
       LEFT JOIN arquivos_sistema a ON u.foto_perfil_id = a.id
       WHERE u.perfil_verificado = 1 AND u.media_avaliacao >= ?
       GROUP BY u.id
       ORDER BY u.media_avaliacao DESC, total_servicos_realizados DESC
       LIMIT ?`,
      [parseFloat(avaliacao_minima), parseInt(limit)]
    );

    // Processar fotos em base64
    const prestadores = prestadoresRaw.map(p => {
      let fotoBase64 = null;
      if (p.conteudo_blob) {
        fotoBase64 = `data:${p.mime_type};base64,${p.conteudo_blob.toString('base64')}`;
      }
      return {
        id: p.id,
        nome_completo: p.nome_completo,
        email: p.email,
        celular: p.celular,
        sexo: p.sexo,
        endereco: {
          rua: p.rua,
          cidade: p.cidade,
          estado: p.estado,
          bairro: p.bairro,
          cep: p.cep
        },
        media_avaliacao: p.media_avaliacao,
        foto_perfil: fotoBase64,
        data_cadastro: p.data_cadastro,
        total_servicos_realizados: p.total_servicos_realizados
      };
    });

    return ResponseHandler.success(res, {
      total: prestadores.length,
      prestadores
    });

  } catch (error) {
    console.error('Erro ao listar prestadores verificados:', error);
    return ResponseHandler.error(res, 'Erro ao listar prestadores verificados');
  }
}

/**
 * Buscar prestadores (por nome, email, etc)
 */
async function buscar(req, res) {
  try {
    const { termo, verificado_apenas = false } = req.query;

    if (!termo) {
      return ResponseHandler.validationError(res, ['Termo de busca é obrigatório']);
    }

    let sql = `SELECT u.id, u.nome_completo, u.email, u.celular, u.cpf_cnpj,
                      u.perfil_verificado, u.media_avaliacao, u.foto_perfil_id,
                      u.sexo, u.rua, u.cidade, u.estado, u.bairro, u.cep,
                      a.conteudo_blob, a.mime_type
               FROM usuarios u
               LEFT JOIN arquivos_sistema a ON u.foto_perfil_id = a.id
               WHERE (u.nome_completo LIKE ? OR u.email LIKE ? OR u.celular LIKE ?)`;
    
    const termoBusca = `%${termo}%`;
    let params = [termoBusca, termoBusca, termoBusca];

    if (verificado_apenas === 'true') {
      sql += ' AND u.perfil_verificado = 1';
    }

    sql += ' ORDER BY u.media_avaliacao DESC LIMIT 50';

    const resultadosRaw = await database.all(sql, params);

    // Processar fotos em base64
    const resultados = resultadosRaw.map(r => {
      let fotoBase64 = null;
      if (r.conteudo_blob) {
        fotoBase64 = `data:${r.mime_type};base64,${r.conteudo_blob.toString('base64')}`;
      }
      return {
        id: r.id,
        nome_completo: r.nome_completo,
        email: r.email,
        celular: r.celular,
        cpf_cnpj: r.cpf_cnpj,
        sexo: r.sexo,
        endereco: {
          rua: r.rua,
          cidade: r.cidade,
          estado: r.estado,
          bairro: r.bairro,
          cep: r.cep
        },
        perfil_verificado: r.perfil_verificado,
        media_avaliacao: r.media_avaliacao,
        foto_perfil: fotoBase64
      };
    });

    return ResponseHandler.success(res, {
      total: resultados.length,
      resultados
    });

  } catch (error) {
    console.error('Erro ao buscar prestadores:', error);
    return ResponseHandler.error(res, 'Erro ao buscar prestadores');
  }
}

/**
 * Obter estatísticas do prestador
 */
async function obterEstatisticas(req, res) {
  try {
    const { id } = req.params;

    // Verificar se usuário existe
    const usuario = await database.get('SELECT id FROM usuarios WHERE id = ?', [id]);
    if (!usuario) {
      return ResponseHandler.notFound(res, 'Prestador não encontrado');
    }

    const stats = await database.get(
      `SELECT 
        COUNT(DISTINCT CASE WHEN c.status_servico = 'Concluído' THEN c.id END) as servicos_concluidos,
        COUNT(DISTINCT CASE WHEN c.status_servico = 'Em Andamento' THEN c.id END) as servicos_andamento,
        COUNT(DISTINCT CASE WHEN c.status_servico = 'Agendado' THEN c.id END) as servicos_agendados,
        COUNT(DISTINCT a.id) as total_avaliacoes,
        AVG(a.nota_estrelas) as media_avaliacoes,
        SUM(CASE WHEN c.status_servico = 'Concluído' THEN c.valor_acordado ELSE 0 END) as valor_total_servicos
       FROM usuarios u
       LEFT JOIN contratacoes_servico c ON u.id = c.id_prestador
       LEFT JOIN avaliacoes_servico a ON u.id = a.id_avaliado
       WHERE u.id = ?`,
      [id]
    );

    return ResponseHandler.success(res, {
      servicos_concluidos: stats.servicos_concluidos || 0,
      servicos_andamento: stats.servicos_andamento || 0,
      servicos_agendados: stats.servicos_agendados || 0,
      total_avaliacoes: stats.total_avaliacoes || 0,
      media_avaliacoes: parseFloat(stats.media_avaliacoes || 0).toFixed(2),
      valor_total_servicos: parseFloat(stats.valor_total_servicos || 0).toFixed(2)
    });

  } catch (error) {
    console.error('Erro ao obter estatísticas:', error);
    return ResponseHandler.error(res, 'Erro ao obter estatísticas');
  }
}

module.exports = {
  listar,
  obterPorId,
  listarServicos,
  listarVerificados,
  buscar,
  obterEstatisticas
};

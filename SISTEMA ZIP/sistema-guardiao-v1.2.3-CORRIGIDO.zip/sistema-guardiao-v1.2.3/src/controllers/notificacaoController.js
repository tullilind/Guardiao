const database = require('../config/database');
const ResponseHandler = require('../utils/responseHandler');

/**
 * Criar notificação
 */
async function criar(req, res) {
  try {
    const { usuario_id, mensagem, link_acao } = req.body;

    if (!usuario_id || !mensagem) {
      return ResponseHandler.validationError(res, ['Usuário e mensagem são obrigatórios']);
    }

    // Verificar se usuário existe
    const usuario = await database.get(
      'SELECT id FROM usuarios WHERE id = ?',
      [usuario_id]
    );

    if (!usuario) {
      return ResponseHandler.notFound(res, 'Usuário não encontrado');
    }

    const result = await database.run(
      `INSERT INTO notificacoes_usuario (usuario_id, mensagem, link_acao)
       VALUES (?, ?, ?)`,
      [usuario_id, mensagem, link_acao || null]
    );

    return ResponseHandler.created(res, { id: result.id }, 'Notificação criada com sucesso');

  } catch (error) {
    console.error('Erro ao criar notificação:', error);
    return ResponseHandler.error(res, 'Erro ao criar notificação');
  }
}

/**
 * Listar notificações do usuário
 */
async function listarPorUsuario(req, res) {
  try {
    const { usuario_id } = req.params;
    const { lida, limit = 50 } = req.query;

    // Verificar permissão
    if (req.user.id !== parseInt(usuario_id)) {
      return ResponseHandler.forbidden(res, 'Você só pode ver suas próprias notificações');
    }

    let sql = 'SELECT * FROM notificacoes_usuario WHERE usuario_id = ?';
    let params = [usuario_id];

    // Filtro por lida/não lida
    if (lida !== undefined) {
      sql += ' AND lida = ?';
      params.push(lida === 'true' ? 1 : 0);
    }

    sql += ' ORDER BY data_criacao DESC LIMIT ?';
    params.push(parseInt(limit));

    const notificacoes = await database.all(sql, params);

    // Contar não lidas
    const { nao_lidas } = await database.get(
      'SELECT COUNT(*) as nao_lidas FROM notificacoes_usuario WHERE usuario_id = ? AND lida = 0',
      [usuario_id]
    );

    return ResponseHandler.success(res, {
      total: notificacoes.length,
      nao_lidas,
      notificacoes
    });

  } catch (error) {
    console.error('Erro ao listar notificações:', error);
    return ResponseHandler.error(res, 'Erro ao listar notificações');
  }
}

/**
 * Listar apenas notificações não lidas
 */
async function listarNaoLidas(req, res) {
  try {
    const usuario_id = req.user.id;

    const notificacoes = await database.all(
      `SELECT * FROM notificacoes_usuario
       WHERE usuario_id = ? AND lida = 0
       ORDER BY data_criacao DESC`,
      [usuario_id]
    );

    return ResponseHandler.success(res, {
      total: notificacoes.length,
      notificacoes
    });

  } catch (error) {
    console.error('Erro ao listar notificações não lidas:', error);
    return ResponseHandler.error(res, 'Erro ao listar notificações');
  }
}

/**
 * Marcar notificação como lida
 */
async function marcarComoLida(req, res) {
  try {
    const { id } = req.params;

    const notificacao = await database.get(
      'SELECT * FROM notificacoes_usuario WHERE id = ?',
      [id]
    );

    if (!notificacao) {
      return ResponseHandler.notFound(res, 'Notificação não encontrada');
    }

    // Verificar permissão
    if (notificacao.usuario_id !== req.user.id) {
      return ResponseHandler.forbidden(res, 'Você não tem permissão para marcar esta notificação');
    }

    await database.run(
      'UPDATE notificacoes_usuario SET lida = 1 WHERE id = ?',
      [id]
    );

    return ResponseHandler.success(res, null, 'Notificação marcada como lida');

  } catch (error) {
    console.error('Erro ao marcar notificação como lida:', error);
    return ResponseHandler.error(res, 'Erro ao marcar notificação');
  }
}

/**
 * Marcar todas as notificações como lidas
 */
async function marcarTodasComoLidas(req, res) {
  try {
    const usuario_id = req.user.id;

    const result = await database.run(
      'UPDATE notificacoes_usuario SET lida = 1 WHERE usuario_id = ? AND lida = 0',
      [usuario_id]
    );

    return ResponseHandler.success(res, {
      marcadas: result.changes
    }, 'Todas as notificações foram marcadas como lidas');

  } catch (error) {
    console.error('Erro ao marcar todas como lidas:', error);
    return ResponseHandler.error(res, 'Erro ao marcar notificações');
  }
}

/**
 * Deletar notificação
 */
async function deletar(req, res) {
  try {
    const { id } = req.params;

    const notificacao = await database.get(
      'SELECT * FROM notificacoes_usuario WHERE id = ?',
      [id]
    );

    if (!notificacao) {
      return ResponseHandler.notFound(res, 'Notificação não encontrada');
    }

    // Verificar permissão
    if (notificacao.usuario_id !== req.user.id) {
      return ResponseHandler.forbidden(res, 'Você não tem permissão para deletar esta notificação');
    }

    await database.run('DELETE FROM notificacoes_usuario WHERE id = ?', [id]);

    return ResponseHandler.success(res, null, 'Notificação deletada com sucesso');

  } catch (error) {
    console.error('Erro ao deletar notificação:', error);
    return ResponseHandler.error(res, 'Erro ao deletar notificação');
  }
}

/**
 * Deletar todas as notificações lidas
 */
async function deletarLidas(req, res) {
  try {
    const usuario_id = req.user.id;

    const result = await database.run(
      'DELETE FROM notificacoes_usuario WHERE usuario_id = ? AND lida = 1',
      [usuario_id]
    );

    return ResponseHandler.success(res, {
      deletadas: result.changes
    }, 'Notificações lidas deletadas com sucesso');

  } catch (error) {
    console.error('Erro ao deletar notificações lidas:', error);
    return ResponseHandler.error(res, 'Erro ao deletar notificações');
  }
}

/**
 * Obter contagem de notificações
 */
async function obterContagem(req, res) {
  try {
    const usuario_id = req.user.id;

    const stats = await database.get(
      `SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN lida = 0 THEN 1 ELSE 0 END) as nao_lidas,
        SUM(CASE WHEN lida = 1 THEN 1 ELSE 0 END) as lidas
       FROM notificacoes_usuario
       WHERE usuario_id = ?`,
      [usuario_id]
    );

    return ResponseHandler.success(res, stats);

  } catch (error) {
    console.error('Erro ao obter contagem:', error);
    return ResponseHandler.error(res, 'Erro ao obter contagem');
  }
}

module.exports = {
  criar,
  listarPorUsuario,
  listarNaoLidas,
  marcarComoLida,
  marcarTodasComoLidas,
  deletar,
  deletarLidas,
  obterContagem
};

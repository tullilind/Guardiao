const database = require('../config/database');
const ResponseHandler = require('../utils/responseHandler');
const { cadastrarFaceInicial, autenticarPorFace, detectarFace, compararFaces } = require('../utils/facePlusPlusHelper');
const { enviarEmail } = require('../utils/emailHelper');

/**
 * Verificar status de documentos e perfil do usuário
 */
async function verificarStatus(req, res) {
  try {
    const { id } = req.params;

    // Dados do usuário
    const usuario = await database.get(
      'SELECT id, nome_completo, email, perfil_verificado FROM usuarios WHERE id = ?',
      [id]
    );

    if (!usuario) {
      return ResponseHandler.notFound(res, 'Usuário não encontrado');
    }

    // Documentos do usuário
    const documentos = await database.all(
      `SELECT id, tipo_documento, status, data_envio, data_validacao, motivo_rejeicao
       FROM documentos_validacao
       WHERE usuario_id = ?
       ORDER BY data_envio DESC`,
      [id]
    );

    // Estatísticas de documentos
    const stats = await database.get(
      `SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN status = 'Pendente' THEN 1 ELSE 0 END) as pendentes,
        SUM(CASE WHEN status = 'Aprovado' THEN 1 ELSE 0 END) as aprovados,
        SUM(CASE WHEN status = 'Rejeitado' THEN 1 ELSE 0 END) as rejeitados
       FROM documentos_validacao
       WHERE usuario_id = ?`,
      [id]
    );

    // Verificar se tem biometria facial
    const biometria = await database.get(
      'SELECT id, face_token, data_cadastro FROM biometria_usuario WHERE usuario_id = ?',
      [id]
    );

    return ResponseHandler.success(res, {
      usuario: {
        id: usuario.id,
        nome_completo: usuario.nome_completo,
        email: usuario.email,
        perfil_verificado: usuario.perfil_verificado === 1
      },
      documentos: {
        total: stats.total || 0,
        pendentes: stats.pendentes || 0,
        aprovados: stats.aprovados || 0,
        rejeitados: stats.rejeitados || 0,
        lista: documentos
      },
      biometria_facial: {
        cadastrada: !!biometria,
        data_cadastro: biometria ? biometria.data_cadastro : null
      },
      pode_usar_sistema: usuario.perfil_verificado === 1
    });

  } catch (error) {
    console.error('Erro ao verificar status:', error);
    return ResponseHandler.error(res, 'Erro ao verificar status');
  }
}

/**
 * Verificar se usuário tem biometria facial cadastrada
 */
async function verificarBiometria(req, res) {
  try {
    const { id } = req.params;

    const biometria = await database.get(
      'SELECT id, face_token, data_cadastro, data_atualizacao FROM biometria_usuario WHERE usuario_id = ?',
      [id]
    );

    if (!biometria) {
      return ResponseHandler.success(res, {
        tem_biometria_facial: false,
        data_cadastro: null,
        data_atualizacao: null
      });
    }

    return ResponseHandler.success(res, {
      tem_biometria_facial: true,
      data_cadastro: biometria.data_cadastro,
      data_atualizacao: biometria.data_atualizacao
    });

  } catch (error) {
    console.error('Erro ao verificar biometria:', error);
    return ResponseHandler.error(res, 'Erro ao verificar biometria');
  }
}

/**
 * Cadastrar biometria facial do usuário usando Face++
 */
async function cadastrarBiometria(req, res) {
  try {
    const { id } = req.params;
    const { foto_base64 } = req.body;

    // Verificar permissão
    if (req.user.id !== parseInt(id)) {
      return ResponseHandler.forbidden(res, 'Você só pode cadastrar sua própria biometria facial');
    }

    if (!foto_base64) {
      return ResponseHandler.validationError(res, ['Foto em base64 é obrigatória']);
    }

    // Verificar se usuário existe
    const usuario = await database.get('SELECT id, nome_completo FROM usuarios WHERE id = ?', [id]);
    if (!usuario) {
      return ResponseHandler.notFound(res, 'Usuário não encontrado');
    }

    // Cadastrar face usando Face++ API
    console.log('📸 Processando face com Face++ API...');
    const resultadoFace = await cadastrarFaceInicial(foto_base64);

    if (!resultadoFace.success) {
      return ResponseHandler.validationError(res, [resultadoFace.message || 'Erro ao processar face']);
    }

    // Verificar se já tem biometria
    const biometriaExistente = await database.get(
      'SELECT id FROM biometria_usuario WHERE usuario_id = ?',
      [id]
    );

    if (biometriaExistente) {
      // Atualizar biometria existente
      await database.run(
        'UPDATE biometria_usuario SET face_token = ?, dados_biometria = ?, data_atualizacao = CURRENT_TIMESTAMP WHERE usuario_id = ?',
        [resultadoFace.face_token, JSON.stringify(resultadoFace), id]
      );
      
      return ResponseHandler.success(res, {
        face_token: resultadoFace.face_token,
        face_rectangle: resultadoFace.face_rectangle
      }, 'Biometria facial atualizada com sucesso');
    } else {
      // Criar nova biometria
      const result = await database.run(
        'INSERT INTO biometria_usuario (usuario_id, face_token, dados_biometria) VALUES (?, ?, ?)',
        [id, resultadoFace.face_token, JSON.stringify(resultadoFace)]
      );
      
      return ResponseHandler.created(res, { 
        id: result.id,
        face_token: resultadoFace.face_token,
        face_rectangle: resultadoFace.face_rectangle
      }, 'Biometria facial cadastrada com sucesso');
    }

  } catch (error) {
    console.error('Erro ao cadastrar biometria facial:', error);
    return ResponseHandler.error(res, 'Erro ao cadastrar biometria facial');
  }
}

/**
 * Autenticar usuário por reconhecimento facial
 */
async function autenticarBiometria(req, res) {
  try {
    const { id } = req.params;
    const { foto_base64 } = req.body;

    if (!foto_base64) {
      return ResponseHandler.validationError(res, ['Foto em base64 é obrigatória']);
    }

    // Buscar biometria cadastrada
    const biometria = await database.get(
      'SELECT id, face_token, usuario_id FROM biometria_usuario WHERE usuario_id = ?',
      [id]
    );

    if (!biometria) {
      return ResponseHandler.notFound(res, 'Biometria facial não cadastrada para este usuário');
    }

    // Autenticar usando Face++
    console.log('🔐 Autenticando face com Face++ API...');
    const resultadoAuth = await autenticarPorFace(biometria.face_token, foto_base64);

    if (!resultadoAuth.success) {
      return ResponseHandler.error(res, resultadoAuth.message || 'Erro ao autenticar face');
    }

    // Buscar dados do usuário para e-mail
    const usuario = await database.get(
      'SELECT id, nome_completo, email FROM usuarios WHERE id = ?',
      [id]
    );

    const dataHora = new Date().toLocaleString('pt-BR', { timeZone: 'America/Sao_Paulo' });
    const ip = req.ip || 'Desconhecido';
    const dispositivo = req.get('user-agent') || 'Desconhecido';

    if (resultadoAuth.autenticado) {
      // Registrar log de acesso bem-sucedido
      await database.run(
        `INSERT INTO logs_acesso (usuario_id, ip_origem, dispositivo, status_login, tipo_autenticacao)
         VALUES (?, ?, ?, ?, ?)`,
        [id, ip, dispositivo, 'Sucesso', 'Biometria Facial']
      );

      // Enviar e-mail de notificação de sucesso
      const mensagemEmail = `Olá ${usuario.nome_completo},\n\n` +
        `✅ LOGIN BEM-SUCEDIDO POR RECONHECIMENTO FACIAL\n\n` +
        `Uma tentativa de login por reconhecimento facial foi realizada com SUCESSO na sua conta.\n\n` +
        `Detalhes do acesso:\n` +
        `• Data e hora: ${dataHora}\n` +
        `• IP de origem: ${ip}\n` +
        `• Dispositivo: ${dispositivo}\n` +
        `• Nível de confiança: ${resultadoAuth.confianca.toFixed(2)}%\n\n` +
        `Se você não reconhece este acesso, entre em contato imediatamente com o suporte.\n\n` +
        `Atenciosamente,\n` +
        `Sistema Guardião Mais`;

      enviarEmail(usuario.email, mensagemEmail).catch(err => {
        console.error('Erro ao enviar e-mail de login biométrico:', err);
      });

      return ResponseHandler.success(res, {
        autenticado: true,
        confianca: resultadoAuth.confianca,
        usuario_id: id
      }, 'Autenticação facial bem-sucedida');
    } else {
      // Registrar tentativa falha
      await database.run(
        `INSERT INTO logs_acesso (usuario_id, ip_origem, dispositivo, status_login, tipo_autenticacao)
         VALUES (?, ?, ?, ?, ?)`,
        [id, ip, dispositivo, 'Falha', 'Biometria Facial']
      );

      // Enviar e-mail de notificação de falha
      const mensagemEmail = `Olá ${usuario.nome_completo},\n\n` +
        `⚠️ TENTATIVA DE LOGIN FALHOU - RECONHECIMENTO FACIAL\n\n` +
        `Uma tentativa de login por reconhecimento facial FALHOU na sua conta.\n\n` +
        `Detalhes da tentativa:\n` +
        `• Data e hora: ${dataHora}\n` +
        `• IP de origem: ${ip}\n` +
        `• Dispositivo: ${dispositivo}\n` +
        `• Nível de confiança: ${resultadoAuth.confianca.toFixed(2)}%\n` +
        `• Motivo: Face não corresponde ao cadastro (confiança abaixo de 70%)\n\n` +
        `Se você não tentou fazer login, sua conta pode estar em risco. Recomendamos:\n` +
        `1. Alterar sua senha imediatamente\n` +
        `2. Verificar dispositivos conectados\n` +
        `3. Entrar em contato com o suporte\n\n` +
        `Atenciosamente,\n` +
        `Sistema Guardião Mais`;

      enviarEmail(usuario.email, mensagemEmail).catch(err => {
        console.error('Erro ao enviar e-mail de tentativa falha:', err);
      });

      return ResponseHandler.unauthorized(res, 'Face não corresponde ao usuário cadastrado');
    }

  } catch (error) {
    console.error('Erro ao autenticar biometria facial:', error);
    return ResponseHandler.error(res, 'Erro ao autenticar biometria facial');
  }
}

/**
 * Comparar duas fotos faciais
 */
async function compararFotos(req, res) {
  try {
    const { foto_base64_1, foto_base64_2 } = req.body;

    if (!foto_base64_1 || !foto_base64_2) {
      return ResponseHandler.validationError(res, ['Duas fotos em base64 são obrigatórias']);
    }

    // Detectar face na primeira foto
    console.log('📸 Detectando face 1...');
    const face1 = await detectarFace(foto_base64_1);
    
    if (!face1.success) {
      return ResponseHandler.validationError(res, [`Foto 1: ${face1.message}`]);
    }

    // Detectar face na segunda foto
    console.log('📸 Detectando face 2...');
    const face2 = await detectarFace(foto_base64_2);
    
    if (!face2.success) {
      return ResponseHandler.validationError(res, [`Foto 2: ${face2.message}`]);
    }

    // Comparar as faces
    console.log('🔍 Comparando faces...');
    const comparacao = await compararFaces(face1.face_token, face2.face_token);

    if (!comparacao.success) {
      return ResponseHandler.error(res, comparacao.message || 'Erro ao comparar faces');
    }

    return ResponseHandler.success(res, {
      mesma_pessoa: comparacao.mesma_pessoa,
      confianca: comparacao.confianca,
      thresholds: comparacao.thresholds,
      face1: {
        face_token: face1.face_token,
        face_rectangle: face1.face_rectangle
      },
      face2: {
        face_token: face2.face_token,
        face_rectangle: face2.face_rectangle
      }
    }, comparacao.mesma_pessoa ? 'As faces correspondem à mesma pessoa' : 'As faces não correspondem');

  } catch (error) {
    console.error('Erro ao comparar fotos:', error);
    return ResponseHandler.error(res, 'Erro ao comparar fotos');
  }
}

/**
 * Remover biometria facial do usuário
 */
async function removerBiometria(req, res) {
  try {
    const { id } = req.params;

    // Verificar permissão
    if (req.user.id !== parseInt(id)) {
      return ResponseHandler.forbidden(res, 'Você só pode remover sua própria biometria facial');
    }

    const biometria = await database.get(
      'SELECT id FROM biometria_usuario WHERE usuario_id = ?',
      [id]
    );

    if (!biometria) {
      return ResponseHandler.notFound(res, 'Biometria facial não encontrada');
    }

    await database.run('DELETE FROM biometria_usuario WHERE usuario_id = ?', [id]);

    return ResponseHandler.success(res, null, 'Biometria facial removida com sucesso');

  } catch (error) {
    console.error('Erro ao remover biometria facial:', error);
    return ResponseHandler.error(res, 'Erro ao remover biometria facial');
  }
}

/**
 * Listar usuários com perfil verificado
 */
async function listarUsuariosVerificados(req, res) {
  try {
    const { page = 1, limit = 20 } = req.query;
    const offset = (page - 1) * limit;

    const usuarios = await database.all(
      `SELECT u.id, u.nome_completo, u.email, u.celular, u.media_avaliacao,
              u.foto_perfil_id, u.data_cadastro
       FROM usuarios u
       WHERE u.perfil_verificado = 1
       ORDER BY u.media_avaliacao DESC, u.data_cadastro DESC
       LIMIT ? OFFSET ?`,
      [parseInt(limit), parseInt(offset)]
    );

    const { total } = await database.get(
      'SELECT COUNT(*) as total FROM usuarios WHERE perfil_verificado = 1'
    );

    return ResponseHandler.success(res, {
      usuarios,
      paginacao: {
        total,
        pagina_atual: parseInt(page),
        total_paginas: Math.ceil(total / limit),
        itens_por_pagina: parseInt(limit)
      }
    });

  } catch (error) {
    console.error('Erro ao listar usuários verificados:', error);
    return ResponseHandler.error(res, 'Erro ao listar usuários verificados');
  }
}

/**
 * Listar usuários com documentos pendentes de validação
 */
async function listarUsuariosPendentes(req, res) {
  try {
    const usuarios = await database.all(
      `SELECT DISTINCT u.id, u.nome_completo, u.email, u.celular, u.data_cadastro,
              COUNT(d.id) as total_documentos_pendentes
       FROM usuarios u
       INNER JOIN documentos_validacao d ON u.id = d.usuario_id
       WHERE d.status = 'Pendente' AND u.perfil_verificado = 0
       GROUP BY u.id
       ORDER BY u.data_cadastro ASC`
    );

    return ResponseHandler.success(res, {
      total: usuarios.length,
      usuarios
    });

  } catch (error) {
    console.error('Erro ao listar usuários pendentes:', error);
    return ResponseHandler.error(res, 'Erro ao listar usuários pendentes');
  }
}

module.exports = {
  verificarStatus,
  verificarBiometria,
  cadastrarBiometria,
  autenticarBiometria,
  compararFotos,
  removerBiometria,
  listarUsuariosVerificados,
  listarUsuariosPendentes
};

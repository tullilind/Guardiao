const bcrypt = require('bcrypt');
const database = require('../config/database');
const ResponseHandler = require('../utils/responseHandler');
const { validarEmail, validarTelefone } = require('../utils/validators');
const { enviarNotificacaoAtualizacao } = require('../utils/emailHelper');

/**
 * Obter usuário por ID
 */
async function obterPorId(req, res) {
  try {
    const { id } = req.params;

    const usuario = await database.get(
      `SELECT u.id, u.nome_completo, u.email, u.celular, u.cpf_cnpj, u.tipo_acesso,
              u.perfil_verificado, u.media_avaliacao, u.foto_perfil_id, u.data_cadastro,
              u.sexo, u.rua, u.cidade, u.estado, u.bairro, u.cep,
              a.conteudo_blob, a.mime_type
       FROM usuarios u
       LEFT JOIN arquivos_sistema a ON u.foto_perfil_id = a.id
       WHERE u.id = ?`,
      [id]
    );

    if (!usuario) {
      return ResponseHandler.notFound(res, 'Usuário não encontrado');
    }

    // Converter foto para base64 se existir
    let fotoBase64 = null;
    if (usuario.conteudo_blob) {
      fotoBase64 = `data:${usuario.mime_type};base64,${usuario.conteudo_blob.toString('base64')}`;
    }

    const dadosUsuario = {
      id: usuario.id,
      nome_completo: usuario.nome_completo,
      email: usuario.email,
      celular: usuario.celular,
      cpf_cnpj: usuario.cpf_cnpj,
      tipo_acesso: usuario.tipo_acesso,
      sexo: usuario.sexo,
      endereco: {
        rua: usuario.rua,
        cidade: usuario.cidade,
        estado: usuario.estado,
        bairro: usuario.bairro,
        cep: usuario.cep
      },
      perfil_verificado: usuario.perfil_verificado,
      media_avaliacao: usuario.media_avaliacao,
      foto_perfil: fotoBase64,
      data_cadastro: usuario.data_cadastro
    };

    return ResponseHandler.success(res, dadosUsuario);
  } catch (error) {
    console.error('Erro ao obter usuário:', error);
    return ResponseHandler.error(res, 'Erro ao obter usuário');
  }
}

/**
 * Listar todos os usuários (com paginação)
 */
async function listar(req, res) {
  try {
    const { page = 1, limit = 10, verificado } = req.query;
    const offset = (page - 1) * limit;

    let sql = `SELECT u.id, u.nome_completo, u.email, u.celular, u.cpf_cnpj, u.tipo_acesso, u.perfil_verificado,
                      u.media_avaliacao, u.data_cadastro, u.sexo, u.rua, u.cidade, u.estado, u.bairro, u.cep,
                      a.conteudo_blob, a.mime_type
               FROM usuarios u
               LEFT JOIN arquivos_sistema a ON u.foto_perfil_id = a.id`;
    let params = [];

    // Filtro por perfil verificado
    if (verificado !== undefined) {
      sql += ' WHERE u.perfil_verificado = ?';
      params.push(verificado === 'true' ? 1 : 0);
    }

    sql += ' ORDER BY u.data_cadastro DESC LIMIT ? OFFSET ?';
    params.push(parseInt(limit), parseInt(offset));

    const usuariosRaw = await database.all(sql, params);

    // Processar fotos em base64
    const usuarios = usuariosRaw.map(u => {
      let fotoBase64 = null;
      if (u.conteudo_blob) {
        fotoBase64 = `data:${u.mime_type};base64,${u.conteudo_blob.toString('base64')}`;
      }
      return {
        id: u.id,
        nome_completo: u.nome_completo,
        email: u.email,
        celular: u.celular,
        cpf_cnpj: u.cpf_cnpj,
        tipo_acesso: u.tipo_acesso,
        sexo: u.sexo,
        endereco: {
          rua: u.rua,
          cidade: u.cidade,
          estado: u.estado,
          bairro: u.bairro,
          cep: u.cep
        },
        perfil_verificado: u.perfil_verificado,
        media_avaliacao: u.media_avaliacao,
        foto_perfil: fotoBase64,
        data_cadastro: u.data_cadastro
      };
    });

    // Contar total
    let countSql = 'SELECT COUNT(*) as total FROM usuarios';
    if (verificado !== undefined) {
      countSql += ' WHERE perfil_verificado = ?';
    }
    const countParams = verificado !== undefined ? [verificado === 'true' ? 1 : 0] : [];
    const { total } = await database.get(countSql, countParams);

    return ResponseHandler.success(res, {
      usuarios,
      paginacao: {
        total,
        pagina_atual: parseInt(page),
        total_paginas: Math.ceil(total / limit),
        itens_por_pagina: parseInt(limit)
      }
    });
  } catch (error) {
    console.error('Erro ao listar usuários:', error);
    return ResponseHandler.error(res, 'Erro ao listar usuários');
  }
}

/**
 * Atualizar dados do usuário
 */
async function atualizar(req, res) {
  try {
    const { id } = req.params;
    const { nome_completo, email, celular, tipo_acesso, sexo, rua, cidade, estado, bairro, cep, foto_base64 } = req.body;

    // Verificar se usuário existe
    const usuario = await database.get('SELECT id FROM usuarios WHERE id = ?', [id]);
    if (!usuario) {
      return ResponseHandler.notFound(res, 'Usuário não encontrado');
    }

    // Verificar permissão (só pode atualizar próprio perfil)
    if (req.user.id !== parseInt(id)) {
      return ResponseHandler.forbidden(res, 'Você só pode atualizar seu próprio perfil');
    }

    const updates = [];
    const params = [];

    if (nome_completo) {
      updates.push('nome_completo = ?');
      params.push(nome_completo);
    }

    if (email) {
      if (!validarEmail(email)) {
        return ResponseHandler.validationError(res, ['Email inválido']);
      }
      // Verificar se email já existe
      const emailExiste = await database.get(
        'SELECT id FROM usuarios WHERE email = ? AND id != ?',
        [email.toLowerCase(), id]
      );
      if (emailExiste) {
        return ResponseHandler.conflict(res, 'Email já cadastrado');
      }
      updates.push('email = ?');
      params.push(email.toLowerCase());
    }

    if (celular) {
      if (!validarTelefone(celular)) {
        return ResponseHandler.validationError(res, ['Telefone inválido']);
      }
      // Verificar se telefone já existe
      const telefoneExiste = await database.get(
        'SELECT id FROM usuarios WHERE celular = ? AND id != ?',
        [celular.replace(/[^\d]/g, ''), id]
      );
      if (telefoneExiste) {
        return ResponseHandler.conflict(res, 'Telefone já cadastrado');
      }
      updates.push('celular = ?');
      params.push(celular.replace(/[^\d]/g, ''));
    }

    if (tipo_acesso) {
      updates.push('tipo_acesso = ?');
      params.push(tipo_acesso);
    }

    if (sexo) {
      const sexosValidos = ['Masculino', 'Feminino', 'Outro'];
      if (!sexosValidos.includes(sexo)) {
        return ResponseHandler.validationError(res, ['Sexo deve ser: Masculino, Feminino ou Outro']);
      }
      updates.push('sexo = ?');
      params.push(sexo);
    }

    if (rua !== undefined) {
      updates.push('rua = ?');
      params.push(rua || null);
    }

    if (cidade !== undefined) {
      updates.push('cidade = ?');
      params.push(cidade || null);
    }

    if (estado !== undefined) {
      updates.push('estado = ?');
      params.push(estado || null);
    }

    if (bairro !== undefined) {
      updates.push('bairro = ?');
      params.push(bairro || null);
    }

    if (cep !== undefined) {
      updates.push('cep = ?');
      params.push(cep ? cep.replace(/[^\d]/g, '') : null);
    }

    // Processar upload de foto se fornecida
    if (foto_base64) {
      try {
        const matches = foto_base64.match(/^data:(.+);base64,(.+)$/);
        if (!matches) {
          return ResponseHandler.validationError(res, ['Formato de imagem inválido']);
        }

        const mimeType = matches[1];
        const base64Data = matches[2];
        const buffer = Buffer.from(base64Data, 'base64');
        const tamanhoKb = buffer.length / 1024;

        if (tamanhoKb > 5120) {
          return ResponseHandler.validationError(res, ['Imagem muito grande. Máximo: 5MB']);
        }

        const tiposPermitidos = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];
        if (!tiposPermitidos.includes(mimeType)) {
          return ResponseHandler.validationError(res, ['Tipo de imagem não permitido']);
        }

        // Salvar nova foto
        const fotoResult = await database.run(
          `INSERT INTO arquivos_sistema (usuario_id, conteudo_blob, mime_type, tamanho_kb)
           VALUES (?, ?, ?, ?)`,
          [id, buffer, mimeType, tamanhoKb]
        );

        updates.push('foto_perfil_id = ?');
        params.push(fotoResult.id);
      } catch (err) {
        return ResponseHandler.validationError(res, ['Erro ao processar imagem']);
      }
    }

    if (updates.length === 0) {
      return ResponseHandler.validationError(res, ['Nenhum campo para atualizar']);
    }

    params.push(id);
    await database.run(
      `UPDATE usuarios SET ${updates.join(', ')} WHERE id = ?`,
      params
    );

    // Buscar usuário atualizado com foto
    const usuarioAtualizado = await database.get(
      `SELECT u.id, u.nome_completo, u.email, u.celular, u.cpf_cnpj, u.tipo_acesso,
              u.perfil_verificado, u.media_avaliacao, u.foto_perfil_id, u.data_cadastro,
              u.sexo, u.rua, u.cidade, u.estado, u.bairro, u.cep,
              a.conteudo_blob, a.mime_type
       FROM usuarios u
       LEFT JOIN arquivos_sistema a ON u.foto_perfil_id = a.id
       WHERE u.id = ?`,
      [id]
    );

    // Enviar e-mail de notificação de atualização
    const camposAlterados = [];
    if (nome_completo) camposAlterados.push('Nome');
    if (email) camposAlterados.push('E-mail');
    if (celular) camposAlterados.push('Celular');
    if (sexo) camposAlterados.push('Sexo');
    if (rua !== undefined || cidade !== undefined || estado !== undefined) camposAlterados.push('Endereço');
    if (foto_base64) camposAlterados.push('Foto de perfil');
    
    if (camposAlterados.length > 0) {
      try {
        await enviarNotificacaoAtualizacao(
          usuarioAtualizado.email, 
          usuarioAtualizado.nome_completo, 
          camposAlterados
        );
        console.log(`✅ E-mail de notificação enviado para ${usuarioAtualizado.email}`);
      } catch (emailError) {
        console.error('⚠️ Erro ao enviar e-mail de notificação:', emailError);
        // Não bloquear atualização se e-mail falhar
      }
    }

    // Converter foto para base64 se existir
    let fotoBase64 = null;
    if (usuarioAtualizado.conteudo_blob) {
      fotoBase64 = `data:${usuarioAtualizado.mime_type};base64,${usuarioAtualizado.conteudo_blob.toString('base64')}`;
    }

    const dadosUsuario = {
      id: usuarioAtualizado.id,
      nome_completo: usuarioAtualizado.nome_completo,
      email: usuarioAtualizado.email,
      celular: usuarioAtualizado.celular,
      cpf_cnpj: usuarioAtualizado.cpf_cnpj,
      tipo_acesso: usuarioAtualizado.tipo_acesso,
      sexo: usuarioAtualizado.sexo,
      endereco: {
        rua: usuarioAtualizado.rua,
        cidade: usuarioAtualizado.cidade,
        estado: usuarioAtualizado.estado,
        bairro: usuarioAtualizado.bairro,
        cep: usuarioAtualizado.cep
      },
      perfil_verificado: usuarioAtualizado.perfil_verificado,
      media_avaliacao: usuarioAtualizado.media_avaliacao,
      foto_perfil: fotoBase64,
      data_cadastro: usuarioAtualizado.data_cadastro
    };

    return ResponseHandler.success(res, dadosUsuario, 'Usuário atualizado com sucesso');
  } catch (error) {
    console.error('Erro ao atualizar usuário:', error);
    return ResponseHandler.error(res, 'Erro ao atualizar usuário');
  }
}

/**
 * Alterar senha
 */
async function alterarSenha(req, res) {
  try {
    const { id } = req.params;
    const { senha_atual, nova_senha } = req.body;

    // Verificar permissão
    if (req.user.id !== parseInt(id)) {
      return ResponseHandler.forbidden(res, 'Você só pode alterar sua própria senha');
    }

    if (!senha_atual || !nova_senha) {
      return ResponseHandler.validationError(res, ['Senha atual e nova senha são obrigatórias']);
    }

    if (nova_senha.length < 6) {
      return ResponseHandler.validationError(res, ['Nova senha deve ter no mínimo 6 caracteres']);
    }

    // Buscar usuário
    const usuario = await database.get(
      'SELECT id, senha_hash FROM usuarios WHERE id = ?',
      [id]
    );

    if (!usuario) {
      return ResponseHandler.notFound(res, 'Usuário não encontrado');
    }

    // Verificar senha atual
    const senhaValida = await bcrypt.compare(senha_atual, usuario.senha_hash);
    if (!senhaValida) {
      return ResponseHandler.unauthorized(res, 'Senha atual incorreta');
    }

    // Hash da nova senha
    const novaSenhaHash = await bcrypt.hash(nova_senha, 10);

    // Atualizar senha
    await database.run(
      'UPDATE usuarios SET senha_hash = ? WHERE id = ?',
      [novaSenhaHash, id]
    );

    return ResponseHandler.success(res, null, 'Senha alterada com sucesso');
  } catch (error) {
    console.error('Erro ao alterar senha:', error);
    return ResponseHandler.error(res, 'Erro ao alterar senha');
  }
}

/**
 * Deletar usuário
 */
async function deletar(req, res) {
  try {
    const { id } = req.params;

    // Verificar permissão
    if (req.user.id !== parseInt(id)) {
      return ResponseHandler.forbidden(res, 'Você só pode deletar seu próprio perfil');
    }

    // Verificar se usuário existe
    const usuario = await database.get('SELECT id FROM usuarios WHERE id = ?', [id]);
    if (!usuario) {
      return ResponseHandler.notFound(res, 'Usuário não encontrado');
    }

    // Deletar usuário (cascade vai deletar relacionados se configurado)
    await database.run('DELETE FROM usuarios WHERE id = ?', [id]);

    return ResponseHandler.success(res, null, 'Usuário deletado com sucesso');
  } catch (error) {
    console.error('Erro ao deletar usuário:', error);
    return ResponseHandler.error(res, 'Erro ao deletar usuário');
  }
}

module.exports = {
  obterPorId,
  listar,
  atualizar,
  alterarSenha,
  deletar
};

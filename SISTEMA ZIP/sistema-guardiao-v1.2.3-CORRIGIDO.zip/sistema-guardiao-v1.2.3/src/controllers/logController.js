const database = require('../config/database');
const ResponseHandler = require('../utils/responseHandler');

/**
 * Listar logs de acesso de um usuário
 */
async function listarPorUsuario(req, res) {
  try {
    const { usuario_id } = req.params;
    const { page = 1, limit = 20, status_login } = req.query;
    const offset = (page - 1) * limit;

    // Verificar permissão
    if (req.user.id !== parseInt(usuario_id)) {
      return ResponseHandler.forbidden(res, 'Você só pode ver seus próprios logs');
    }

    let sql = 'SELECT * FROM logs_acesso WHERE usuario_id = ?';
    let params = [usuario_id];

    if (status_login) {
      sql += ' AND status_login = ?';
      params.push(status_login);
    }

    sql += ' ORDER BY data_hora DESC LIMIT ? OFFSET ?';
    params.push(parseInt(limit), parseInt(offset));

    const logs = await database.all(sql, params);

    // Contar total
    let countSql = 'SELECT COUNT(*) as total FROM logs_acesso WHERE usuario_id = ?';
    let countParams = [usuario_id];
    if (status_login) {
      countSql += ' AND status_login = ?';
      countParams.push(status_login);
    }

    const { total } = await database.get(countSql, countParams);

    return ResponseHandler.success(res, {
      logs,
      paginacao: {
        total,
        pagina_atual: parseInt(page),
        total_paginas: Math.ceil(total / limit),
        itens_por_pagina: parseInt(limit)
      }
    });

  } catch (error) {
    console.error('Erro ao listar logs:', error);
    return ResponseHandler.error(res, 'Erro ao listar logs');
  }
}

/**
 * Listar todos os logs (admin)
 */
async function listarTodos(req, res) {
  try {
    const { page = 1, limit = 50, status_login, data_inicio, data_fim } = req.query;
    const offset = (page - 1) * limit;

    let sql = `SELECT l.*, u.nome_completo, u.email
               FROM logs_acesso l
               LEFT JOIN usuarios u ON l.usuario_id = u.id
               WHERE 1=1`;
    let params = [];

    if (status_login) {
      sql += ' AND l.status_login = ?';
      params.push(status_login);
    }

    if (data_inicio) {
      sql += ' AND DATE(l.data_hora) >= DATE(?)';
      params.push(data_inicio);
    }

    if (data_fim) {
      sql += ' AND DATE(l.data_hora) <= DATE(?)';
      params.push(data_fim);
    }

    sql += ' ORDER BY l.data_hora DESC LIMIT ? OFFSET ?';
    params.push(parseInt(limit), parseInt(offset));

    const logs = await database.all(sql, params);

    // Contar total
    let countSql = 'SELECT COUNT(*) as total FROM logs_acesso WHERE 1=1';
    let countParams = [];
    if (status_login) {
      countSql += ' AND status_login = ?';
      countParams.push(status_login);
    }
    if (data_inicio) {
      countSql += ' AND DATE(data_hora) >= DATE(?)';
      countParams.push(data_inicio);
    }
    if (data_fim) {
      countSql += ' AND DATE(data_hora) <= DATE(?)';
      countParams.push(data_fim);
    }

    const { total } = await database.get(countSql, countParams);

    return ResponseHandler.success(res, {
      logs,
      paginacao: {
        total,
        pagina_atual: parseInt(page),
        total_paginas: Math.ceil(total / limit),
        itens_por_pagina: parseInt(limit)
      }
    });

  } catch (error) {
    console.error('Erro ao listar todos os logs:', error);
    return ResponseHandler.error(res, 'Erro ao listar logs');
  }
}

/**
 * Obter estatísticas de acesso
 */
async function obterEstatisticas(req, res) {
  try {
    const { usuario_id } = req.query;

    let whereClause = '';
    let params = [];

    if (usuario_id) {
      whereClause = 'WHERE usuario_id = ?';
      params.push(usuario_id);
    }

    const stats = await database.get(
      `SELECT 
        COUNT(*) as total_acessos,
        SUM(CASE WHEN status_login = 'Sucesso' THEN 1 ELSE 0 END) as acessos_sucesso,
        SUM(CASE WHEN status_login LIKE 'Falha%' THEN 1 ELSE 0 END) as acessos_falha
       FROM logs_acesso ${whereClause}`,
      params
    );

    // Últimos acessos
    const ultimosAcessos = await database.all(
      `SELECT * FROM logs_acesso ${whereClause}
       ORDER BY data_hora DESC LIMIT 5`,
      params
    );

    return ResponseHandler.success(res, {
      estatisticas: stats,
      ultimos_acessos: ultimosAcessos
    });

  } catch (error) {
    console.error('Erro ao obter estatísticas:', error);
    return ResponseHandler.error(res, 'Erro ao obter estatísticas');
  }
}

/**
 * Obter último acesso do usuário
 */
async function obterUltimoAcesso(req, res) {
  try {
    const { usuario_id } = req.params;

    const ultimoAcesso = await database.get(
      `SELECT * FROM logs_acesso
       WHERE usuario_id = ? AND status_login = 'Sucesso'
       ORDER BY data_hora DESC LIMIT 1`,
      [usuario_id]
    );

    if (!ultimoAcesso) {
      return ResponseHandler.notFound(res, 'Nenhum acesso registrado');
    }

    return ResponseHandler.success(res, ultimoAcesso);

  } catch (error) {
    console.error('Erro ao obter último acesso:', error);
    return ResponseHandler.error(res, 'Erro ao obter último acesso');
  }
}

/**
 * Limpar logs antigos
 */
async function limparLogsAntigos(req, res) {
  try {
    const { dias = 90 } = req.body;

    const result = await database.run(
      `DELETE FROM logs_acesso 
       WHERE data_hora < datetime('now', '-' || ? || ' days')`,
      [dias]
    );

    return ResponseHandler.success(res, {
      deletados: result.changes
    }, `Logs com mais de ${dias} dias foram deletados`);

  } catch (error) {
    console.error('Erro ao limpar logs:', error);
    return ResponseHandler.error(res, 'Erro ao limpar logs');
  }
}

module.exports = {
  listarPorUsuario,
  listarTodos,
  obterEstatisticas,
  obterUltimoAcesso,
  limparLogsAntigos
};

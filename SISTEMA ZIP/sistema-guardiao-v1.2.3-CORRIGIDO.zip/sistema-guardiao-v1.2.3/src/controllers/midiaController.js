const database = require('../config/database');
const ResponseHandler = require('../utils/responseHandler');
const sharp = require('sharp');
const CryptoJS = require('crypto-js');

/**
 * Upload de múltiplos arquivos
 */
async function uploadMultiplo(req, res) {
  try {
    const userId = req.userId;
    const { latitude, longitude, endereco_completo } = req.body;
    const files = req.files;

    if (!files || files.length === 0) {
      return ResponseHandler.validationError(res, ['Nenhum arquivo foi enviado']);
    }

    if (files.length > 10) {
      return ResponseHandler.validationError(res, ['Máximo 10 arquivos por vez']);
    }

    const uploadados = [];
    const erros = [];

    for (const file of files) {
      try {
        // Validar tamanho (máximo 10MB por arquivo)
        if (file.size > 10 * 1024 * 1024) {
          erros.push(`${file.originalname}: Arquivo muito grande (máximo 10MB)`);
          continue;
        }

        // Determinar tipo de mídia
        let tipoMidia = 'arquivo';
        if (file.mimetype.startsWith('image/')) {
          tipoMidia = 'imagem';
        } else if (file.mimetype === 'application/pdf') {
          tipoMidia = 'documento_pdf';
        }

        // Comprimir imagens automaticamente
        let conteudo = file.buffer;
        if (file.mimetype.startsWith('image/')) {
          conteudo = await sharp(file.buffer)
            .resize(1920, 1080, {
              fit: 'inside',
              withoutEnlargement: true
            })
            .webp({ quality: 80 })
            .toBuffer();
        }

        const tamanhoKb = conteudo.length / 1024;

        // Salvar arquivo
        const result = await database.run(
          `INSERT INTO midia_usuarios (usuario_id, tipo_midia, nome_arquivo, conteudo_blob, mime_type, tamanho_kb, latitude, longitude, endereco_completo)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [
            userId,
            tipoMidia,
            file.originalname,
            conteudo,
            file.mimetype,
            tamanhoKb,
            latitude || null,
            longitude || null,
            endereco_completo || null
          ]
        );

        uploadados.push({
          id: result.id,
          nome_arquivo: file.originalname,
          tipo_midia: tipoMidia,
          tamanho_kb: tamanhoKb.toFixed(2),
          mime_type: file.mimetype
        });

      } catch (err) {
        erros.push(`${file.originalname}: ${err.message}`);
      }
    }

    return ResponseHandler.success(res, {
      uploadados,
      total_uploadados: uploadados.length,
      total_erros: erros.length,
      erros: erros.length > 0 ? erros : null
    }, `${uploadados.length} arquivo(s) enviado(s) com sucesso`);

  } catch (error) {
    console.error('Erro ao fazer upload múltiplo:', error);
    return ResponseHandler.serverError(res, 'Erro ao fazer upload múltiplo');
  }
}

/**
 * Obter galeria de fotos do usuário
 */
async function obterGaleria(req, res) {
  try {
    const userId = req.userId;
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 20;
    const offset = (page - 1) * limit;
    const tipoFiltro = req.query.tipo || null;

    let query = 'SELECT id, tipo_midia, nome_arquivo, mime_type, tamanho_kb, latitude, longitude, data_upload FROM midia_usuarios WHERE usuario_id = ?';
    let params = [userId];

    if (tipoFiltro) {
      query += ' AND tipo_midia = ?';
      params.push(tipoFiltro);
    }

    query += ' ORDER BY data_upload DESC LIMIT ? OFFSET ?';
    params.push(limit, offset);

    const arquivos = await database.all(query, params);

    // Contar total
    let countQuery = 'SELECT COUNT(*) as total FROM midia_usuarios WHERE usuario_id = ?';
    let countParams = [userId];
    if (tipoFiltro) {
      countQuery += ' AND tipo_midia = ?';
      countParams.push(tipoFiltro);
    }

    const countResult = await database.get(countQuery, countParams);
    const total = countResult.total;

    // Formatar resposta
    const galeriaFormatada = arquivos.map(arquivo => ({
      id: arquivo.id,
      nome_arquivo: arquivo.nome_arquivo,
      tipo_midia: arquivo.tipo_midia,
      mime_type: arquivo.mime_type,
      tamanho_kb: arquivo.tamanho_kb,
      localizacao: {
        latitude: arquivo.latitude,
        longitude: arquivo.longitude
      },
      data_upload: arquivo.data_upload
    }));

    return ResponseHandler.success(res, {
      arquivos: galeriaFormatada,
      paginacao: {
        total,
        pagina_atual: page,
        total_paginas: Math.ceil(total / limit),
        itens_por_pagina: limit
      }
    }, 'Galeria obtida com sucesso');

  } catch (error) {
    console.error('Erro ao obter galeria:', error);
    return ResponseHandler.serverError(res, 'Erro ao obter galeria');
  }
}

/**
 * Deletar arquivo da galeria
 */
async function deletarArquivo(req, res) {
  try {
    const userId = req.userId;
    const { arquivoId } = req.params;

    // Verificar se arquivo pertence ao usuário
    const arquivo = await database.get(
      'SELECT id, usuario_id FROM midia_usuarios WHERE id = ?',
      [arquivoId]
    );

    if (!arquivo) {
      return ResponseHandler.notFound(res, 'Arquivo não encontrado');
    }

    if (arquivo.usuario_id !== userId) {
      return ResponseHandler.unauthorized(res, 'Você não tem permissão para deletar este arquivo');
    }

    // Deletar arquivo
    await database.run('DELETE FROM midia_usuarios WHERE id = ?', [arquivoId]);

    return ResponseHandler.success(res, null, 'Arquivo deletado com sucesso');

  } catch (error) {
    console.error('Erro ao deletar arquivo:', error);
    return ResponseHandler.serverError(res, 'Erro ao deletar arquivo');
  }
}

/**
 * Assinar documento digitalmente
 */
async function assinarDocumento(req, res) {
  try {
    const userId = req.userId;
    const { arquivoId, chave_privada } = req.body;

    if (!arquivoId || !chave_privada) {
      return ResponseHandler.validationError(res, ['ID do arquivo e chave privada são obrigatórios']);
    }

    // Buscar arquivo
    const arquivo = await database.get(
      'SELECT id, usuario_id, conteudo_blob FROM midia_usuarios WHERE id = ?',
      [arquivoId]
    );

    if (!arquivo) {
      return ResponseHandler.notFound(res, 'Arquivo não encontrado');
    }

    if (arquivo.usuario_id !== userId) {
      return ResponseHandler.unauthorized(res, 'Você não tem permissão para assinar este arquivo');
    }

    // Gerar assinatura digital
    const conteudoHash = CryptoJS.SHA256(arquivo.conteudo_blob.toString()).toString();
    const assinatura = CryptoJS.HmacSHA256(conteudoHash, chave_privada).toString();

    // Salvar assinatura em nova tabela
    const resultAssinatura = await database.run(
      `INSERT INTO assinaturas_digitais (arquivo_id, usuario_id, assinatura_hash, data_assinatura)
       VALUES (?, ?, ?, CURRENT_TIMESTAMP)`,
      [arquivoId, userId, assinatura]
    );

    return ResponseHandler.success(res, {
      arquivo_id: arquivoId,
      assinatura_id: resultAssinatura.id,
      assinatura_hash: assinatura,
      data_assinatura: new Date().toISOString()
    }, 'Documento assinado com sucesso');

  } catch (error) {
    console.error('Erro ao assinar documento:', error);
    return ResponseHandler.serverError(res, 'Erro ao assinar documento');
  }
}

/**
 * Verificar assinatura digital
 */
async function verificarAssinatura(req, res) {
  try {
    const { arquivoId, assinatura } = req.body;

    if (!arquivoId || !assinatura) {
      return ResponseHandler.validationError(res, ['ID do arquivo e assinatura são obrigatórios']);
    }

    // Buscar arquivo
    const arquivo = await database.get(
      'SELECT conteudo_blob FROM midia_usuarios WHERE id = ?',
      [arquivoId]
    );

    if (!arquivo) {
      return ResponseHandler.notFound(res, 'Arquivo não encontrado');
    }

    // Buscar assinatura
    const assinaturaBD = await database.get(
      'SELECT assinatura_hash FROM assinaturas_digitais WHERE arquivo_id = ? ORDER BY data_assinatura DESC LIMIT 1',
      [arquivoId]
    );

    if (!assinaturaBD) {
      return ResponseHandler.notFound(res, 'Assinatura não encontrada');
    }

    // Verificar se assinatura é válida
    const valida = assinaturaBD.assinatura_hash === assinatura;

    return ResponseHandler.success(res, {
      arquivo_id: arquivoId,
      assinatura_valida: valida,
      assinatura_esperada: assinaturaBD.assinatura_hash,
      assinatura_fornecida: assinatura
    }, valida ? 'Assinatura válida' : 'Assinatura inválida');

  } catch (error) {
    console.error('Erro ao verificar assinatura:', error);
    return ResponseHandler.serverError(res, 'Erro ao verificar assinatura');
  }
}

module.exports = {
  uploadMultiplo,
  obterGaleria,
  deletarArquivo,
  assinarDocumento,
  verificarAssinatura
};

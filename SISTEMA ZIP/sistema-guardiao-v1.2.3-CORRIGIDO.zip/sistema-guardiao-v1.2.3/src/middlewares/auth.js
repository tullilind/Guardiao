const jwt = require('jsonwebtoken');
const crypto = require('crypto');
const { jwtSecret } = require('../config/auth');
const ResponseHandler = require('../utils/responseHandler');
const database = require('../config/database');

/**
 * Middleware para verificar autenticação JWT
 */
async function authenticateToken(req, res, next) {
  try {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1]; // Bearer TOKEN

    if (!token) {
      return ResponseHandler.unauthorized(res, 'Token não fornecido');
    }

    // Verificar token JWT com Promise
    jwt.verify(token, jwtSecret, async (err, decoded) => {
      if (err) {
        return ResponseHandler.unauthorized(res, 'Token inválido ou expirado');
      }

      try {
        // Verificar se o usuário existe e se o token é válido
        const usuario = await database.get(
          'SELECT id, nome_completo, email, cpf_cnpj, guardiao_token FROM usuarios WHERE id = ?',
          [decoded.userId]
        );

        if (!usuario) {
          return ResponseHandler.unauthorized(res, 'Usuário não encontrado');
        }

        // Verificar se o guardiao_token corresponde com proteção contra timing attacks
        if (!usuario.guardiao_token || !token) {
          return ResponseHandler.unauthorized(res, 'Sessão inválida. Faça login novamente');
        }

        // Usar comparação segura para evitar timing attacks
        const tokenMatch = crypto.timingSafeEqual(
          Buffer.from(usuario.guardiao_token),
          Buffer.from(token)
        );

        if (!tokenMatch) {
          return ResponseHandler.unauthorized(res, 'Sessão inválida. Faça login novamente');
        }

        // Adicionar dados do usuário na requisição
        req.user = {
          id: usuario.id,
          nome_completo: usuario.nome_completo,
          email: usuario.email,
          cpf_cnpj: usuario.cpf_cnpj
        };

        next();
      } catch (error) {
        console.error('Erro ao verificar token:', error);
        return ResponseHandler.unauthorized(res, 'Erro ao verificar autenticação');
      }
    });
  } catch (error) {
    console.error('Erro no middleware de autenticação:', error);
    return ResponseHandler.error(res, 'Erro ao verificar autenticação');
  }
}

/**
 * Middleware para verificar autenticação de admin (módulo backup)
 */
async function authenticateAdmin(req, res, next) {
  try {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (!token) {
      return ResponseHandler.unauthorized(res, 'Token de administrador não fornecido');
    }

    jwt.verify(token, jwtSecret, async (err, decoded) => {
      if (err) {
        return ResponseHandler.unauthorized(res, 'Token de administrador inválido');
      }

      if (!decoded.isAdmin) {
        return ResponseHandler.forbidden(res, 'Acesso restrito a administradores');
      }

      req.admin = {
        id: decoded.adminId,
        nome_usuario: decoded.nome_usuario
      };

      next();
    });
  } catch (error) {
    console.error('Erro no middleware de autenticação admin:', error);
    return ResponseHandler.error(res, 'Erro ao verificar autenticação de administrador');
  }
}

module.exports = {
  authenticateToken,
  authenticateAdmin
};

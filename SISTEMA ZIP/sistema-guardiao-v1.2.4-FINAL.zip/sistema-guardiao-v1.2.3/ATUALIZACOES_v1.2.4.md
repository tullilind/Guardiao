# 📋 Atualizações Sistema Guardião v1.2.4

## 🔧 Correções Implementadas

### 1. ✅ Erro 500 na API de Biometria Facial - CORRIGIDO

**Problema:** A API `/api/verificacao/usuario/:id/biometria` retornava erro 500 porque a tabela `biometria_usuario` não existia no banco de dados.

**Solução:**
- Adicionada a tabela `biometria_usuario` no script de inicialização do banco de dados
- Adicionado índice para melhorar performance nas consultas
- Adicionada coluna `tipo_autenticacao` na tabela `logs_acesso` para registrar autenticações por biometria facial

**Estrutura da tabela:**
```sql
CREATE TABLE IF NOT EXISTS biometria_usuario (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  usuario_id INTEGER NOT NULL UNIQUE,
  face_token VARCHAR(500) NOT NULL,
  dados_biometria TEXT,
  data_cadastro DATETIME DEFAULT CURRENT_TIMESTAMP,
  data_atualizacao DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
)
```

---

### 2. ✅ Upload Múltiplo de Documentos - IMPLEMENTADO

**Funcionalidade:** Agora é possível enviar múltiplos documentos em uma única requisição.

**Endpoint:** `POST /api/documentos`

**Formato da Requisição (Upload Múltiplo):**
```json
{
  "arquivos": [
    {
      "arquivo_id": 1,
      "tipo_documento": "CPF"
    },
    {
      "arquivo_id": 2,
      "tipo_documento": "RG"
    },
    {
      "arquivo_id": 3,
      "tipo_documento": "CNH"
    }
  ]
}
```

**Formato da Requisição (Upload Único - Compatibilidade):**
```json
{
  "arquivo_id": 1,
  "tipo_documento": "CPF"
}
```

**Resposta (Upload Múltiplo):**
```json
{
  "success": true,
  "message": "3 documento(s) enviado(s) para validação",
  "data": {
    "total": 3,
    "documentos": [
      {
        "id": 1,
        "tipo_documento": "CPF",
        "arquivo_id": 1
      },
      {
        "id": 2,
        "tipo_documento": "RG",
        "arquivo_id": 2
      },
      {
        "id": 3,
        "tipo_documento": "CNH",
        "arquivo_id": 3
      }
    ]
  },
  "timestamp": "2024-01-15T13:00:00.000Z"
}
```

**Validações:**
- Verifica se cada arquivo existe no banco de dados
- Verifica se o arquivo pertence ao usuário autenticado
- Ignora arquivos inválidos e continua processando os válidos
- Cria notificação única informando o total de documentos enviados

---

### 3. ✅ Notificação por E-mail na Aprovação/Rejeição - IMPLEMENTADO

**Funcionalidade:** Sistema envia e-mail automático quando um documento é aprovado ou rejeitado.

**E-mail de Documento Aprovado:**
```
Olá [Nome do Usuário],

✅ DOCUMENTO APROVADO

Seu documento foi analisado e aprovado com sucesso!

Detalhes:
• Tipo de documento: CPF
• Data de aprovação: 23/11/2025 16:30:00
• ID do documento: #1

Continue enviando seus documentos para completar a verificação do seu perfil.

Atenciosamente,
Sistema Guardião Mais
```

**E-mail de Documento Rejeitado:**
```
Olá [Nome do Usuário],

❌ DOCUMENTO REJEITADO

Infelizmente, seu documento não foi aprovado na análise.

Detalhes:
• Tipo de documento: CPF
• Data de rejeição: 23/11/2025 16:30:00
• ID do documento: #1
• Motivo: Documento ilegível ou com baixa qualidade

Por favor, corrija o problema e envie o documento novamente.

Se tiver dúvidas, entre em contato com o suporte.

Atenciosamente,
Sistema Guardião Mais
```

**E-mail de Perfil Verificado (quando todos os documentos são aprovados):**
```
Olá [Nome do Usuário],

🎉 PARABÉNS! SEU PERFIL FOI VERIFICADO COM SUCESSO

Todos os seus documentos foram analisados e aprovados.
Agora você tem acesso completo a todas as funcionalidades do Sistema Guardião Mais.

O que você pode fazer agora:
• Contratar e oferecer serviços
• Realizar pagamentos e receber valores
• Acessar recursos premium
• Compartilhar sua localização em tempo real

Obrigado por confiar no Sistema Guardião Mais!

Atenciosamente,
Equipe Guardião Mais
```

---

## 🚀 Como Atualizar o Sistema

### Passo 1: Reinicializar o Banco de Dados

```bash
# Navegar até a pasta do projeto
cd sistema-guardiao-v1.2.3

# Remover banco de dados antigo (CUIDADO: isso apaga todos os dados)
rm -f database/database.db

# Criar novo banco de dados com as tabelas atualizadas
npm run init-db
```

### Passo 2: Iniciar o Servidor

```bash
# Iniciar o servidor
npm start
```

---

## 📝 Notas Importantes

1. **Compatibilidade:** O sistema mantém compatibilidade com upload único de documentos
2. **Validação:** Todos os arquivos são validados antes de serem processados
3. **Segurança:** Apenas o proprietário do arquivo pode enviá-lo como documento
4. **E-mails:** Os e-mails são enviados de forma assíncrona e não bloqueiam a resposta da API
5. **Logs:** Todas as autenticações por biometria facial são registradas na tabela `logs_acesso`

---

## 🔍 APIs Atualizadas

### Verificação de Biometria
- ✅ `GET /api/verificacao/usuario/:id/biometria` - Agora funciona corretamente
- ✅ `POST /api/verificacao/usuario/:id/biometria` - Cadastrar biometria facial
- ✅ `POST /api/verificacao/usuario/:id/biometria/autenticar` - Autenticar por biometria
- ✅ `DELETE /api/verificacao/usuario/:id/biometria` - Remover biometria

### Documentos
- ✅ `POST /api/documentos` - Suporta upload múltiplo e único
- ✅ `PUT /api/documentos/:id/status` - Envia e-mail ao atualizar status

---

## 📧 Configuração de E-mail

O sistema utiliza a API do Google Apps Script para envio de e-mails.

**URL da API:** https://script.google.com/macros/s/AKfycbwN8jiiMzm0Win5XRYUqmE11CXEiuoMzeROmYPz8MxcvutXBhGtr-LxjtXB18stlAD_jQ/exec

**Parâmetros:**
- `email`: E-mail do destinatário
- `mensagem`: Conteúdo do e-mail

---

## 🐛 Bugs Corrigidos

1. ✅ Erro 500 na verificação de biometria facial
2. ✅ Falta de suporte para upload múltiplo de documentos
3. ✅ Falta de notificação por e-mail na aprovação/rejeição
4. ✅ Referência incorreta à tabela `arquivos_sistema` (atualizada para `midia_usuarios`)
5. ✅ Falta de coluna `tipo_autenticacao` na tabela `logs_acesso`

---

## 📊 Melhorias de Performance

1. ✅ Adicionados índices no banco de dados para consultas mais rápidas
2. ✅ E-mails enviados de forma assíncrona (não bloqueiam a API)
3. ✅ Validação otimizada de múltiplos arquivos

---

## 🔒 Segurança

1. ✅ Validação de propriedade de arquivos antes do upload
2. ✅ Logs de autenticação por biometria facial
3. ✅ E-mails de notificação de tentativas de login (sucesso e falha)

---

**Versão:** 1.2.4  
**Data:** 23/11/2025  
**Desenvolvedor:** Sistema Guardião Mais

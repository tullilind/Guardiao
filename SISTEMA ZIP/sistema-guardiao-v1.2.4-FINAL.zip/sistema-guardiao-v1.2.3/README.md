# Sistema de Gerenciamento de Serviços - API REST

Sistema completo de gerenciamento de serviços com Node.js, SQLite e autenticação JWT.

## 📋 Características

- ✅ **Autenticação completa** com CPF/CNPJ e senha
- ✅ **Recuperação de senha** com token temporário
- ✅ **Sistema de avaliações** com cálculo automático de média
- ✅ **Ponto eletrônico** com GPS
- ✅ **Upload de arquivos** (BLOB no banco de dados)
- ✅ **Validação de documentos** (CNH, RG, Antecedentes)
- ✅ **Sistema de notificações**
- ✅ **Backup e restauração** com interface web
- ✅ **Logs de acesso** para auditoria
- ✅ **Biometria** para usuários
- ✅ **APIs completas** para todas as operações

## 🚀 Instalação e Execução

### 1. Instalar dependências (já incluídas no ZIP)

```bash
npm install
```

### 2. Inicializar banco de dados

```bash
npm run init-db
```

### 3. Iniciar servidor

```bash
npm start
```

O servidor estará disponível em: **http://localhost:3005**

## 📡 Endpoints da API

### Autenticação (`/api/auth`)

| Método | Endpoint | Descrição |
|--------|----------|-----------|
| POST | `/register` | Cadastrar novo usuário |
| POST | `/login` | Login com CPF e senha |
| POST | `/recuperar-senha` | Solicitar recuperação de senha |
| POST | `/redefinir-senha` | Redefinir senha com token |
| POST | `/logout` | Fazer logout |
| GET | `/me` | Obter dados do usuário logado |

### Usuários (`/api/usuarios`)

| Método | Endpoint | Descrição |
|--------|----------|-----------|
| GET | `/` | Listar todos os usuários |
| GET | `/:id` | Obter usuário por ID |
| PUT | `/:id` | Atualizar dados do usuário |
| PUT | `/:id/senha` | Alterar senha |
| DELETE | `/:id` | Deletar usuário |

### Prestadores (`/api/prestadores`)

| Método | Endpoint | Descrição |
|--------|----------|-----------|
| GET | `/` | Listar prestadores (com filtros) |
| GET | `/verificados` | Listar apenas verificados |
| GET | `/buscar` | Buscar prestadores |
| GET | `/:id` | Obter prestador por ID |
| GET | `/:id/servicos` | Listar serviços do prestador |
| GET | `/:id/estatisticas` | Estatísticas do prestador |

### Verificação (`/api/verificacao`)

| Método | Endpoint | Descrição |
|--------|----------|-----------|
| GET | `/usuarios/verificados` | Listar usuários verificados |
| GET | `/usuarios/pendentes` | Listar usuários pendentes |
| GET | `/usuario/:id/status` | Status de verificação |
| GET | `/usuario/:id/biometria` | Verificar biometria |
| POST | `/usuario/:id/biometria` | Cadastrar biometria |
| DELETE | `/usuario/:id/biometria` | Remover biometria |

### Documentos (`/api/documentos`)

| Método | Endpoint | Descrição |
|--------|----------|-----------|
| POST | `/` | Criar documento |
| GET | `/pendentes` | Listar pendentes |
| GET | `/aprovados` | Listar aprovados |
| GET | `/rejeitados` | Listar rejeitados |
| GET | `/estatisticas` | Estatísticas |
| GET | `/usuario/:usuario_id` | Documentos do usuário |
| GET | `/:id` | Obter documento |
| PUT | `/:id/status` | Atualizar status |

### Arquivos (`/api/arquivos`)

| Método | Endpoint | Descrição |
|--------|----------|-----------|
| POST | `/upload` | Upload de arquivo |
| GET | `/` | Listar arquivos |
| GET | `/estatisticas` | Estatísticas de armazenamento |
| GET | `/:id/info` | Informações do arquivo |
| GET | `/:id/download` | Download do arquivo |
| GET | `/:id/visualizar` | Visualizar arquivo |
| DELETE | `/:id` | Deletar arquivo |

### Contratações (`/api/contratacoes`)

| Método | Endpoint | Descrição |
|--------|----------|-----------|
| POST | `/` | Criar contratação |
| GET | `/` | Listar todas (com filtros) |
| GET | `/prestador/:id_prestador` | Contratações do prestador |
| GET | `/solicitante/:id_solicitante` | Contratações do solicitante |
| GET | `/:id` | Obter contratação |
| PUT | `/:id` | Atualizar contratação |
| PUT | `/:id/status-servico` | Atualizar status do serviço |
| PUT | `/:id/status-pagamento` | Atualizar status do pagamento |

### Ponto Eletrônico (`/api/ponto`)

| Método | Endpoint | Descrição |
|--------|----------|-----------|
| POST | `/registrar` | Registrar ponto (entrada/saída) |
| GET | `/contratacao/:contratacao_id` | Registros da contratação |
| GET | `/contratacao/:contratacao_id/ultimo` | Último registro |
| GET | `/prestador/:id_prestador` | Registros do prestador |
| GET | `/prestador/:id_prestador/relatorio` | Relatório de horas |
| DELETE | `/:id` | Deletar registro |

### Notificações (`/api/notificacoes`)

| Método | Endpoint | Descrição |
|--------|----------|-----------|
| POST | `/` | Criar notificação |
| GET | `/usuario/:usuario_id` | Notificações do usuário |
| GET | `/nao-lidas` | Listar não lidas |
| GET | `/contagem` | Contagem de notificações |
| PUT | `/:id/marcar-lida` | Marcar como lida |
| PUT | `/marcar-todas-lidas` | Marcar todas como lidas |
| DELETE | `/:id` | Deletar notificação |
| DELETE | `/lidas/limpar` | Limpar lidas |

### Avaliações (`/api/avaliacoes`)

| Método | Endpoint | Descrição |
|--------|----------|-----------|
| POST | `/` | Criar avaliação |
| GET | `/usuario/:usuario_id` | Avaliações do usuário |
| GET | `/usuario/:usuario_id/feitas` | Avaliações feitas |
| GET | `/contratacao/:contratacao_id` | Avaliações da contratação |
| GET | `/top-prestadores` | Top prestadores |
| GET | `/:id` | Obter avaliação |
| PUT | `/:id` | Atualizar avaliação |
| DELETE | `/:id` | Deletar avaliação |

### Logs (`/api/logs`)

| Método | Endpoint | Descrição |
|--------|----------|-----------|
| GET | `/usuario/:usuario_id` | Logs do usuário |
| GET | `/usuario/:usuario_id/ultimo` | Último acesso |
| GET | `/todos` | Todos os logs |
| GET | `/estatisticas` | Estatísticas de acesso |
| POST | `/limpar` | Limpar logs antigos |

### Backup (`/api/backup`)

| Método | Endpoint | Descrição |
|--------|----------|-----------|
| POST | `/admin/login` | Login de admin |
| POST | `/admin/criar` | Criar admin |
| POST | `/criar` | Criar backup |
| GET | `/listar` | Listar backups |
| POST | `/restaurar` | Restaurar backup |
| GET | `/download/:nome_arquivo` | Download de backup |
| DELETE | `/:nome_arquivo` | Deletar backup |
| GET | `/estatisticas` | Estatísticas do sistema |

## 🔐 Autenticação

Todas as rotas (exceto login e registro) requerem autenticação via JWT.

### Como usar:

1. **Registrar usuário:**
```bash
POST /api/auth/register
{
  "nome_completo": "João Silva",
  "email": "joao@email.com",
  "celular": "11999999999",
  "senha": "senha123",
  "cpf_cnpj": "12345678901"
}
```

2. **Fazer login:**
```bash
POST /api/auth/login
{
  "cpf_cnpj": "12345678901",
  "senha": "senha123"
}
```

3. **Usar o token nas requisições:**
```
Authorization: Bearer SEU_TOKEN_AQUI
```

## 💾 Sistema de Backup

Acesse a interface web de backup em: **http://localhost:3005/backup-interface**

### Funcionalidades:

- ✅ Criar backups do banco de dados
- ✅ Listar backups disponíveis
- ✅ Restaurar backups
- ✅ Download de backups
- ✅ Deletar backups
- ✅ Visualizar estatísticas do sistema

### Primeiro acesso:

1. Acesse a interface de backup
2. Use o formulário de login para criar sua conta de administrador
3. O sistema criará automaticamente a conta no primeiro acesso

## 📊 Estrutura do Banco de Dados

### Tabelas:

1. **usuarios** - Dados dos usuários
2. **logs_acesso** - Logs de autenticação
3. **arquivos_sistema** - Arquivos em BLOB
4. **documentos_validacao** - Documentos para validação
5. **contratacoes_servico** - Ordens de serviço
6. **registro_ponto_os** - Ponto eletrônico
7. **notificacoes_usuario** - Notificações
8. **avaliacoes_servico** - Avaliações
9. **admin_backup** - Administradores de backup
10. **biometria_usuario** - Dados biométricos

## 🛠️ Tecnologias Utilizadas

- **Node.js** - Runtime JavaScript
- **Express** - Framework web
- **SQLite3** - Banco de dados
- **JWT** - Autenticação
- **Bcrypt** - Hash de senhas
- **Multer** - Upload de arquivos
- **Joi** - Validação de dados
- **CORS** - Cross-Origin Resource Sharing

## 📝 Variáveis de Ambiente

Arquivo `.env`:

```env
PORT=3005
NODE_ENV=development
DB_PATH=./database/database.db
JWT_SECRET=sua_chave_secreta_super_segura
JWT_EXPIRES_IN=7d
MAX_FILE_SIZE=10485760
```

## 🔄 Fluxo de Trabalho

### 1. Cadastro e Validação:
- Usuário se cadastra
- Envia documentos (CNH, RG, etc)
- Aguarda validação
- Perfil é marcado como verificado

### 2. Contratação de Serviço:
- Solicitante busca prestadores verificados
- Cria contratação
- Prestador recebe notificação
- Aceita o serviço

### 3. Execução:
- Prestador registra ponto de entrada
- Executa o serviço
- Registra ponto de saída
- Marca serviço como concluído

### 4. Avaliação:
- Solicitante avalia o prestador
- Média de avaliação é recalculada automaticamente
- Prestador pode ver suas avaliações

## 📦 Estrutura de Pastas

```
sistema-servicos/
├── src/
│   ├── config/          # Configurações (DB, Auth)
│   ├── controllers/     # Lógica de negócio
│   ├── middlewares/     # Middlewares (Auth, Errors)
│   ├── routes/          # Rotas da API
│   ├── utils/           # Utilitários
│   └── server.js        # Servidor principal
├── database/            # Banco de dados SQLite
│   └── backups/         # Backups do banco
├── public/              # Interface web de backup
├── package.json
├── .env
└── README.md
```

## 🚨 Segurança

- ✅ Senhas com hash bcrypt
- ✅ Tokens JWT com expiração
- ✅ Validação de CPF/CNPJ
- ✅ Proteção contra SQL Injection
- ✅ Logs de acesso
- ✅ Validação de permissões
- ✅ CORS configurado

## 📞 Suporte

Para dúvidas ou problemas, consulte a documentação ou entre em contato.

## 📄 Licença

MIT License

---

**Desenvolvido com ❤️ usando Node.js**

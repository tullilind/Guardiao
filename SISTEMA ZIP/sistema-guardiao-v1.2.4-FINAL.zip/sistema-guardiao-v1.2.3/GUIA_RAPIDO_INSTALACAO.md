# 🚀 Guia Rápido de Instalação - Sistema Atualizado

## 📦 O que foi atualizado?

✅ **Sistema de Backup Completo**
- Download de backup com token de administrador corrigido
- Nova funcionalidade de upload e restauração de backup externo

✅ **Sistema de Envio de E-mails**
- E-mails automáticos no cadastro de usuário
- E-mails de recuperação de senha
- Notificações de atualização de dados

✅ **Sistema de Reconhecimento Facial com Face++**
- Cadastro de biometria facial
- Autenticação por reconhecimento facial
- Comparação de fotos
- Verificação de biometria cadastrada

---

## 📋 Pré-requisitos

- Node.js 14+ instalado
- NPM ou Yarn
- Porta 3005 disponível (ou configurar outra no .env)

---

## 🔧 Instalação

### 1. Extrair o arquivo

```bash
unzip sistema-servicos-atualizado-20251123.zip
cd sistema-servicos-corrigido
```

### 2. Instalar dependências

```bash
npm install
```

**Novas dependências instaladas automaticamente:**
- `axios` - Para requisições HTTP (e-mail e Face++)
- `form-data` - Para upload de arquivos multipart

### 3. Configurar variáveis de ambiente

O arquivo `.env` já está configurado com:
```
PORT=3005
JWT_SECRET=seu_secret_super_seguro_aqui_mude_em_producao
JWT_EXPIRES_IN=7d
JWT_TEMP_EXPIRES_IN=15m
NODE_ENV=development
```

### 4. Iniciar o servidor

```bash
npm start
```

Ou para desenvolvimento:
```bash
npm run dev
```

---

## ✅ Verificar se está funcionando

Acesse no navegador:
- **API Principal**: http://localhost:3005
- **Interface de Backup**: http://localhost:3005/backup-interface

Você deve ver a mensagem:
```
✓ Servidor rodando na porta 3005
✓ Ambiente: development
✓ API disponível em: http://localhost:3005
```

---

## 🔐 Configurar Administrador de Backup

### 1. Criar primeiro admin

```bash
curl -X POST http://localhost:3005/api/backup/admin/criar \
  -H "Content-Type: application/json" \
  -d '{
    "nome_usuario": "admin",
    "senha": "senha_segura_123"
  }'
```

### 2. Fazer login e obter token

```bash
curl -X POST http://localhost:3005/api/backup/admin/login \
  -H "Content-Type: application/json" \
  -d '{
    "nome_usuario": "admin",
    "senha": "senha_segura_123"
  }'
```

Copie o `token` retornado para usar nas operações de backup.

---

## 📧 Testar Envio de E-mails

### Registrar novo usuário (dispara e-mail automático)

```bash
curl -X POST http://localhost:3005/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "nome_completo": "João Silva",
    "email": "seu_email@gmail.com",
    "celular": "11999999999",
    "senha": "senha123",
    "cpf_cnpj": "12345678901",
    "sexo": "Masculino"
  }'
```

✅ Verifique sua caixa de entrada - você deve receber um e-mail de boas-vindas com código de verificação!

---

## 🔐 Testar Reconhecimento Facial

### 1. Cadastrar biometria facial

Primeiro, faça login e obtenha o token:

```bash
curl -X POST http://localhost:3005/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "cpf_cnpj": "12345678901",
    "senha": "senha123"
  }'
```

Depois, cadastre a biometria (substitua `{TOKEN}` e `{USER_ID}`):

```bash
curl -X POST http://localhost:3005/api/verificacao/usuario/{USER_ID}/biometria \
  -H "Authorization: Bearer {TOKEN}" \
  -H "Content-Type: application/json" \
  -d '{
    "foto_base64": "data:image/jpeg;base64,/9j/4AAQSkZJRg..."
  }'
```

### 2. Autenticar por reconhecimento facial

```bash
curl -X POST http://localhost:3005/api/verificacao/usuario/{USER_ID}/biometria/autenticar \
  -H "Authorization: Bearer {TOKEN}" \
  -H "Content-Type: application/json" \
  -d '{
    "foto_base64": "data:image/jpeg;base64,/9j/4AAQSkZJRg..."
  }'
```

### 3. Comparar duas fotos

```bash
curl -X POST http://localhost:3005/api/verificacao/comparar-fotos \
  -H "Authorization: Bearer {TOKEN}" \
  -H "Content-Type: application/json" \
  -d '{
    "foto_base64_1": "data:image/jpeg;base64,/9j/4AAQ...",
    "foto_base64_2": "data:image/jpeg;base64,/9j/4AAQ..."
  }'
```

---

## 💾 Testar Backup e Restauração

### 1. Criar backup

```bash
curl -X POST http://localhost:3005/api/backup/criar \
  -H "Authorization: Bearer {ADMIN_TOKEN}"
```

### 2. Listar backups

```bash
curl -X GET http://localhost:3005/api/backup/listar \
  -H "Authorization: Bearer {ADMIN_TOKEN}"
```

### 3. Download de backup

```bash
curl -X GET http://localhost:3005/api/backup/download/backup_2025-11-23.db \
  -H "Authorization: Bearer {ADMIN_TOKEN}" \
  -o backup_download.db
```

### 4. Upload e restaurar backup

```bash
curl -X POST http://localhost:3005/api/backup/upload-restaurar \
  -H "Authorization: Bearer {ADMIN_TOKEN}" \
  -F "backup_file=@/caminho/para/backup.db"
```

---

## 📚 Documentação Completa

Consulte os seguintes arquivos para mais detalhes:

- **NOVAS_FUNCIONALIDADES.md** - Documentação detalhada das novas funcionalidades
- **API_COMPLETA.md** - Todas as APIs disponíveis
- **README.md** - Documentação geral do sistema
- **TODAS_AS_APIS.md** - Lista completa de endpoints

---

## 🗄️ Banco de Dados

### Novas tabelas criadas automaticamente:

1. **biometria_usuario** - Armazena dados de reconhecimento facial
   - `id` - ID único
   - `usuario_id` - ID do usuário (único)
   - `face_token` - Token da face do Face++
   - `dados_biometria` - Dados adicionais em JSON
   - `data_cadastro` - Data de cadastro
   - `data_atualizacao` - Data de atualização

2. **logs_acesso** - Atualizada com nova coluna
   - `tipo_autenticacao` - Tipo de autenticação ('Senha' ou 'Biometria Facial')

---

## 🔑 Credenciais Configuradas

### Face++ API
- **API Key**: `lOHREhzgNbKmjGyEE_-UmVvQnkpTVolo`
- **API Secret**: `yI_Cu6m1m_8C7BQESyvd7VIbUs0yVCUz`
- **Região**: US (api-us.faceplusplus.com)

### API de E-mail Guardião Mais
- **URL**: `https://script.google.com/macros/s/AKfycbwN8jiiMzm0Win5XRYUqmE11CXEiuoMzeROmYPz8MxcvutXBhGtr-LxjtXB18stlAD_jQ/exec`
- **Método**: GET
- **Parâmetros**: `email` e `mensagem`

---

## ⚠️ Notas Importantes

### Segurança
- ⚠️ **Mude o JWT_SECRET em produção!**
- ⚠️ Use HTTPS em produção
- ⚠️ Configure CORS adequadamente para seu domínio

### E-mails
- Os e-mails são enviados de forma assíncrona
- Falhas no envio não bloqueiam as operações
- Logs são gerados para monitoramento

### Reconhecimento Facial
- Imagens devem estar em base64
- Tamanho máximo recomendado: 5MB
- Formatos suportados: JPEG, PNG, WebP
- Confiança mínima para autenticação: 70%

### Backup
- Backups são salvos em `database/backups/`
- Tamanho máximo para upload: 100MB
- Backup automático é criado antes de restaurar

---

## 🐛 Solução de Problemas

### Erro: "Token de administrador não fornecido"
✅ **Solução**: Certifique-se de incluir o header `Authorization: Bearer {token}` nas requisições de backup

### Erro: "Nenhuma face detectada na imagem"
✅ **Solução**: 
- Verifique se a imagem está em base64 válido
- Certifique-se de que há uma face visível na foto
- Tente com melhor iluminação e enquadramento

### Erro: "Erro ao conectar com serviço de e-mail"
✅ **Solução**: 
- Verifique sua conexão com a internet
- A API do Google pode estar temporariamente indisponível
- O sistema continuará funcionando normalmente

### Porta 3005 já em uso
✅ **Solução**: Altere a porta no arquivo `.env`:
```
PORT=3006
```

---

## 📞 Suporte

Para dúvidas ou problemas:
1. Consulte a documentação em `NOVAS_FUNCIONALIDADES.md`
2. Verifique os logs do servidor
3. Revise o arquivo `API_COMPLETA.md`

---

## ✅ Checklist Pós-Instalação

- [ ] Servidor iniciou sem erros
- [ ] Criou administrador de backup
- [ ] Testou login de admin
- [ ] Testou cadastro de usuário (e-mail enviado)
- [ ] Testou cadastro de biometria facial
- [ ] Testou autenticação facial
- [ ] Testou criação de backup
- [ ] Testou download de backup
- [ ] Testou upload e restauração de backup

---

**Sistema pronto para uso! 🎉**

Desenvolvido com ❤️ para o Sistema Guardião Mais

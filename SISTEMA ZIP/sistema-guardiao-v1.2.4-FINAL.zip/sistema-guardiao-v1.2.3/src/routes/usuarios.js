const express = require('express');
const router = express.Router();
const usuarioController = require('../controllers/usuarioController');
const { authenticateToken } = require('../middlewares/auth');

// Todas as rotas requerem autenticação
router.use(authenticateToken);

router.get('/', usuarioController.listar);
router.get('/:id', usuarioController.obterPorId);
router.put('/:id', usuarioController.atualizar);
router.put('/:id/senha', usuarioController.alterarSenha);
router.delete('/:id', usuarioController.deletar);

module.exports = router;

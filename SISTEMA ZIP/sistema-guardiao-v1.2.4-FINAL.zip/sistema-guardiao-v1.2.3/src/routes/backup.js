const express = require('express');
const router = express.Router();
const multer = require('multer');
const backupController = require('../controllers/backupController');
const { authenticateAdmin } = require('../middlewares/auth');

// Configurar multer para upload de arquivos em memória
const upload = multer({ 
  storage: multer.memoryStorage(),
  limits: { fileSize: 100 * 1024 * 1024 } // 100MB máximo
});

// Rotas públicas (login e criar primeiro admin)
router.post('/admin/login', backupController.loginAdmin);
router.post('/admin/criar', backupController.criarAdmin);

// Rotas protegidas (requerem autenticação de admin)
router.post('/criar', authenticateAdmin, backupController.criarBackup);
router.get('/listar', authenticateAdmin, backupController.listarBackups);
router.post('/restaurar', authenticateAdmin, backupController.restaurarBackup);
router.post('/upload-restaurar', authenticateAdmin, upload.single('backup_file'), backupController.uploadRestaurarBackup);
router.get('/download/:nome_arquivo', authenticateAdmin, backupController.downloadBackup);
router.delete('/:nome_arquivo', authenticateAdmin, backupController.deletarBackup);
router.get('/estatisticas', authenticateAdmin, backupController.obterEstatisticasSistema);

module.exports = router;

const express = require('express');
const router = express.Router();
const avaliacaoController = require('../controllers/avaliacaoController');
const { authenticateToken } = require('../middlewares/auth');

// Todas as rotas requerem autenticação
router.use(authenticateToken);

// Rotas específicas ANTES das rotas parametrizadas
router.get('/top-prestadores', avaliacaoController.obterTopPrestadores);

// Rotas parametrizadas
router.post('/', avaliacaoController.criar);
router.get('/usuario/:usuario_id', avaliacaoController.listarPorUsuario);
router.get('/usuario/:usuario_id/feitas', avaliacaoController.listarFeitasPorUsuario);
router.get('/contratacao/:contratacao_id', avaliacaoController.listarPorContratacao);
router.get('/:id', avaliacaoController.obterPorId);
router.put('/:id', avaliacaoController.atualizar);
router.delete('/:id', avaliacaoController.deletar);

module.exports = router;

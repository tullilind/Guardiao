const express = require('express');
const router = express.Router();
const logController = require('../controllers/logController');
const { authenticateToken } = require('../middlewares/auth');

// Todas as rotas requerem autenticação
router.use(authenticateToken);

// Rotas específicas ANTES das rotas parametrizadas
router.get('/todos', logController.listarTodos);
router.get('/estatisticas', logController.obterEstatisticas);
router.post('/limpar', logController.limparLogsAntigos);

// Rotas parametrizadas
router.get('/usuario/:usuario_id', logController.listarPorUsuario);
router.get('/usuario/:usuario_id/ultimo', logController.obterUltimoAcesso);

module.exports = router;

/**
 * Gerar URL do Google Maps com base em coordenadas
 */
function gerarUrlMapa(latitude, longitude, endereco = null) {
  if (!latitude || !longitude) return null;

  const query = endereco 
    ? encodeURIComponent(endereco)
    : `${latitude},${longitude}`;

  return `https://www.google.com/maps/search/${query}/@${latitude},${longitude},15z`;
}

/**
 * Gerar URL de embed do Google Maps
 */
function gerarMapaEmbed(latitude, longitude) {
  if (!latitude || !longitude) return null;

  return `https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3000!2d${longitude}!3d${latitude}!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0:0x0!2zM0MwJzAwLjAiTiA0NkMwMCcwMC4wIkU!5e0!3m2!1spt-BR!2sbr!4v1234567890`;
}

/**
 * Formatar endereço com coordenadas
 */
function formatarEnderecoComCoordenadas(endereco, latitude, longitude) {
  if (!endereco) return null;

  return {
    endereco_completo: endereco,
    latitude,
    longitude,
    mapa_url: gerarUrlMapa(latitude, longitude, endereco),
    mapa_embed: gerarMapaEmbed(latitude, longitude)
  };
}

/**
 * Validar coordenadas
 */
function validarCoordenadas(latitude, longitude) {
  if (!latitude || !longitude) return false;

  const lat = parseFloat(latitude);
  const lng = parseFloat(longitude);

  // Validar ranges válidos
  if (lat < -90 || lat > 90) return false;
  if (lng < -180 || lng > 180) return false;

  return true;
}

module.exports = {
  gerarUrlMapa,
  gerarMapaEmbed,
  formatarEnderecoComCoordenadas,
  validarCoordenadas
};

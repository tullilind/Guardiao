const database = require('../config/database');

/**
 * Buscar foto do usuário e converter para base64
 */
async function obterFotoUsuario(usuarioId) {
  try {
    if (!usuarioId) return null;

    const usuario = await database.get(
      'SELECT foto_perfil_id FROM usuarios WHERE id = ?',
      [usuarioId]
    );

    if (!usuario || !usuario.foto_perfil_id) return null;

    const fotoData = await database.get(
      'SELECT conteudo_blob, mime_type FROM midia_usuarios WHERE id = ?',
      [usuario.foto_perfil_id]
    );

    if (!fotoData || !fotoData.conteudo_blob) return null;

    const buffer = Buffer.from(fotoData.conteudo_blob);
    return `data:${fotoData.mime_type};base64,${buffer.toString('base64')}`;
  } catch (error) {
    console.error('Erro ao obter foto do usuário:', error);
    return null;
  }
}

/**
 * Formatar dados do usuário com foto e localização
 */
async function formatarUsuarioComFoto(usuario) {
  if (!usuario) return null;

  const fotoBase64 = await obterFotoUsuario(usuario.id);

  return {
    id: usuario.id,
    nome_completo: usuario.nome_completo,
    email: usuario.email,
    celular: usuario.celular,
    cpf_cnpj: usuario.cpf_cnpj,
    tipo_acesso: usuario.tipo_acesso,
    sexo: usuario.sexo,
    endereco: {
      rua: usuario.rua,
      cidade: usuario.cidade,
      estado: usuario.estado,
      bairro: usuario.bairro,
      cep: usuario.cep
    },
    localizacao: {
      latitude: usuario.latitude,
      longitude: usuario.longitude,
      mapa_url: usuario.latitude && usuario.longitude 
        ? `https://www.google.com/maps?q=${usuario.latitude},${usuario.longitude}`
        : null
    },
    perfil_verificado: usuario.perfil_verificado,
    media_avaliacao: usuario.media_avaliacao,
    foto_perfil: fotoBase64,
    foto_perfil_id: usuario.foto_perfil_id,
    data_cadastro: usuario.data_cadastro
  };
}

/**
 * Formatar lista de usuários com fotos
 */
async function formatarListaUsuariosComFoto(usuarios) {
  if (!usuarios || usuarios.length === 0) return [];

  const usuariosFormatados = [];
  for (const usuario of usuarios) {
    const usuarioFormatado = await formatarUsuarioComFoto(usuario);
    usuariosFormatados.push(usuarioFormatado);
  }

  return usuariosFormatados;
}

module.exports = {
  obterFotoUsuario,
  formatarUsuarioComFoto,
  formatarListaUsuariosComFoto
};

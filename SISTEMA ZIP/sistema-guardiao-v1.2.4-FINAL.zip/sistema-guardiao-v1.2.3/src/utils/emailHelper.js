const axios = require('axios');

/**
 * Helper para envio de e-mails via API Guardião Mais
 */

const EMAIL_API_URL = 'https://script.google.com/macros/s/AKfycbwN8jiiMzm0Win5XRYUqmE11CXEiuoMzeROmYPz8MxcvutXBhGtr-LxjtXB18stlAD_jQ/exec';

/**
 * Enviar e-mail genérico
 */
async function enviarEmail(email, mensagem) {
  try {
    const response = await axios.get(EMAIL_API_URL, {
      params: {
        email: email,
        mensagem: mensagem
      },
      timeout: 10000 // 10 segundos de timeout
    });

    if (response.data && response.data.status === 'success') {
      console.log(`✅ E-mail enviado com sucesso para: ${email}`);
      return { success: true, message: response.data.message };
    } else {
      console.error(`❌ Erro ao enviar e-mail: ${response.data?.message || 'Erro desconhecido'}`);
      return { success: false, message: response.data?.message || 'Erro ao enviar e-mail' };
    }
  } catch (error) {
    console.error('❌ Erro na requisição de e-mail:', error.message);
    return { success: false, message: 'Erro ao conectar com serviço de e-mail' };
  }
}

/**
 * Enviar código de verificação (cadastro de conta)
 */
async function enviarCodigoVerificacao(email, codigo, nomeUsuario) {
  const mensagem = `
Olá ${nomeUsuario}!

Bem-vindo(a) ao Guardião Mais! 🎉

Sua conta foi criada com sucesso. Para sua segurança, aqui está seu código de verificação:

🔐 Código: ${codigo}

Este código é válido por 15 minutos.

Se você não solicitou este cadastro, ignore este e-mail.

Atenciosamente,
Equipe Guardião Mais
  `.trim();

  return await enviarEmail(email, mensagem);
}

/**
 * Enviar código de recuperação de senha
 */
async function enviarCodigoRecuperacao(email, codigo, nomeUsuario) {
  const mensagem = `
Olá ${nomeUsuario}!

Você solicitou a recuperação de senha no Guardião Mais.

🔐 Código de recuperação: ${codigo}

Este código é válido por 15 minutos.

Se você não solicitou esta recuperação, ignore este e-mail e sua senha permanecerá inalterada.

Atenciosamente,
Equipe Guardião Mais
  `.trim();

  return await enviarEmail(email, mensagem);
}

/**
 * Enviar notificação de atualização de dados
 */
async function enviarNotificacaoAtualizacao(email, nomeUsuario, dadosAlterados) {
  const listaAlteracoes = dadosAlterados.join(', ');
  
  const mensagem = `
Olá ${nomeUsuario}!

Detectamos uma atualização nos seus dados cadastrais no Guardião Mais.

📝 Dados alterados: ${listaAlteracoes}

Se você não realizou esta alteração, entre em contato conosco imediatamente.

Atenciosamente,
Equipe Guardião Mais
  `.trim();

  return await enviarEmail(email, mensagem);
}

/**
 * Enviar código de confirmação para alteração de dados sensíveis
 */
async function enviarCodigoConfirmacao(email, codigo, nomeUsuario, tipoAlteracao) {
  const mensagem = `
Olá ${nomeUsuario}!

Você está tentando alterar: ${tipoAlteracao}

Para confirmar esta alteração, use o código abaixo:

🔐 Código: ${codigo}

Este código é válido por 10 minutos.

Se você não solicitou esta alteração, ignore este e-mail.

Atenciosamente,
Equipe Guardião Mais
  `.trim();

  return await enviarEmail(email, mensagem);
}

/**
 * Gerar código aleatório de 6 dígitos
 */
function gerarCodigoVerificacao() {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

module.exports = {
  enviarEmail,
  enviarCodigoVerificacao,
  enviarCodigoRecuperacao,
  enviarNotificacaoAtualizacao,
  enviarCodigoConfirmacao,
  gerarCodigoVerificacao
};

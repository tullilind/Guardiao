const express = require('express');
const cors = require('cors');
const path = require('path');
require('dotenv').config();

const database = require('./config/database');
const { errorHandler, notFoundHandler } = require('./middlewares/errorHandler');

// Importar rotas
const authRoutes = require('./routes/auth');
const usuarioRoutes = require('./routes/usuarios');
const arquivoRoutes = require('./routes/arquivos');
const documentoRoutes = require('./routes/documentos');
const contratacaoRoutes = require('./routes/contratacoes');
const pontoRoutes = require('./routes/ponto');
const notificacaoRoutes = require('./routes/notificacoes');
const avaliacaoRoutes = require('./routes/avaliacoes');
const prestadorRoutes = require('./routes/prestadores');
const verificacaoRoutes = require('./routes/verificacao');
const logRoutes = require('./routes/logs');
const backupRoutes = require('./routes/backup');
const midiaRoutes = require('./routes/midia');
const localizacaoRoutes = require('./routes/localizacao');

const app = express();
const PORT = process.env.PORT || 3005;

// Configuração de CORS - CORRIGIDO
const corsOptions = {
  origin: function (origin, callback) {
    // Permitir requisições sem origin (como mobile apps ou requests diretos)
    if (!origin || origin === 'undefined') {
      return callback(null, true);
    }
    
    // Permitir localhost e variações
    if (origin.includes('localhost') || 
        origin.includes('127.0.0.1') || 
        origin.includes('.netlify.app') ||
        origin.includes('manusvm.computer') ||
        process.env.ALLOWED_ORIGINS?.includes(origin)) {
      callback(null, true);
    } else {
      callback(null, true); // Permitir todos em desenvolvimento
    }
  },
  credentials: true,
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH', 'OPTIONS'],
  allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With', 'Accept'],
  exposedHeaders: ['Content-Type', 'Authorization'],
  maxAge: 86400 // 24 horas
};

// Middlewares globais
app.use(cors(corsOptions));
app.options('*', cors(corsOptions)); // Preflight requests

app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Middleware de logging
app.use((req, res, next) => {
  console.log(`[${new Date().toISOString()}] ${req.method} ${req.path}`);
  next();
});

// Servir arquivos estáticos (interface de backup)
app.use('/backup-interface', express.static(path.join(__dirname, '../public')));

// Rota de health check
app.get('/health', (req, res) => {
  res.json({
    status: 'OK',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
    database: 'Connected'
  });
});

// Rota raiz
app.get('/', (req, res) => {
  res.json({
    message: 'Sistema de Gerenciamento de Serviços - API',
    version: '1.2.4 - ATUALIZADA (Biometria + Upload Múltiplo + E-mails)',
    endpoints: {
      auth: '/api/auth',
      usuarios: '/api/usuarios',
      arquivos: '/api/arquivos',
      documentos: '/api/documentos',
      contratacoes: '/api/contratacoes',
      ponto: '/api/ponto',
      notificacoes: '/api/notificacoes',
      avaliacoes: '/api/avaliacoes',
      prestadores: '/api/prestadores',
      verificacao: '/api/verificacao',
      logs: '/api/logs',
      backup: '/api/backup'
    },
    backup_interface: '/backup-interface'
  });
});

// Registrar rotas da API
app.use('/api/auth', authRoutes);
app.use('/api/usuarios', usuarioRoutes);
app.use('/api/arquivos', arquivoRoutes);
app.use('/api/documentos', documentoRoutes);
app.use('/api/contratacoes', contratacaoRoutes);
app.use('/api/ponto', pontoRoutes);
app.use('/api/notificacoes', notificacaoRoutes);
app.use('/api/avaliacoes', avaliacaoRoutes);
app.use('/api/prestadores', prestadorRoutes);
app.use('/api/verificacao', verificacaoRoutes);
app.use('/api/logs', logRoutes);
app.use('/api/backup', backupRoutes);
app.use('/api/midia', midiaRoutes);
app.use('/api/localizacao', localizacaoRoutes);

// Middleware de rota não encontrada
app.use(notFoundHandler);

// Middleware de tratamento de erros
app.use(errorHandler);

// Iniciar servidor
async function startServer() {
  try {
    // Conectar ao banco de dados
    await database.connect();
    
    // Iniciar servidor HTTP
    app.listen(PORT, () => {
      console.log('\n╔═══════════════════════════════════════════════════════════════════╗');
      console.log('║   🛡️  SISTEMA GUARDIÃO MAIS - API v1.2.4                         ║');
      console.log('╚═══════════════════════════════════════════════════════════════════╝\n');
      
      console.log('📡 SERVIDOR');
      console.log(`   ✓ Porta: ${PORT}`);
      console.log(`   ✓ Ambiente: ${process.env.NODE_ENV || 'development'}`);
      console.log(`   ✓ URL Base: http://localhost:${PORT}`);
      console.log(`   ✓ CORS: Habilitado para todas as origens\n`);
      
      console.log('🔗 ACESSOS IMPORTANTES');
      console.log(`   📊 API Health Check: http://localhost:${PORT}/health`);
      console.log(`   💾 Interface de Backup: http://localhost:${PORT}/backup-interface`);
      console.log(`   📖 Documentação: http://localhost:${PORT}/\n`);
      
      console.log('👤 CRIAR USUÁRIO ADMINISTRADOR');
      console.log('   Execute no terminal:');
      console.log('   node src/config/addBiometria.js\n');
      
      console.log('💾 GERENCIAR BANCO DE DADOS');
      console.log('   Inicializar: npm run init-db');
      console.log('   Backup: Acesse http://localhost:${PORT}/backup-interface');
      console.log('   Restaurar: Use a interface de backup\n');
      
      console.log('🔐 MÓDULOS DISPONÍVEIS');
      console.log('   ✓ Autenticação (JWT)');
      console.log('   ✓ Usuários e Prestadores');
      console.log('   ✓ Documentos e Validação (Upload Múltiplo)');
      console.log('   ✓ Biometria Facial (Face++)');
      console.log('   ✓ Contratações e Serviços');
      console.log('   ✓ Registro de Ponto');
      console.log('   ✓ Avaliações');
      console.log('   ✓ Notificações');
      console.log('   ✓ Localização em Tempo Real');
      console.log('   ✓ Backup e Restauração\n');
      
      console.log('📋 ENDPOINTS PRINCIPAIS');
      console.log('   AUTH:');
      console.log('     POST   /api/auth/register');
      console.log('     POST   /api/auth/login');
      console.log('     POST   /api/auth/recuperar-senha\n');
      
      console.log('   DOCUMENTOS:');
      console.log('     POST   /api/documentos (Upload único ou múltiplo)');
      console.log('     PUT    /api/documentos/:id/status');
      console.log('     GET    /api/documentos/pendentes\n');
      
      console.log('   BIOMETRIA FACIAL:');
      console.log('     GET    /api/verificacao/usuario/:id/biometria');
      console.log('     POST   /api/verificacao/usuario/:id/biometria');
      console.log('     POST   /api/verificacao/usuario/:id/biometria/autenticar\n');
      
      console.log('   USUÁRIOS:');
      console.log('     GET    /api/usuarios');
      console.log('     GET    /api/prestadores/verificados');
      console.log('     PUT    /api/usuarios/:id\n');
      
      console.log('╔═══════════════════════════════════════════════════════════════════╗');
      console.log('║   ✅ SERVIDOR PRONTO! Aguardando requisições...                   ║');
      console.log('╚═══════════════════════════════════════════════════════════════════╝\n');
    });
  } catch (error) {
    console.error('❌ Erro ao iniciar servidor:', error);
    process.exit(1);
  }
}

// Tratamento de encerramento gracioso
process.on('SIGINT', async () => {
  console.log('\n\n🛑 Encerrando servidor...');
  await database.close();
  process.exit(0);
});

process.on('SIGTERM', async () => {
  console.log('\n\n🛑 Encerrando servidor...');
  await database.close();
  process.exit(0);
});

// Iniciar
startServer();

module.exports = app;

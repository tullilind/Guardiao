const database = require('../config/database');
const ResponseHandler = require('../utils/responseHandler');

/**
 * Upload de arquivo (BLOB)
 */
async function upload(req, res) {
  try {
    if (!req.file) {
      return ResponseHandler.validationError(res, ['Nenhum arquivo foi enviado']);
    }

    const { buffer, mimetype, size } = req.file;
    const usuario_id = req.user.id;
    const tamanho_kb = (size / 1024).toFixed(2);

    // Inserir arquivo no banco
    const result = await database.run(
      `INSERT INTO arquivos_sistema (usuario_id, conteudo_blob, mime_type, tamanho_kb)
       VALUES (?, ?, ?, ?)`,
      [usuario_id, buffer, mimetype, tamanho_kb]
    );

    return ResponseHandler.created(res, {
      id: result.id,
      mime_type: mimetype,
      tamanho_kb: parseFloat(tamanho_kb)
    }, 'Arquivo enviado com sucesso');

  } catch (error) {
    console.error('Erro ao fazer upload de arquivo:', error);
    return ResponseHandler.error(res, 'Erro ao fazer upload de arquivo');
  }
}

/**
 * Download de arquivo
 */
async function download(req, res) {
  try {
    const { id } = req.params;

    const arquivo = await database.get(
      'SELECT * FROM arquivos_sistema WHERE id = ?',
      [id]
    );

    if (!arquivo) {
      return ResponseHandler.notFound(res, 'Arquivo não encontrado');
    }

    // Verificar permissão (só pode baixar próprios arquivos ou se for admin)
    if (arquivo.usuario_id !== req.user.id) {
      return ResponseHandler.forbidden(res, 'Você não tem permissão para acessar este arquivo');
    }

    // Enviar arquivo
    res.setHeader('Content-Type', arquivo.mime_type);
    res.setHeader('Content-Disposition', `attachment; filename="arquivo_${id}"`);
    res.send(arquivo.conteudo_blob);

  } catch (error) {
    console.error('Erro ao fazer download de arquivo:', error);
    return ResponseHandler.error(res, 'Erro ao fazer download de arquivo');
  }
}

/**
 * Visualizar arquivo (inline)
 */
async function visualizar(req, res) {
  try {
    const { id } = req.params;

    const arquivo = await database.get(
      'SELECT * FROM arquivos_sistema WHERE id = ?',
      [id]
    );

    if (!arquivo) {
      return ResponseHandler.notFound(res, 'Arquivo não encontrado');
    }

    // Verificar permissão
    if (arquivo.usuario_id !== req.user.id) {
      return ResponseHandler.forbidden(res, 'Você não tem permissão para acessar este arquivo');
    }

    // Enviar arquivo inline
    res.setHeader('Content-Type', arquivo.mime_type);
    res.setHeader('Content-Disposition', 'inline');
    res.send(arquivo.conteudo_blob);

  } catch (error) {
    console.error('Erro ao visualizar arquivo:', error);
    return ResponseHandler.error(res, 'Erro ao visualizar arquivo');
  }
}

/**
 * Listar arquivos do usuário
 */
async function listar(req, res) {
  try {
    const usuario_id = req.user.id;
    const { page = 1, limit = 20 } = req.query;
    const offset = (page - 1) * limit;

    const arquivos = await database.all(
      `SELECT id, mime_type, tamanho_kb, data_upload
       FROM arquivos_sistema
       WHERE usuario_id = ?
       ORDER BY data_upload DESC
       LIMIT ? OFFSET ?`,
      [usuario_id, parseInt(limit), parseInt(offset)]
    );

    // Contar total
    const { total } = await database.get(
      'SELECT COUNT(*) as total FROM arquivos_sistema WHERE usuario_id = ?',
      [usuario_id]
    );

    return ResponseHandler.success(res, {
      arquivos,
      paginacao: {
        total,
        pagina_atual: parseInt(page),
        total_paginas: Math.ceil(total / limit),
        itens_por_pagina: parseInt(limit)
      }
    });

  } catch (error) {
    console.error('Erro ao listar arquivos:', error);
    return ResponseHandler.error(res, 'Erro ao listar arquivos');
  }
}

/**
 * Obter informações do arquivo (sem o blob)
 */
async function obterInfo(req, res) {
  try {
    const { id } = req.params;

    const arquivo = await database.get(
      `SELECT id, usuario_id, mime_type, tamanho_kb, data_upload
       FROM arquivos_sistema WHERE id = ?`,
      [id]
    );

    if (!arquivo) {
      return ResponseHandler.notFound(res, 'Arquivo não encontrado');
    }

    return ResponseHandler.success(res, arquivo);

  } catch (error) {
    console.error('Erro ao obter informações do arquivo:', error);
    return ResponseHandler.error(res, 'Erro ao obter informações do arquivo');
  }
}

/**
 * Deletar arquivo
 */
async function deletar(req, res) {
  try {
    const { id } = req.params;

    const arquivo = await database.get(
      'SELECT * FROM arquivos_sistema WHERE id = ?',
      [id]
    );

    if (!arquivo) {
      return ResponseHandler.notFound(res, 'Arquivo não encontrado');
    }

    // Verificar permissão
    if (arquivo.usuario_id !== req.user.id) {
      return ResponseHandler.forbidden(res, 'Você não tem permissão para deletar este arquivo');
    }

    // Verificar se arquivo está sendo usado em documentos
    const documentoUsando = await database.get(
      'SELECT id FROM documentos_validacao WHERE arquivo_id = ?',
      [id]
    );

    if (documentoUsando) {
      return ResponseHandler.conflict(res, 'Arquivo está sendo usado em um documento e não pode ser deletado');
    }

    // Deletar arquivo
    await database.run('DELETE FROM arquivos_sistema WHERE id = ?', [id]);

    return ResponseHandler.success(res, null, 'Arquivo deletado com sucesso');

  } catch (error) {
    console.error('Erro ao deletar arquivo:', error);
    return ResponseHandler.error(res, 'Erro ao deletar arquivo');
  }
}

/**
 * Obter estatísticas de armazenamento do usuário
 */
async function obterEstatisticas(req, res) {
  try {
    const usuario_id = req.user.id;

    const stats = await database.get(
      `SELECT 
        COUNT(*) as total_arquivos,
        SUM(tamanho_kb) as espaco_usado_kb,
        AVG(tamanho_kb) as tamanho_medio_kb
       FROM arquivos_sistema
       WHERE usuario_id = ?`,
      [usuario_id]
    );

    return ResponseHandler.success(res, {
      total_arquivos: stats.total_arquivos || 0,
      espaco_usado_kb: parseFloat(stats.espaco_usado_kb || 0).toFixed(2),
      espaco_usado_mb: (parseFloat(stats.espaco_usado_kb || 0) / 1024).toFixed(2),
      tamanho_medio_kb: parseFloat(stats.tamanho_medio_kb || 0).toFixed(2)
    });

  } catch (error) {
    console.error('Erro ao obter estatísticas:', error);
    return ResponseHandler.error(res, 'Erro ao obter estatísticas');
  }
}

module.exports = {
  upload,
  download,
  visualizar,
  listar,
  obterInfo,
  deletar,
  obterEstatisticas
};

const database = require('../config/database');
const ResponseHandler = require('../utils/responseHandler');
const { gerarUrlMapa, validarCoordenadas } = require('../utils/googleMapsHelper');

/**
 * Atualizar localização em tempo real
 */
async function atualizarLocalizacao(req, res) {
  try {
    const userId = req.userId;
    const { latitude, longitude, endereco_completo, precisao } = req.body;

    if (!latitude || !longitude) {
      return ResponseHandler.validationError(res, ['Latitude e longitude são obrigatórios']);
    }

    if (!validarCoordenadas(latitude, longitude)) {
      return ResponseHandler.validationError(res, ['Coordenadas inválidas']);
    }

    // Atualizar localização do usuário
    await database.run(
      `UPDATE usuarios SET latitude = ?, longitude = ? WHERE id = ?`,
      [latitude, longitude, userId]
    );

    // Registrar histórico de localização
    await database.run(
      `INSERT INTO historico_localizacao (usuario_id, latitude, longitude, endereco_completo, precisao, data_hora)
       VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP)`,
      [userId, latitude, longitude, endereco_completo || null, precisao || null]
    );

    return ResponseHandler.success(res, {
      usuario_id: userId,
      localizacao: {
        latitude,
        longitude,
        endereco_completo,
        precisao,
        mapa_url: gerarUrlMapa(latitude, longitude, endereco_completo)
      },
      data_atualizacao: new Date().toISOString()
    }, 'Localização atualizada com sucesso');

  } catch (error) {
    console.error('Erro ao atualizar localização:', error);
    return ResponseHandler.serverError(res, 'Erro ao atualizar localização');
  }
}

/**
 * Obter histórico de localização
 */
async function obterHistoricoLocalizacao(req, res) {
  try {
    const userId = req.userId;
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 20;
    const offset = (page - 1) * limit;
    const dataInicio = req.query.data_inicio || null;
    const dataFim = req.query.data_fim || null;

    let query = 'SELECT id, latitude, longitude, endereco_completo, precisao, data_hora FROM historico_localizacao WHERE usuario_id = ?';
    let params = [userId];

    if (dataInicio) {
      query += ' AND data_hora >= ?';
      params.push(dataInicio);
    }

    if (dataFim) {
      query += ' AND data_hora <= ?';
      params.push(dataFim);
    }

    query += ' ORDER BY data_hora DESC LIMIT ? OFFSET ?';
    params.push(limit, offset);

    const historico = await database.all(query, params);

    // Contar total
    let countQuery = 'SELECT COUNT(*) as total FROM historico_localizacao WHERE usuario_id = ?';
    let countParams = [userId];
    if (dataInicio) {
      countQuery += ' AND data_hora >= ?';
      countParams.push(dataInicio);
    }
    if (dataFim) {
      countQuery += ' AND data_hora <= ?';
      countParams.push(dataFim);
    }

    const countResult = await database.get(countQuery, countParams);
    const total = countResult.total;

    // Formatar resposta
    const historicoFormatado = historico.map(loc => ({
      id: loc.id,
      localizacao: {
        latitude: loc.latitude,
        longitude: loc.longitude,
        endereco_completo: loc.endereco_completo,
        precisao: loc.precisao,
        mapa_url: gerarUrlMapa(loc.latitude, loc.longitude, loc.endereco_completo)
      },
      data_hora: loc.data_hora
    }));

    return ResponseHandler.success(res, {
      historico: historicoFormatado,
      paginacao: {
        total,
        pagina_atual: page,
        total_paginas: Math.ceil(total / limit),
        itens_por_pagina: limit
      }
    }, 'Histórico de localização obtido com sucesso');

  } catch (error) {
    console.error('Erro ao obter histórico:', error);
    return ResponseHandler.serverError(res, 'Erro ao obter histórico de localização');
  }
}

/**
 * Geocoding reverso (coordenadas para endereço)
 * Simula a API do Google Maps
 */
async function geocodingReverso(req, res) {
  try {
    const { latitude, longitude } = req.body;

    if (!latitude || !longitude) {
      return ResponseHandler.validationError(res, ['Latitude e longitude são obrigatórios']);
    }

    if (!validarCoordenadas(latitude, longitude)) {
      return ResponseHandler.validationError(res, ['Coordenadas inválidas']);
    }

    // Simular resposta de geocoding reverso
    // Em produção, usar Google Maps Geocoding API
    const endereco = `Coordenadas: ${latitude.toFixed(4)}, ${longitude.toFixed(4)}`;
    const pais = 'Brasil';
    const estado = 'SP'; // Simplificado
    const cidade = 'São Paulo'; // Simplificado

    return ResponseHandler.success(res, {
      latitude,
      longitude,
      endereco,
      pais,
      estado,
      cidade,
      mapa_url: gerarUrlMapa(latitude, longitude, endereco)
    }, 'Geocoding reverso realizado com sucesso');

  } catch (error) {
    console.error('Erro ao fazer geocoding reverso:', error);
    return ResponseHandler.serverError(res, 'Erro ao fazer geocoding reverso');
  }
}

/**
 * Geocoding direto (endereço para coordenadas)
 * Simula a API do Google Maps
 */
async function geocodingDireto(req, res) {
  try {
    const { endereco } = req.body;

    if (!endereco) {
      return ResponseHandler.validationError(res, ['Endereço é obrigatório']);
    }

    // Simular resposta de geocoding direto
    // Em produção, usar Google Maps Geocoding API
    const latitude = -23.5505 + (Math.random() - 0.5) * 0.1;
    const longitude = -46.6333 + (Math.random() - 0.5) * 0.1;

    return ResponseHandler.success(res, {
      endereco,
      latitude: latitude.toFixed(6),
      longitude: longitude.toFixed(6),
      pais: 'Brasil',
      estado: 'SP',
      cidade: 'São Paulo',
      mapa_url: gerarUrlMapa(latitude, longitude, endereco)
    }, 'Geocoding direto realizado com sucesso');

  } catch (error) {
    console.error('Erro ao fazer geocoding direto:', error);
    return ResponseHandler.serverError(res, 'Erro ao fazer geocoding direto');
  }
}

/**
 * Compartilhar localização com outro usuário
 */
async function compartilharLocalizacao(req, res) {
  try {
    const userId = req.userId;
    const { usuario_id_destino, duracao_minutos } = req.body;

    if (!usuario_id_destino) {
      return ResponseHandler.validationError(res, ['ID do usuário destino é obrigatório']);
    }

    // Verificar se usuário destino existe
    const usuarioDestino = await database.get(
      'SELECT id FROM usuarios WHERE id = ?',
      [usuario_id_destino]
    );

    if (!usuarioDestino) {
      return ResponseHandler.notFound(res, 'Usuário destino não encontrado');
    }

    // Criar compartilhamento
    const result = await database.run(
      `INSERT INTO compartilhamento_localizacao (usuario_origem, usuario_destino, duracao_minutos, data_inicio, ativo)
       VALUES (?, ?, ?, CURRENT_TIMESTAMP, 1)`,
      [userId, usuario_id_destino, duracao_minutos || 60]
    );

    return ResponseHandler.success(res, {
      compartilhamento_id: result.id,
      usuario_origem: userId,
      usuario_destino: usuario_id_destino,
      duracao_minutos: duracao_minutos || 60,
      data_inicio: new Date().toISOString(),
      ativo: true
    }, 'Localização compartilhada com sucesso');

  } catch (error) {
    console.error('Erro ao compartilhar localização:', error);
    return ResponseHandler.serverError(res, 'Erro ao compartilhar localização');
  }
}

/**
 * Parar compartilhamento de localização
 */
async function pararCompartilhamento(req, res) {
  try {
    const userId = req.userId;
    const { compartilhamento_id } = req.params;

    // Verificar se compartilhamento pertence ao usuário
    const compartilhamento = await database.get(
      'SELECT usuario_origem FROM compartilhamento_localizacao WHERE id = ?',
      [compartilhamento_id]
    );

    if (!compartilhamento) {
      return ResponseHandler.notFound(res, 'Compartilhamento não encontrado');
    }

    if (compartilhamento.usuario_origem !== userId) {
      return ResponseHandler.unauthorized(res, 'Você não tem permissão para parar este compartilhamento');
    }

    // Parar compartilhamento
    await database.run(
      'UPDATE compartilhamento_localizacao SET ativo = 0, data_fim = CURRENT_TIMESTAMP WHERE id = ?',
      [compartilhamento_id]
    );

    return ResponseHandler.success(res, null, 'Compartilhamento parado com sucesso');

  } catch (error) {
    console.error('Erro ao parar compartilhamento:', error);
    return ResponseHandler.serverError(res, 'Erro ao parar compartilhamento');
  }
}

module.exports = {
  atualizarLocalizacao,
  obterHistoricoLocalizacao,
  geocodingReverso,
  geocodingDireto,
  compartilharLocalizacao,
  pararCompartilhamento
};

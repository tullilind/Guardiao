const database = require('../config/database');
const ResponseHandler = require('../utils/responseHandler');

/**
 * Registrar ponto (entrada ou saída)
 */
async function registrar(req, res) {
  try {
    const { contratacao_id, tipo_registro, latitude, longitude } = req.body;

    if (!contratacao_id || !tipo_registro) {
      return ResponseHandler.validationError(res, ['Contratação e tipo de registro são obrigatórios']);
    }

    const tiposValidos = ['ENTRADA', 'SAIDA'];
    if (!tiposValidos.includes(tipo_registro)) {
      return ResponseHandler.validationError(res, ['Tipo de registro inválido. Use ENTRADA ou SAIDA']);
    }

    // Verificar se contratação existe
    const contratacao = await database.get(
      'SELECT * FROM contratacoes_servico WHERE id = ?',
      [contratacao_id]
    );

    if (!contratacao) {
      return ResponseHandler.notFound(res, 'Contratação não encontrada');
    }

    // Verificar se usuário é o prestador
    if (contratacao.id_prestador !== req.user.id) {
      return ResponseHandler.forbidden(res, 'Apenas o prestador pode registrar ponto');
    }

    // Verificar se serviço está em andamento
    if (contratacao.status_servico === 'Concluído') {
      return ResponseHandler.conflict(res, 'Não é possível registrar ponto em serviço concluído');
    }

    // Registrar ponto
    const result = await database.run(
      `INSERT INTO registro_ponto_os (contratacao_id, tipo_registro, latitude, longitude)
       VALUES (?, ?, ?, ?)`,
      [contratacao_id, tipo_registro, latitude || null, longitude || null]
    );

    // Se for entrada, atualizar status do serviço para "Em Andamento"
    if (tipo_registro === 'ENTRADA' && contratacao.status_servico === 'Agendado') {
      await database.run(
        'UPDATE contratacoes_servico SET status_servico = ? WHERE id = ?',
        ['Em Andamento', contratacao_id]
      );

      // Notificar solicitante
      await database.run(
        `INSERT INTO notificacoes_usuario (usuario_id, mensagem, link_acao)
         VALUES (?, ?, ?)`,
        [contratacao.id_solicitante, 'O prestador iniciou o serviço', `/contratacoes/${contratacao_id}`]
      );
    }

    // Se for saída, pode considerar concluir o serviço
    if (tipo_registro === 'SAIDA') {
      // Notificar solicitante
      await database.run(
        `INSERT INTO notificacoes_usuario (usuario_id, mensagem, link_acao)
         VALUES (?, ?, ?)`,
        [contratacao.id_solicitante, 'O prestador finalizou o serviço', `/contratacoes/${contratacao_id}`]
      );
    }

    return ResponseHandler.created(res, {
      id: result.id,
      tipo_registro,
      data_hora: new Date().toISOString()
    }, 'Ponto registrado com sucesso');

  } catch (error) {
    console.error('Erro ao registrar ponto:', error);
    return ResponseHandler.error(res, 'Erro ao registrar ponto');
  }
}

/**
 * Listar registros de ponto por contratação
 */
async function listarPorContratacao(req, res) {
  try {
    const { contratacao_id } = req.params;

    // Verificar se contratação existe
    const contratacao = await database.get(
      'SELECT * FROM contratacoes_servico WHERE id = ?',
      [contratacao_id]
    );

    if (!contratacao) {
      return ResponseHandler.notFound(res, 'Contratação não encontrada');
    }

    // Listar registros
    const registros = await database.all(
      `SELECT * FROM registro_ponto_os
       WHERE contratacao_id = ?
       ORDER BY data_hora ASC`,
      [contratacao_id]
    );

    // Calcular tempo total trabalhado
    let tempoTotal = 0;
    let entradaTemp = null;

    for (const registro of registros) {
      if (registro.tipo_registro === 'ENTRADA') {
        entradaTemp = new Date(registro.data_hora);
      } else if (registro.tipo_registro === 'SAIDA' && entradaTemp) {
        const saida = new Date(registro.data_hora);
        tempoTotal += (saida - entradaTemp) / 1000 / 60; // minutos
        entradaTemp = null;
      }
    }

    return ResponseHandler.success(res, {
      contratacao_id: parseInt(contratacao_id),
      total_registros: registros.length,
      tempo_total_minutos: Math.round(tempoTotal),
      tempo_total_horas: (tempoTotal / 60).toFixed(2),
      registros
    });

  } catch (error) {
    console.error('Erro ao listar registros de ponto:', error);
    return ResponseHandler.error(res, 'Erro ao listar registros de ponto');
  }
}

/**
 * Listar todos os registros do prestador
 */
async function listarPorPrestador(req, res) {
  try {
    const { id_prestador } = req.params;
    const { data_inicio, data_fim } = req.query;

    let sql = `SELECT r.*, c.servico_nome, c.id_solicitante
               FROM registro_ponto_os r
               INNER JOIN contratacoes_servico c ON r.contratacao_id = c.id
               WHERE c.id_prestador = ?`;
    let params = [id_prestador];

    if (data_inicio) {
      sql += ' AND DATE(r.data_hora) >= DATE(?)';
      params.push(data_inicio);
    }

    if (data_fim) {
      sql += ' AND DATE(r.data_hora) <= DATE(?)';
      params.push(data_fim);
    }

    sql += ' ORDER BY r.data_hora DESC';

    const registros = await database.all(sql, params);

    return ResponseHandler.success(res, {
      total: registros.length,
      registros
    });

  } catch (error) {
    console.error('Erro ao listar registros do prestador:', error);
    return ResponseHandler.error(res, 'Erro ao listar registros');
  }
}

/**
 * Obter último registro de uma contratação
 */
async function obterUltimo(req, res) {
  try {
    const { contratacao_id } = req.params;

    const ultimoRegistro = await database.get(
      `SELECT * FROM registro_ponto_os
       WHERE contratacao_id = ?
       ORDER BY data_hora DESC
       LIMIT 1`,
      [contratacao_id]
    );

    if (!ultimoRegistro) {
      return ResponseHandler.notFound(res, 'Nenhum registro encontrado para esta contratação');
    }

    return ResponseHandler.success(res, ultimoRegistro);

  } catch (error) {
    console.error('Erro ao obter último registro:', error);
    return ResponseHandler.error(res, 'Erro ao obter último registro');
  }
}

/**
 * Deletar registro de ponto
 */
async function deletar(req, res) {
  try {
    const { id } = req.params;

    const registro = await database.get(
      `SELECT r.*, c.id_prestador
       FROM registro_ponto_os r
       INNER JOIN contratacoes_servico c ON r.contratacao_id = c.id
       WHERE r.id = ?`,
      [id]
    );

    if (!registro) {
      return ResponseHandler.notFound(res, 'Registro não encontrado');
    }

    // Verificar permissão
    if (registro.id_prestador !== req.user.id) {
      return ResponseHandler.forbidden(res, 'Você não tem permissão para deletar este registro');
    }

    await database.run('DELETE FROM registro_ponto_os WHERE id = ?', [id]);

    return ResponseHandler.success(res, null, 'Registro deletado com sucesso');

  } catch (error) {
    console.error('Erro ao deletar registro:', error);
    return ResponseHandler.error(res, 'Erro ao deletar registro');
  }
}

/**
 * Obter relatório de horas trabalhadas
 */
async function relatorioHoras(req, res) {
  try {
    const { id_prestador } = req.params;
    const { mes, ano } = req.query;

    let sql = `SELECT 
                 DATE(r.data_hora) as data,
                 c.servico_nome,
                 c.id as contratacao_id,
                 GROUP_CONCAT(r.tipo_registro || ':' || r.data_hora) as registros
               FROM registro_ponto_os r
               INNER JOIN contratacoes_servico c ON r.contratacao_id = c.id
               WHERE c.id_prestador = ?`;
    let params = [id_prestador];

    if (mes && ano) {
      sql += ` AND strftime('%m', r.data_hora) = ? AND strftime('%Y', r.data_hora) = ?`;
      params.push(mes.toString().padStart(2, '0'), ano.toString());
    }

    sql += ' GROUP BY DATE(r.data_hora), c.id ORDER BY r.data_hora DESC';

    const dados = await database.all(sql, params);

    return ResponseHandler.success(res, {
      periodo: mes && ano ? `${mes}/${ano}` : 'Todos',
      total_dias: dados.length,
      dados
    });

  } catch (error) {
    console.error('Erro ao gerar relatório:', error);
    return ResponseHandler.error(res, 'Erro ao gerar relatório');
  }
}

module.exports = {
  registrar,
  listarPorContratacao,
  listarPorPrestador,
  obterUltimo,
  deletar,
  relatorioHoras
};

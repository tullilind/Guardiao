const ResponseHandler = require('../utils/responseHandler');

/**
 * Middleware global de tratamento de erros
 */
function errorHandler(err, req, res, next) {
  console.error('Erro capturado:', err);

  // Erro de validação do Joi
  if (err.isJoi) {
    return ResponseHandler.validationError(res, err.details.map(d => d.message));
  }

  // Erro de sintaxe JSON
  if (err instanceof SyntaxError && err.status === 400 && 'body' in err) {
    return ResponseHandler.error(res, 'JSON inválido', 400);
  }

  // Erro de banco de dados SQLite
  if (err.code) {
    switch (err.code) {
      case 'SQLITE_CONSTRAINT':
        return ResponseHandler.conflict(res, 'Violação de restrição de dados');
      case 'SQLITE_ERROR':
        return ResponseHandler.error(res, 'Erro no banco de dados');
      default:
        return ResponseHandler.error(res, 'Erro interno do servidor');
    }
  }

  // Erro genérico
  return ResponseHandler.error(
    res,
    err.message || 'Erro interno do servidor',
    err.statusCode || 500
  );
}

/**
 * Middleware para rotas não encontradas
 */
function notFoundHandler(req, res) {
  return ResponseHandler.notFound(res, `Rota ${req.method} ${req.path} não encontrada`);
}

module.exports = {
  errorHandler,
  notFoundHandler
};

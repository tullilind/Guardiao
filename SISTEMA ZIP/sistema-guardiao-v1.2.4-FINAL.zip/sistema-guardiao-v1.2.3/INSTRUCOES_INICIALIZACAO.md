# 🚀 Instruções de Inicialização - Sistema Guardião v1.2.4

## 📋 Passo a Passo

### 1️⃣ Instalar Dependências

```bash
cd sistema-guardiao-v1.2.3
npm install
```

### 2️⃣ Inicializar o Banco de Dados

**IMPORTANTE:** Execute este comando antes de iniciar o servidor pela primeira vez.

```bash
npm run init-db
```

Este comando irá:
- Criar o arquivo `database/database.db`
- Criar todas as tabelas necessárias
- Criar índices para otimização
- Preparar o sistema para uso

### 3️⃣ Iniciar o Servidor

```bash
npm start
```

O servidor estará disponível em: `http://localhost:3005`

---

## 🔐 Criar Usuário Administrador para Backup

Para acessar a interface de backup e gerenciar o banco de dados, você precisa criar um usuário administrador.

### Opção 1: Usando o Script Automático

```bash
node src/config/addBiometria.js
```

Este script irá:
1. Solicitar nome de usuário
2. Solicitar senha
3. Criar o usuário administrador no banco
4. Exibir confirmação

### Opção 2: Criação Manual via SQL

Se preferir, você pode criar manualmente executando:

```bash
sqlite3 database/database.db
```

Depois execute:

```sql
INSERT INTO admin_backup (nome_usuario, senha_hash) 
VALUES ('admin', '$2b$10$HASH_AQUI');
```

**Nota:** Para gerar o hash da senha, use bcrypt com 10 rounds.

---

## 🌐 Acessos Importantes

### API Principal
```
http://localhost:3005
```

### Health Check
```
http://localhost:3005/health
```

### Interface de Backup
```
http://localhost:3005/backup-interface
```

**Credenciais:** Use o usuário administrador criado no passo anterior.

---

## 📊 Endpoints Principais

### Autenticação
- `POST /api/auth/register` - Cadastrar novo usuário
- `POST /api/auth/login` - Fazer login
- `GET /api/auth/me` - Obter dados do usuário logado

### Documentos
- `POST /api/documentos` - Enviar documento(s) para validação
- `GET /api/documentos/pendentes` - Listar documentos pendentes
- `PUT /api/documentos/:id/status` - Aprovar/Rejeitar documento

### Biometria Facial
- `GET /api/verificacao/usuario/:id/biometria` - Verificar se tem biometria
- `POST /api/verificacao/usuario/:id/biometria` - Cadastrar biometria
- `POST /api/verificacao/usuario/:id/biometria/autenticar` - Autenticar por face

---

## 🛠️ Comandos Úteis

### Reiniciar Banco de Dados (APAGA TODOS OS DADOS)
```bash
rm -f database/database.db
npm run init-db
```

### Verificar Logs do Servidor
Os logs aparecem no terminal onde você executou `npm start`

### Parar o Servidor
Pressione `Ctrl + C` no terminal

---

## ⚠️ Solução de Problemas

### Erro: "EADDRINUSE: address already in use"
A porta 3005 já está em uso. Pare o processo ou mude a porta no arquivo `.env`:
```
PORT=3006
```

### Erro: "SQLITE_ERROR: no such table: usuarios"
O banco de dados não foi inicializado. Execute:
```bash
npm run init-db
```

### Erro: "Cannot find module 'express'"
As dependências não foram instaladas. Execute:
```bash
npm install
```

### Erro na API de Biometria: "CONCURRENCY_LIMIT_EXCEEDED"
Limite de requisições simultâneas da API Face++ foi atingido. Aguarde alguns segundos e tente novamente.

### Erro: "Nenhuma face detectada na imagem"
- Verifique se a imagem contém um rosto visível
- Certifique-se de que há boa iluminação
- Use imagens em formato JPG ou PNG
- Tamanho recomendado: entre 200x200 e 2000x2000 pixels

---

## 📧 Configuração de E-mail

O sistema usa a API do Google Apps Script para envio de e-mails. A configuração já está pronta em:

```
src/utils/emailHelper.js
```

**URL da API:** https://script.google.com/macros/s/AKfycbwN8jiiMzm0Win5XRYUqmE11CXEiuoMzeROmYPz8MxcvutXBhGtr-LxjtXB18stlAD_jQ/exec

---

## 🔒 Segurança

- **JWT Secret:** Configurado em `.env` (JWT_SECRET)
- **Senha do Banco:** Não há senha (SQLite local)
- **CORS:** Habilitado para todas as origens (desenvolvimento)

**Para produção:** Altere as configurações de CORS em `src/server.js`

---

## 📦 Estrutura de Pastas

```
sistema-guardiao-v1.2.3/
├── database/              # Banco de dados SQLite
├── public/                # Interface de backup
├── src/
│   ├── config/           # Configurações e inicialização
│   ├── controllers/      # Lógica de negócio
│   ├── middlewares/      # Autenticação e tratamento de erros
│   ├── routes/           # Definição de rotas
│   ├── utils/            # Utilitários (e-mail, Face++, etc)
│   └── server.js         # Arquivo principal
├── .env                  # Variáveis de ambiente
├── package.json          # Dependências
└── README.md             # Documentação
```

---

## ✅ Checklist de Inicialização

- [ ] Dependências instaladas (`npm install`)
- [ ] Banco de dados inicializado (`npm run init-db`)
- [ ] Servidor iniciado (`npm start`)
- [ ] Usuário admin criado para backup
- [ ] Testado endpoint de health check
- [ ] Testado cadastro de usuário
- [ ] Testado login

---

**Versão:** 1.2.4  
**Data:** 23/11/2025  
**Suporte:** Sistema Guardião Mais

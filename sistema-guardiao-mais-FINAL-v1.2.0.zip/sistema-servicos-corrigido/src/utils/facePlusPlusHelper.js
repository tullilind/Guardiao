const axios = require('axios');
const FormData = require('form-data');

/**
 * Helper para integração com Face++ API
 */

const FACE_API_KEY = 'lOHREhzgNbKmjGyEE_-UmVvQnkpTVolo';
const FACE_API_SECRET = 'yI_Cu6m1m_8C7BQESyvd7VIbUs0yVCUz';
const FACE_API_BASE_URL = 'https://api-us.faceplusplus.com/facepp/v3';

/**
 * Detectar face em uma imagem
 * @param {Buffer|String} imagemBuffer - Buffer da imagem ou base64
 * @returns {Object} - Dados da face detectada incluindo face_token
 */
async function detectarFace(imagemBuffer) {
  try {
    const formData = new FormData();
    formData.append('api_key', FACE_API_KEY);
    formData.append('api_secret', FACE_API_SECRET);
    
    // Se for base64, converter para buffer
    let buffer = imagemBuffer;
    if (typeof imagemBuffer === 'string') {
      // Remover prefixo data:image se existir
      const base64Data = imagemBuffer.replace(/^data:image\/\w+;base64,/, '');
      buffer = Buffer.from(base64Data, 'base64');
    }
    
    formData.append('image_file', buffer, { filename: 'face.jpg' });

    const response = await axios.post(`${FACE_API_BASE_URL}/detect`, formData, {
      headers: formData.getHeaders(),
      timeout: 30000
    });

    if (response.data && response.data.faces && response.data.faces.length > 0) {
      return {
        success: true,
        face_token: response.data.faces[0].face_token,
        face_rectangle: response.data.faces[0].face_rectangle,
        total_faces: response.data.faces.length
      };
    } else {
      return {
        success: false,
        message: 'Nenhuma face detectada na imagem'
      };
    }
  } catch (error) {
    console.error('❌ Erro ao detectar face:', error.response?.data || error.message);
    return {
      success: false,
      message: error.response?.data?.error_message || 'Erro ao processar imagem',
      error: error.message
    };
  }
}

/**
 * Comparar duas faces
 * @param {String} faceToken1 - Token da primeira face
 * @param {String} faceToken2 - Token da segunda face
 * @returns {Object} - Resultado da comparação com confiança
 */
async function compararFaces(faceToken1, faceToken2) {
  try {
    const formData = new FormData();
    formData.append('api_key', FACE_API_KEY);
    formData.append('api_secret', FACE_API_SECRET);
    formData.append('face_token1', faceToken1);
    formData.append('face_token2', faceToken2);

    const response = await axios.post(`${FACE_API_BASE_URL}/compare`, formData, {
      headers: formData.getHeaders(),
      timeout: 30000
    });

    if (response.data && response.data.confidence !== undefined) {
      const confianca = response.data.confidence;
      const limiarConfianca = 70; // 70% de confiança mínima
      
      return {
        success: true,
        mesma_pessoa: confianca >= limiarConfianca,
        confianca: confianca,
        thresholds: response.data.thresholds
      };
    } else {
      return {
        success: false,
        message: 'Erro ao comparar faces'
      };
    }
  } catch (error) {
    console.error('❌ Erro ao comparar faces:', error.response?.data || error.message);
    return {
      success: false,
      message: error.response?.data?.error_message || 'Erro ao comparar faces',
      error: error.message
    };
  }
}

/**
 * Cadastrar face inicial do usuário
 * @param {Buffer|String} imagemBuffer - Buffer da imagem ou base64
 * @returns {Object} - Dados do cadastro incluindo face_token
 */
async function cadastrarFaceInicial(imagemBuffer) {
  const resultado = await detectarFace(imagemBuffer);
  
  if (resultado.success) {
    return {
      success: true,
      face_token: resultado.face_token,
      face_rectangle: resultado.face_rectangle,
      message: 'Face cadastrada com sucesso'
    };
  } else {
    return resultado;
  }
}

/**
 * Verificar e autenticar usuário por face
 * @param {String} faceTokenCadastrado - Token da face cadastrada no banco
 * @param {Buffer|String} novaImagem - Nova imagem para comparação
 * @returns {Object} - Resultado da autenticação
 */
async function autenticarPorFace(faceTokenCadastrado, novaImagem) {
  // Primeiro detectar a face na nova imagem
  const deteccao = await detectarFace(novaImagem);
  
  if (!deteccao.success) {
    return {
      success: false,
      autenticado: false,
      message: deteccao.message
    };
  }

  // Comparar as faces
  const comparacao = await compararFaces(faceTokenCadastrado, deteccao.face_token);
  
  if (comparacao.success) {
    return {
      success: true,
      autenticado: comparacao.mesma_pessoa,
      confianca: comparacao.confianca,
      message: comparacao.mesma_pessoa 
        ? 'Autenticação facial bem-sucedida' 
        : 'Face não corresponde ao usuário cadastrado'
    };
  } else {
    return comparacao;
  }
}

module.exports = {
  detectarFace,
  compararFaces,
  cadastrarFaceInicial,
  autenticarPorFace
};

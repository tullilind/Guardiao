const database = require('./database');

async function addBiometriaTable() {
  try {
    await database.connect();
    console.log('Adicionando tabela de biometria...\n');

    // Criar tabela de biometria
    await database.run(`
      CREATE TABLE IF NOT EXISTS biometria_usuario (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        usuario_id INTEGER UNIQUE NOT NULL,
        dados_biometria TEXT NOT NULL,
        data_cadastro DATETIME DEFAULT CURRENT_TIMESTAMP,
        data_atualizacao DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
      )
    `);
    console.log('✓ Tabela biometria_usuario criada');

    // Criar índice
    await database.run('CREATE INDEX IF NOT EXISTS idx_biometria_usuario ON biometria_usuario(usuario_id)');
    console.log('✓ Índice criado');

    console.log('\n✅ Tabela de biometria adicionada com sucesso!');
    
  } catch (error) {
    console.error('❌ Erro ao adicionar tabela de biometria:', error);
  } finally {
    await database.close();
  }
}

// Executar se chamado diretamente
if (require.main === module) {
  addBiometriaTable();
}

module.exports = addBiometriaTable;

const express = require('express');
const cors = require('cors');
const path = require('path');
require('dotenv').config();

const database = require('./config/database');
const { errorHandler, notFoundHandler } = require('./middlewares/errorHandler');

// Importar rotas
const authRoutes = require('./routes/auth');
const usuarioRoutes = require('./routes/usuarios');
const arquivoRoutes = require('./routes/arquivos');
const documentoRoutes = require('./routes/documentos');
const contratacaoRoutes = require('./routes/contratacoes');
const pontoRoutes = require('./routes/ponto');
const notificacaoRoutes = require('./routes/notificacoes');
const avaliacaoRoutes = require('./routes/avaliacoes');
const prestadorRoutes = require('./routes/prestadores');
const verificacaoRoutes = require('./routes/verificacao');
const logRoutes = require('./routes/logs');
const backupRoutes = require('./routes/backup');
const midiaRoutes = require('./routes/midia');
const localizacaoRoutes = require('./routes/localizacao');

const app = express();
const PORT = process.env.PORT || 3005;

// Middlewares globais
app.use(cors());
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Servir arquivos estáticos (interface de backup)
app.use('/backup-interface', express.static(path.join(__dirname, '../public')));

// Rota de health check
app.get('/health', (req, res) => {
  res.json({
    status: 'OK',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
    database: 'Connected'
  });
});

// Rota raiz
app.get('/', (req, res) => {
  res.json({
    message: 'Sistema de Gerenciamento de Serviços - API',
    version: '1.0.0',
    endpoints: {
      auth: '/api/auth',
      usuarios: '/api/usuarios',
      arquivos: '/api/arquivos',
      documentos: '/api/documentos',
      contratacoes: '/api/contratacoes',
      ponto: '/api/ponto',
      notificacoes: '/api/notificacoes',
      avaliacoes: '/api/avaliacoes',
      prestadores: '/api/prestadores',
      verificacao: '/api/verificacao',
      logs: '/api/logs',
      backup: '/api/backup'
    },
    backup_interface: '/backup-interface'
  });
});

// Registrar rotas da API
app.use('/api/auth', authRoutes);
app.use('/api/usuarios', usuarioRoutes);
app.use('/api/arquivos', arquivoRoutes);
app.use('/api/documentos', documentoRoutes);
app.use('/api/contratacoes', contratacaoRoutes);
app.use('/api/ponto', pontoRoutes);
app.use('/api/notificacoes', notificacaoRoutes);
app.use('/api/avaliacoes', avaliacaoRoutes);
app.use('/api/prestadores', prestadorRoutes);
app.use('/api/verificacao', verificacaoRoutes);
app.use('/api/logs', logRoutes);
app.use('/api/backup', backupRoutes);
app.use('/api/midia', midiaRoutes);
app.use('/api/localizacao', localizacaoRoutes);

// Middleware de rota não encontrada
app.use(notFoundHandler);

// Middleware de tratamento de erros
app.use(errorHandler);

// Iniciar servidor
async function startServer() {
  try {
    // Conectar ao banco de dados
    await database.connect();
    
    // Iniciar servidor HTTP
    app.listen(PORT, () => {
      console.log('═══════════════════════════════════════════════════════');
      console.log('  Sistema de Gerenciamento de Serviços - API');
      console.log('═══════════════════════════════════════════════════════');
      console.log(`✓ Servidor rodando na porta ${PORT}`);
      console.log(`✓ Ambiente: ${process.env.NODE_ENV || 'development'}`);
      console.log(`✓ API disponível em: http://localhost:${PORT}`);
      console.log(`✓ Interface de Backup: http://localhost:${PORT}/backup-interface`);
      console.log('═══════════════════════════════════════════════════════');
      console.log('\nEndpoints disponíveis:');
      console.log('  POST   /api/auth/register');
      console.log('  POST   /api/auth/login');
      console.log('  POST   /api/auth/recuperar-senha');
      console.log('  POST   /api/auth/redefinir-senha');
      console.log('  GET    /api/auth/me');
      console.log('  GET    /api/usuarios');
      console.log('  GET    /api/prestadores');
      console.log('  GET    /api/prestadores/verificados');
      console.log('  GET    /api/documentos/pendentes');
      console.log('  GET    /api/documentos/aprovados');
      console.log('  GET    /api/verificacao/usuarios/verificados');
      console.log('  GET    /api/verificacao/usuarios/pendentes');
      console.log('  POST   /api/contratacoes');
      console.log('  POST   /api/ponto/registrar');
      console.log('  POST   /api/avaliacoes');
      console.log('  POST   /api/backup/criar');
      console.log('  ... e muitos outros!');
      console.log('═══════════════════════════════════════════════════════\n');
    });
  } catch (error) {
    console.error('❌ Erro ao iniciar servidor:', error);
    process.exit(1);
  }
}

// Tratamento de encerramento gracioso
process.on('SIGINT', async () => {
  console.log('\n\n🛑 Encerrando servidor...');
  await database.close();
  process.exit(0);
});

process.on('SIGTERM', async () => {
  console.log('\n\n🛑 Encerrando servidor...');
  await database.close();
  process.exit(0);
});

// Iniciar
startServer();

module.exports = app;

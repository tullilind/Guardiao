const database = require('../config/database');
const ResponseHandler = require('../utils/responseHandler');

/**
 * Criar novo documento de validação
 */
async function criar(req, res) {
  try {
    const { arquivo_id, tipo_documento } = req.body;
    
    // Pegar usuario_id do token JWT (usuário autenticado)
    const usuario_id = req.user.id;

    if (!arquivo_id || !tipo_documento) {
      return ResponseHandler.validationError(res, ['Arquivo e tipo de documento são obrigatórios']);
    }

    // Verificar se arquivo existe
    const arquivo = await database.get(
      'SELECT id FROM arquivos_sistema WHERE id = ?',
      [arquivo_id]
    );

    if (!arquivo) {
      return ResponseHandler.notFound(res, 'Arquivo não encontrado');
    }

    // Inserir documento
    const result = await database.run(
      `INSERT INTO documentos_validacao (usuario_id, arquivo_id, tipo_documento, status)
       VALUES (?, ?, ?, 'Pendente')`,
      [usuario_id, arquivo_id, tipo_documento]
    );

    // Criar notificação para o usuário
    await database.run(
      `INSERT INTO notificacoes_usuario (usuario_id, mensagem, link_acao)
       VALUES (?, ?, ?)`,
      [usuario_id, `Documento ${tipo_documento} enviado para validação`, `/documentos/${result.id}`]
    );

    return ResponseHandler.created(res, { id: result.id }, 'Documento enviado para validação');
  } catch (error) {
    console.error('Erro ao criar documento:', error);
    return ResponseHandler.error(res, 'Erro ao criar documento');
  }
}

/**
 * Listar documentos por usuário
 */
async function listarPorUsuario(req, res) {
  try {
    const { usuario_id } = req.params;
    const { status } = req.query;

    let sql = `SELECT d.*, a.mime_type, a.tamanho_kb
               FROM documentos_validacao d
               LEFT JOIN arquivos_sistema a ON d.arquivo_id = a.id
               WHERE d.usuario_id = ?`;
    let params = [usuario_id];

    // Filtro por status
    if (status) {
      sql += ' AND d.status = ?';
      params.push(status);
    }

    sql += ' ORDER BY d.data_envio DESC';

    const documentos = await database.all(sql, params);

    return ResponseHandler.success(res, documentos);
  } catch (error) {
    console.error('Erro ao listar documentos:', error);
    return ResponseHandler.error(res, 'Erro ao listar documentos');
  }
}

/**
 * Listar todos os documentos pendentes
 */
async function listarPendentes(req, res) {
  try {
    const documentos = await database.all(
      `SELECT d.*, u.nome_completo, u.email, a.mime_type, a.tamanho_kb
       FROM documentos_validacao d
       INNER JOIN usuarios u ON d.usuario_id = u.id
       LEFT JOIN arquivos_sistema a ON d.arquivo_id = a.id
       WHERE d.status = 'Pendente'
       ORDER BY d.data_envio ASC`
    );

    return ResponseHandler.success(res, {
      total: documentos.length,
      documentos
    });
  } catch (error) {
    console.error('Erro ao listar documentos pendentes:', error);
    return ResponseHandler.error(res, 'Erro ao listar documentos pendentes');
  }
}

/**
 * Listar documentos aprovados
 */
async function listarAprovados(req, res) {
  try {
    const { usuario_id } = req.query;
    
    let sql = `SELECT d.*, u.nome_completo, a.mime_type, a.tamanho_kb
               FROM documentos_validacao d
               INNER JOIN usuarios u ON d.usuario_id = u.id
               LEFT JOIN arquivos_sistema a ON d.arquivo_id = a.id
               WHERE d.status = 'Aprovado'`;
    let params = [];

    if (usuario_id) {
      sql += ' AND d.usuario_id = ?';
      params.push(usuario_id);
    }

    sql += ' ORDER BY d.data_validacao DESC';

    const documentos = await database.all(sql, params);

    return ResponseHandler.success(res, {
      total: documentos.length,
      documentos
    });
  } catch (error) {
    console.error('Erro ao listar documentos aprovados:', error);
    return ResponseHandler.error(res, 'Erro ao listar documentos aprovados');
  }
}

/**
 * Listar documentos rejeitados
 */
async function listarRejeitados(req, res) {
  try {
    const { usuario_id } = req.query;
    
    let sql = `SELECT d.*, u.nome_completo, a.mime_type, a.tamanho_kb
               FROM documentos_validacao d
               INNER JOIN usuarios u ON d.usuario_id = u.id
               LEFT JOIN arquivos_sistema a ON d.arquivo_id = a.id
               WHERE d.status = 'Rejeitado'`;
    let params = [];

    if (usuario_id) {
      sql += ' AND d.usuario_id = ?';
      params.push(usuario_id);
    }

    sql += ' ORDER BY d.data_validacao DESC';

    const documentos = await database.all(sql, params);

    return ResponseHandler.success(res, {
      total: documentos.length,
      documentos
    });
  } catch (error) {
    console.error('Erro ao listar documentos rejeitados:', error);
    return ResponseHandler.error(res, 'Erro ao listar documentos rejeitados');
  }
}

/**
 * Obter documento por ID
 */
async function obterPorId(req, res) {
  try {
    const { id } = req.params;

    const documento = await database.get(
      `SELECT d.*, u.nome_completo, u.email, a.mime_type, a.tamanho_kb
       FROM documentos_validacao d
       INNER JOIN usuarios u ON d.usuario_id = u.id
       LEFT JOIN arquivos_sistema a ON d.arquivo_id = a.id
       WHERE d.id = ?`,
      [id]
    );

    if (!documento) {
      return ResponseHandler.notFound(res, 'Documento não encontrado');
    }

    return ResponseHandler.success(res, documento);
  } catch (error) {
    console.error('Erro ao obter documento:', error);
    return ResponseHandler.error(res, 'Erro ao obter documento');
  }
}

/**
 * Atualizar status do documento
 */
async function atualizarStatus(req, res) {
  try {
    const { id } = req.params;
    const { status, motivo_rejeicao } = req.body;

    if (!status) {
      return ResponseHandler.validationError(res, ['Status é obrigatório']);
    }

    const statusValidos = ['Pendente', 'Aprovado', 'Rejeitado'];
    if (!statusValidos.includes(status)) {
      return ResponseHandler.validationError(res, ['Status inválido']);
    }

    if (status === 'Rejeitado' && !motivo_rejeicao) {
      return ResponseHandler.validationError(res, ['Motivo da rejeição é obrigatório']);
    }

    // Verificar se documento existe
    const documento = await database.get(
      'SELECT * FROM documentos_validacao WHERE id = ?',
      [id]
    );

    if (!documento) {
      return ResponseHandler.notFound(res, 'Documento não encontrado');
    }

    // Atualizar status
    await database.run(
      `UPDATE documentos_validacao 
       SET status = ?, motivo_rejeicao = ?, data_validacao = CURRENT_TIMESTAMP
       WHERE id = ?`,
      [status, motivo_rejeicao || null, id]
    );

    // Se aprovado, verificar se todos os documentos do usuário foram aprovados
    if (status === 'Aprovado') {
      const documentosPendentes = await database.get(
        `SELECT COUNT(*) as total FROM documentos_validacao 
         WHERE usuario_id = ? AND status = 'Pendente'`,
        [documento.usuario_id]
      );

      // Se não há mais documentos pendentes, marcar perfil como verificado
      if (documentosPendentes.total === 0) {
        await database.run(
          'UPDATE usuarios SET perfil_verificado = 1 WHERE id = ?',
          [documento.usuario_id]
        );

        // Criar notificação
        await database.run(
          `INSERT INTO notificacoes_usuario (usuario_id, mensagem, link_acao)
           VALUES (?, ?, ?)`,
          [documento.usuario_id, 'Parabéns! Seu perfil foi verificado com sucesso', '/perfil']
        );
      }
    }

    // Criar notificação para o usuário
    const mensagem = status === 'Aprovado' 
      ? `Documento ${documento.tipo_documento} foi aprovado`
      : `Documento ${documento.tipo_documento} foi rejeitado: ${motivo_rejeicao}`;

    await database.run(
      `INSERT INTO notificacoes_usuario (usuario_id, mensagem, link_acao)
       VALUES (?, ?, ?)`,
      [documento.usuario_id, mensagem, `/documentos/${id}`]
    );

    return ResponseHandler.success(res, null, 'Status do documento atualizado com sucesso');
  } catch (error) {
    console.error('Erro ao atualizar status do documento:', error);
    return ResponseHandler.error(res, 'Erro ao atualizar status do documento');
  }
}

/**
 * Obter estatísticas de documentos
 */
async function obterEstatisticas(req, res) {
  try {
    const { usuario_id } = req.query;

    let whereClause = '';
    let params = [];

    if (usuario_id) {
      whereClause = 'WHERE usuario_id = ?';
      params.push(usuario_id);
    }

    const stats = await database.get(
      `SELECT 
        COUNT(*) as total,
        SUM(CASE WHEN status = 'Pendente' THEN 1 ELSE 0 END) as pendentes,
        SUM(CASE WHEN status = 'Aprovado' THEN 1 ELSE 0 END) as aprovados,
        SUM(CASE WHEN status = 'Rejeitado' THEN 1 ELSE 0 END) as rejeitados
       FROM documentos_validacao ${whereClause}`,
      params
    );

    return ResponseHandler.success(res, stats);
  } catch (error) {
    console.error('Erro ao obter estatísticas:', error);
    return ResponseHandler.error(res, 'Erro ao obter estatísticas');
  }
}

module.exports = {
  criar,
  listarPorUsuario,
  listarPendentes,
  listarAprovados,
  listarRejeitados,
  obterPorId,
  atualizarStatus,
  obterEstatisticas
};

const database = require('../config/database');
const ResponseHandler = require('../utils/responseHandler');

/**
 * Criar nova contratação de serviço
 */
async function criar(req, res) {
  try {
    const {
      id_prestador,
      id_solicitante,
      servico_nome,
      servico_descricao,
      valor_acordado
    } = req.body;

    if (!id_prestador || !id_solicitante || !servico_nome || !valor_acordado) {
      return ResponseHandler.validationError(res, ['Campos obrigatórios faltando']);
    }

    if (valor_acordado <= 0) {
      return ResponseHandler.validationError(res, ['Valor deve ser maior que zero']);
    }

    // Verificar se prestador existe
    const prestador = await database.get(
      'SELECT id, nome_completo FROM usuarios WHERE id = ?',
      [id_prestador]
    );

    if (!prestador) {
      return ResponseHandler.notFound(res, 'Prestador não encontrado');
    }

    // Verificar se solicitante existe
    const solicitante = await database.get(
      'SELECT id, nome_completo FROM usuarios WHERE id = ?',
      [id_solicitante]
    );

    if (!solicitante) {
      return ResponseHandler.notFound(res, 'Solicitante não encontrado');
    }

    // Criar contratação
    const result = await database.run(
      `INSERT INTO contratacoes_servico 
       (id_prestador, id_solicitante, servico_nome, servico_descricao, valor_acordado, status_pagamento, status_servico)
       VALUES (?, ?, ?, ?, ?, 'Pendente', 'Agendado')`,
      [id_prestador, id_solicitante, servico_nome, servico_descricao || null, valor_acordado]
    );

    // Criar notificações
    await database.run(
      `INSERT INTO notificacoes_usuario (usuario_id, mensagem, link_acao)
       VALUES (?, ?, ?)`,
      [id_prestador, `Nova contratação: ${servico_nome}`, `/contratacoes/${result.id}`]
    );

    await database.run(
      `INSERT INTO notificacoes_usuario (usuario_id, mensagem, link_acao)
       VALUES (?, ?, ?)`,
      [id_solicitante, `Contratação criada: ${servico_nome}`, `/contratacoes/${result.id}`]
    );

    return ResponseHandler.created(res, { id: result.id }, 'Contratação criada com sucesso');
  } catch (error) {
    console.error('Erro ao criar contratação:', error);
    return ResponseHandler.error(res, 'Erro ao criar contratação');
  }
}

/**
 * Obter contratação por ID
 */
async function obterPorId(req, res) {
  try {
    const { id } = req.params;

    const contratacao = await database.get(
      `SELECT c.*, 
              p.nome_completo as prestador_nome, p.email as prestador_email,
              s.nome_completo as solicitante_nome, s.email as solicitante_email
       FROM contratacoes_servico c
       INNER JOIN usuarios p ON c.id_prestador = p.id
       INNER JOIN usuarios s ON c.id_solicitante = s.id
       WHERE c.id = ?`,
      [id]
    );

    if (!contratacao) {
      return ResponseHandler.notFound(res, 'Contratação não encontrada');
    }

    return ResponseHandler.success(res, contratacao);
  } catch (error) {
    console.error('Erro ao obter contratação:', error);
    return ResponseHandler.error(res, 'Erro ao obter contratação');
  }
}

/**
 * Listar contratações do prestador
 */
async function listarPorPrestador(req, res) {
  try {
    const { id_prestador } = req.params;
    const { status_servico, status_pagamento } = req.query;

    let sql = `SELECT c.*, s.nome_completo as solicitante_nome
               FROM contratacoes_servico c
               INNER JOIN usuarios s ON c.id_solicitante = s.id
               WHERE c.id_prestador = ?`;
    let params = [id_prestador];

    if (status_servico) {
      sql += ' AND c.status_servico = ?';
      params.push(status_servico);
    }

    if (status_pagamento) {
      sql += ' AND c.status_pagamento = ?';
      params.push(status_pagamento);
    }

    sql += ' ORDER BY c.data_contrato DESC';

    const contratacoes = await database.all(sql, params);

    return ResponseHandler.success(res, {
      total: contratacoes.length,
      contratacoes
    });
  } catch (error) {
    console.error('Erro ao listar contratações do prestador:', error);
    return ResponseHandler.error(res, 'Erro ao listar contratações');
  }
}

/**
 * Listar contratações do solicitante
 */
async function listarPorSolicitante(req, res) {
  try {
    const { id_solicitante } = req.params;
    const { status_servico, status_pagamento } = req.query;

    let sql = `SELECT c.*, p.nome_completo as prestador_nome, p.media_avaliacao
               FROM contratacoes_servico c
               INNER JOIN usuarios p ON c.id_prestador = p.id
               WHERE c.id_solicitante = ?`;
    let params = [id_solicitante];

    if (status_servico) {
      sql += ' AND c.status_servico = ?';
      params.push(status_servico);
    }

    if (status_pagamento) {
      sql += ' AND c.status_pagamento = ?';
      params.push(status_pagamento);
    }

    sql += ' ORDER BY c.data_contrato DESC';

    const contratacoes = await database.all(sql, params);

    return ResponseHandler.success(res, {
      total: contratacoes.length,
      contratacoes
    });
  } catch (error) {
    console.error('Erro ao listar contratações do solicitante:', error);
    return ResponseHandler.error(res, 'Erro ao listar contratações');
  }
}

/**
 * Listar todas as contratações (com filtros)
 */
async function listar(req, res) {
  try {
    const { status_servico, status_pagamento, page = 1, limit = 10 } = req.query;
    const offset = (page - 1) * limit;

    let sql = `SELECT c.*, 
                      p.nome_completo as prestador_nome,
                      s.nome_completo as solicitante_nome
               FROM contratacoes_servico c
               INNER JOIN usuarios p ON c.id_prestador = p.id
               INNER JOIN usuarios s ON c.id_solicitante = s.id
               WHERE 1=1`;
    let params = [];

    if (status_servico) {
      sql += ' AND c.status_servico = ?';
      params.push(status_servico);
    }

    if (status_pagamento) {
      sql += ' AND c.status_pagamento = ?';
      params.push(status_pagamento);
    }

    sql += ' ORDER BY c.data_contrato DESC LIMIT ? OFFSET ?';
    params.push(parseInt(limit), parseInt(offset));

    const contratacoes = await database.all(sql, params);

    // Contar total
    let countSql = 'SELECT COUNT(*) as total FROM contratacoes_servico WHERE 1=1';
    let countParams = [];
    if (status_servico) {
      countSql += ' AND status_servico = ?';
      countParams.push(status_servico);
    }
    if (status_pagamento) {
      countSql += ' AND status_pagamento = ?';
      countParams.push(status_pagamento);
    }

    const { total } = await database.get(countSql, countParams);

    return ResponseHandler.success(res, {
      contratacoes,
      paginacao: {
        total,
        pagina_atual: parseInt(page),
        total_paginas: Math.ceil(total / limit),
        itens_por_pagina: parseInt(limit)
      }
    });
  } catch (error) {
    console.error('Erro ao listar contratações:', error);
    return ResponseHandler.error(res, 'Erro ao listar contratações');
  }
}

/**
 * Atualizar status do serviço
 */
async function atualizarStatusServico(req, res) {
  try {
    const { id } = req.params;
    const { status_servico } = req.body;

    const statusValidos = ['Agendado', 'Em Andamento', 'Concluído', 'Cancelado'];
    if (!statusValidos.includes(status_servico)) {
      return ResponseHandler.validationError(res, ['Status de serviço inválido']);
    }

    // Verificar se contratação existe
    const contratacao = await database.get(
      'SELECT * FROM contratacoes_servico WHERE id = ?',
      [id]
    );

    if (!contratacao) {
      return ResponseHandler.notFound(res, 'Contratação não encontrada');
    }

    // Atualizar status
    const updates = ['status_servico = ?'];
    const params = [status_servico];

    // Se concluído, adicionar data de conclusão
    if (status_servico === 'Concluído') {
      updates.push('data_conclusao = CURRENT_TIMESTAMP');
    }

    params.push(id);
    await database.run(
      `UPDATE contratacoes_servico SET ${updates.join(', ')} WHERE id = ?`,
      params
    );

    // Criar notificações
    await database.run(
      `INSERT INTO notificacoes_usuario (usuario_id, mensagem, link_acao)
       VALUES (?, ?, ?)`,
      [contratacao.id_prestador, `Serviço atualizado para: ${status_servico}`, `/contratacoes/${id}`]
    );

    await database.run(
      `INSERT INTO notificacoes_usuario (usuario_id, mensagem, link_acao)
       VALUES (?, ?, ?)`,
      [contratacao.id_solicitante, `Serviço atualizado para: ${status_servico}`, `/contratacoes/${id}`]
    );

    return ResponseHandler.success(res, null, 'Status do serviço atualizado com sucesso');
  } catch (error) {
    console.error('Erro ao atualizar status do serviço:', error);
    return ResponseHandler.error(res, 'Erro ao atualizar status do serviço');
  }
}

/**
 * Atualizar status do pagamento
 */
async function atualizarStatusPagamento(req, res) {
  try {
    const { id } = req.params;
    const { status_pagamento } = req.body;

    const statusValidos = ['Pendente', 'Pago', 'Cancelado'];
    if (!statusValidos.includes(status_pagamento)) {
      return ResponseHandler.validationError(res, ['Status de pagamento inválido']);
    }

    // Verificar se contratação existe
    const contratacao = await database.get(
      'SELECT * FROM contratacoes_servico WHERE id = ?',
      [id]
    );

    if (!contratacao) {
      return ResponseHandler.notFound(res, 'Contratação não encontrada');
    }

    // Atualizar status
    await database.run(
      'UPDATE contratacoes_servico SET status_pagamento = ? WHERE id = ?',
      [status_pagamento, id]
    );

    // Criar notificações
    await database.run(
      `INSERT INTO notificacoes_usuario (usuario_id, mensagem, link_acao)
       VALUES (?, ?, ?)`,
      [contratacao.id_prestador, `Pagamento atualizado para: ${status_pagamento}`, `/contratacoes/${id}`]
    );

    return ResponseHandler.success(res, null, 'Status do pagamento atualizado com sucesso');
  } catch (error) {
    console.error('Erro ao atualizar status do pagamento:', error);
    return ResponseHandler.error(res, 'Erro ao atualizar status do pagamento');
  }
}

/**
 * Atualizar dados da contratação
 */
async function atualizar(req, res) {
  try {
    const { id } = req.params;
    const { servico_nome, servico_descricao, valor_acordado } = req.body;

    // Verificar se contratação existe
    const contratacao = await database.get(
      'SELECT * FROM contratacoes_servico WHERE id = ?',
      [id]
    );

    if (!contratacao) {
      return ResponseHandler.notFound(res, 'Contratação não encontrada');
    }

    const updates = [];
    const params = [];

    if (servico_nome) {
      updates.push('servico_nome = ?');
      params.push(servico_nome);
    }

    if (servico_descricao !== undefined) {
      updates.push('servico_descricao = ?');
      params.push(servico_descricao);
    }

    if (valor_acordado) {
      if (valor_acordado <= 0) {
        return ResponseHandler.validationError(res, ['Valor deve ser maior que zero']);
      }
      updates.push('valor_acordado = ?');
      params.push(valor_acordado);
    }

    if (updates.length === 0) {
      return ResponseHandler.validationError(res, ['Nenhum campo para atualizar']);
    }

    params.push(id);
    await database.run(
      `UPDATE contratacoes_servico SET ${updates.join(', ')} WHERE id = ?`,
      params
    );

    return ResponseHandler.success(res, null, 'Contratação atualizada com sucesso');
  } catch (error) {
    console.error('Erro ao atualizar contratação:', error);
    return ResponseHandler.error(res, 'Erro ao atualizar contratação');
  }
}

module.exports = {
  criar,
  obterPorId,
  listarPorPrestador,
  listarPorSolicitante,
  listar,
  atualizarStatusServico,
  atualizarStatusPagamento,
  atualizar
};

const express = require('express');
const router = express.Router();
const verificacaoController = require('../controllers/verificacaoController');
const { authenticateToken } = require('../middlewares/auth');

// Todas as rotas requerem autenticação
router.use(authenticateToken);

// Rotas específicas ANTES das rotas parametrizadas
router.get('/usuarios/verificados', verificacaoController.listarUsuariosVerificados);
router.get('/usuarios/pendentes', verificacaoController.listarUsuariosPendentes);

// Rotas de comparação facial
router.post('/comparar-fotos', verificacaoController.compararFotos);

// Rotas paramétricas (mais específicas primeiro)
router.get('/usuario/:id/status', verificacaoController.verificarStatus);
router.get('/usuario/:id/biometria', verificacaoController.verificarBiometria);
router.post('/usuario/:id/biometria', verificacaoController.cadastrarBiometria);
router.post('/usuario/:id/biometria/autenticar', verificacaoController.autenticarBiometria);
router.delete('/usuario/:id/biometria', verificacaoController.removerBiometria);

module.exports = router;

const express = require('express');
const router = express.Router();
const documentoController = require('../controllers/documentoController');
const { authenticateToken } = require('../middlewares/auth');

// Todas as rotas requerem autenticação
router.use(authenticateToken);

// Rotas específicas ANTES das rotas parametrizadas
router.get('/pendentes', documentoController.listarPendentes);
router.get('/aprovados', documentoController.listarAprovados);
router.get('/rejeitados', documentoController.listarRejeitados);
router.get('/estatisticas', documentoController.obterEstatisticas);

// Rotas parametrizadas
router.post('/', documentoController.criar);
router.get('/usuario/:usuario_id', documentoController.listarPorUsuario);
router.get('/:id', documentoController.obterPorId);
router.put('/:id/status', documentoController.atualizarStatus);

module.exports = router;

const express = require('express');
const router = express.Router();
const pontoController = require('../controllers/pontoController');
const { authenticateToken } = require('../middlewares/auth');

// Todas as rotas requerem autenticação
router.use(authenticateToken);

// Rotas específicas ANTES das rotas parametrizadas
router.post('/registrar', pontoController.registrar);

// Rotas parametrizadas (mais específicas primeiro)
router.get('/contratacao/:contratacao_id/ultimo', pontoController.obterUltimo);
router.get('/contratacao/:contratacao_id', pontoController.listarPorContratacao);
router.get('/prestador/:id_prestador/relatorio', pontoController.relatorioHoras);
router.get('/prestador/:id_prestador', pontoController.listarPorPrestador);
router.delete('/:id', pontoController.deletar);

module.exports = router;

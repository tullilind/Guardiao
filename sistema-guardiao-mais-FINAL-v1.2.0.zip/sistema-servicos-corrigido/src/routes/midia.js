const express = require('express');
const router = express.Router();
const midiaController = require('../controllers/midiaController');
const { authenticateToken } = require('../middlewares/auth');

// Rotas protegidas
router.post('/upload-multiplo', authenticateToken, midiaController.uploadMultiplo);
router.get('/galeria', authenticateToken, midiaController.obterGaleria);
router.delete('/arquivo/:arquivoId', authenticateToken, midiaController.deletarArquivo);
router.post('/assinar-documento', authenticateToken, midiaController.assinarDocumento);
router.post('/verificar-assinatura', midiaController.verificarAssinatura);

module.exports = router;

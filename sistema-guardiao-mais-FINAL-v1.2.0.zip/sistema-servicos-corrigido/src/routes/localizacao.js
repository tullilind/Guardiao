const express = require('express');
const router = express.Router();
const localizacaoController = require('../controllers/localizacaoController');
const { authenticateToken } = require('../middlewares/auth');

// Rotas protegidas
router.post('/atualizar', authenticateToken, localizacaoController.atualizarLocalizacao);
router.get('/historico', authenticateToken, localizacaoController.obterHistoricoLocalizacao);
router.post('/geocoding-reverso', localizacaoController.geocodingReverso);
router.post('/geocoding-direto', localizacaoController.geocodingDireto);
router.post('/compartilhar', authenticateToken, localizacaoController.compartilharLocalizacao);
router.delete('/compartilhamento/:compartilhamento_id', authenticateToken, localizacaoController.pararCompartilhamento);

module.exports = router;

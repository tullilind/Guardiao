const express = require('express');
const router = express.Router();
const multer = require('multer');
const arquivoController = require('../controllers/arquivoController');
const { authenticateToken } = require('../middlewares/auth');

// Configurar multer para upload em memória
const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: 10 * 1024 * 1024 // 10MB
  }
});

// Todas as rotas requerem autenticação
router.use(authenticateToken);

// Rotas específicas ANTES das rotas parametrizadas
router.post('/upload', upload.single('arquivo'), arquivoController.upload);
router.get('/estatisticas', arquivoController.obterEstatisticas);

// Rotas parametrizadas
router.get('/', arquivoController.listar);
router.get('/:id/info', arquivoController.obterInfo);
router.get('/:id/download', arquivoController.download);
router.get('/:id/visualizar', arquivoController.visualizar);
router.delete('/:id', arquivoController.deletar);

module.exports = router;

# 📖 Instruções de Uso - Sistema de Gerenciamento de Serviços

## 🚀 Como Iniciar o Sistema

### 1. Descompactar o arquivo ZIP

Extraia todos os arquivos do ZIP para uma pasta de sua escolha.

### 2. Abrir terminal na pasta do projeto

Navegue até a pasta onde você extraiu os arquivos.

### 3. Iniciar o servidor

Execute o comando:

```bash
npm start
```

Você verá uma mensagem como esta:

```
═══════════════════════════════════════════════════════
  Sistema de Gerenciamento de Serviços - API
═══════════════════════════════════════════════════════
✓ Servidor rodando na porta 3005
✓ Ambiente: development
✓ API disponível em: http://localhost:3005
✓ Interface de Backup: http://localhost:3005/backup-interface
═══════════════════════════════════════════════════════
```

## 🔧 Configuração Inicial

### Criar Primeiro Administrador de Backup

1. Acesse: **http://localhost:3005/backup-interface**
2. Digite um nome de usuário e senha
3. Clique em "Entrar"
4. O sistema criará automaticamente sua conta de administrador

## 📱 Testando as APIs

### Exemplo 1: Cadastrar Usuário

**Requisição:**
```http
POST http://localhost:3005/api/auth/register
Content-Type: application/json

{
  "nome_completo": "João Silva",
  "email": "joao@email.com",
  "celular": "11999999999",
  "senha": "senha123",
  "cpf_cnpj": "12345678901"
}
```

**Resposta:**
```json
{
  "success": true,
  "message": "Usuário cadastrado com sucesso",
  "data": {
    "usuario": {
      "id": 1,
      "nome_completo": "João Silva",
      "email": "joao@email.com",
      "cpf_cnpj": "12345678901"
    },
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
  }
}
```

### Exemplo 2: Fazer Login

**Requisição:**
```http
POST http://localhost:3005/api/auth/login
Content-Type: application/json

{
  "cpf_cnpj": "12345678901",
  "senha": "senha123"
}
```

**Resposta:**
```json
{
  "success": true,
  "message": "Login realizado com sucesso",
  "data": {
    "usuario": {
      "id": 1,
      "nome_completo": "João Silva",
      "email": "joao@email.com",
      "cpf_cnpj": "12345678901",
      "perfil_verificado": false,
      "media_avaliacao": 0.00
    },
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
  }
}
```

### Exemplo 3: Listar Prestadores Verificados

**Requisição:**
```http
GET http://localhost:3005/api/prestadores/verificados
Authorization: Bearer SEU_TOKEN_AQUI
```

**Resposta:**
```json
{
  "success": true,
  "message": "Operação realizada com sucesso",
  "data": {
    "total": 5,
    "prestadores": [
      {
        "id": 2,
        "nome_completo": "Maria Santos",
        "email": "maria@email.com",
        "media_avaliacao": 4.85,
        "total_servicos_realizados": 23
      }
    ]
  }
}
```

### Exemplo 4: Criar Contratação

**Requisição:**
```http
POST http://localhost:3005/api/contratacoes
Authorization: Bearer SEU_TOKEN_AQUI
Content-Type: application/json

{
  "id_prestador": 2,
  "id_solicitante": 1,
  "servico_nome": "Instalação Elétrica",
  "servico_descricao": "Instalação de tomadas e interruptores",
  "valor_acordado": 250.00
}
```

### Exemplo 5: Registrar Ponto

**Requisição:**
```http
POST http://localhost:3005/api/ponto/registrar
Authorization: Bearer SEU_TOKEN_AQUI
Content-Type: application/json

{
  "contratacao_id": 1,
  "tipo_registro": "ENTRADA",
  "latitude": "-23.550520",
  "longitude": "-46.633308"
}
```

### Exemplo 6: Criar Avaliação

**Requisição:**
```http
POST http://localhost:3005/api/avaliacoes
Authorization: Bearer SEU_TOKEN_AQUI
Content-Type: application/json

{
  "contratacao_id": 1,
  "id_avaliador": 1,
  "id_avaliado": 2,
  "nota_estrelas": 5,
  "comentario": "Excelente profissional!"
}
```

## 🔐 Recuperação de Senha

### Passo 1: Solicitar Token de Recuperação

**Requisição:**
```http
POST http://localhost:3005/api/auth/recuperar-senha
Content-Type: application/json

{
  "nome_completo": "João Silva"
}
```

**Resposta:**
```json
{
  "success": true,
  "message": "Token de recuperação gerado com sucesso",
  "data": {
    "token_recuperacao": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "usuario": {
      "id": 1,
      "nome_completo": "João Silva",
      "email": "jo***@email.com"
    }
  }
}
```

### Passo 2: Redefinir Senha

**Requisição:**
```http
POST http://localhost:3005/api/auth/redefinir-senha
Content-Type: application/json

{
  "token_recuperacao": "TOKEN_RECEBIDO_ACIMA",
  "nova_senha": "novaSenha123"
}
```

## 📤 Upload de Arquivos

### Enviar Arquivo

**Requisição (usando FormData):**
```http
POST http://localhost:3005/api/arquivos/upload
Authorization: Bearer SEU_TOKEN_AQUI
Content-Type: multipart/form-data

arquivo: [SELECIONE O ARQUIVO]
```

**Resposta:**
```json
{
  "success": true,
  "message": "Arquivo enviado com sucesso",
  "data": {
    "id": 1,
    "mime_type": "image/jpeg",
    "tamanho_kb": 245.67
  }
}
```

### Criar Documento de Validação

**Requisição:**
```http
POST http://localhost:3005/api/documentos
Authorization: Bearer SEU_TOKEN_AQUI
Content-Type: application/json

{
  "usuario_id": 1,
  "arquivo_id": 1,
  "tipo_documento": "CNH"
}
```

## 💾 Sistema de Backup

### Via Interface Web

1. Acesse: **http://localhost:3005/backup-interface**
2. Faça login com suas credenciais de administrador
3. Use os botões para:
   - **Criar Novo Backup** - Cria um backup do banco de dados
   - **Restaurar** - Restaura um backup anterior
   - **Baixar** - Faz download do arquivo de backup
   - **Deletar** - Remove um backup

### Via API

**Criar Backup:**
```http
POST http://localhost:3005/api/backup/criar
Authorization: Bearer TOKEN_ADMIN
```

**Listar Backups:**
```http
GET http://localhost:3005/api/backup/listar
Authorization: Bearer TOKEN_ADMIN
```

**Restaurar Backup:**
```http
POST http://localhost:3005/api/backup/restaurar
Authorization: Bearer TOKEN_ADMIN
Content-Type: application/json

{
  "nome_arquivo": "backup_2024-01-15T10-30-00.db"
}
```

## 📊 Consultas Úteis

### Listar Documentos Pendentes

```http
GET http://localhost:3005/api/documentos/pendentes
Authorization: Bearer SEU_TOKEN_AQUI
```

### Listar Usuários Verificados

```http
GET http://localhost:3005/api/verificacao/usuarios/verificados
Authorization: Bearer SEU_TOKEN_AQUI
```

### Verificar Status de Verificação do Usuário

```http
GET http://localhost:3005/api/verificacao/usuario/1/status
Authorization: Bearer SEU_TOKEN_AQUI
```

### Obter Notificações Não Lidas

```http
GET http://localhost:3005/api/notificacoes/nao-lidas
Authorization: Bearer SEU_TOKEN_AQUI
```

### Buscar Prestadores

```http
GET http://localhost:3005/api/prestadores/buscar?termo=João&verificado_apenas=true
Authorization: Bearer SEU_TOKEN_AQUI
```

### Listar Serviços do Prestador

```http
GET http://localhost:3005/api/prestadores/2/servicos
Authorization: Bearer SEU_TOKEN_AQUI
```

### Obter Estatísticas do Prestador

```http
GET http://localhost:3005/api/prestadores/2/estatisticas
Authorization: Bearer SEU_TOKEN_AQUI
```

## 🔍 Filtros e Paginação

A maioria das APIs de listagem suporta filtros e paginação:

**Exemplo:**
```http
GET http://localhost:3005/api/usuarios?page=1&limit=20&verificado=true
Authorization: Bearer SEU_TOKEN_AQUI
```

**Parâmetros comuns:**
- `page` - Número da página (padrão: 1)
- `limit` - Itens por página (padrão: 10 ou 20)
- `status` - Filtrar por status
- `verificado` - Filtrar por perfil verificado (true/false)

## ⚠️ Tratamento de Erros

Todas as APIs retornam respostas padronizadas:

**Sucesso:**
```json
{
  "success": true,
  "message": "Operação realizada com sucesso",
  "data": { ... }
}
```

**Erro:**
```json
{
  "success": false,
  "message": "Descrição do erro",
  "errors": ["Detalhes do erro"],
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

**Códigos HTTP:**
- `200` - Sucesso
- `201` - Criado com sucesso
- `400` - Erro de validação
- `401` - Não autorizado
- `403` - Acesso negado
- `404` - Não encontrado
- `409` - Conflito (ex: CPF já cadastrado)
- `500` - Erro interno do servidor

## 🛑 Parar o Servidor

Para parar o servidor, pressione `Ctrl + C` no terminal.

## 📞 Dúvidas?

Consulte o arquivo `README.md` para mais informações técnicas sobre o sistema.

---

**Sistema pronto para uso! 🎉**

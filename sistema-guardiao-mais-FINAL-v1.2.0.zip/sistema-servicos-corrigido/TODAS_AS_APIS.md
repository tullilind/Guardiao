# 📚 DOCUMENTAÇÃO COMPLETA DE TODAS AS APIs

**Sistema de Gerenciamento de Serviços**  
**Porta:** 3005  
**Base URL:** http://localhost:3005/api

---

## 🔐 AUTENTICAÇÃO

Todas as APIs (exceto login e registro) requerem token JWT no header:

```
Authorization: Bearer SEU_TOKEN_AQUI
```

**Chave Secreta JWT:** 1526105  
**Validade do Token:** 7 dias

---

# 📋 ÍNDICE DE MÓDULOS

1. [Autenticação](#1-autenticação-apiauth) - 6 APIs
2. [Usuários](#2-usuários-apiusuarios) - 5 APIs
3. [Prestadores](#3-prestadores-apiprestadores) - 6 APIs
4. [Verificação](#4-verificação-apiverificacao) - 6 APIs
5. [Documentos](#5-documentos-apidocumentos) - 8 APIs
6. [Arquivos](#6-arquivos-apiarquivos) - 7 APIs
7. [Contratações](#7-contratações-apicontratacoes) - 8 APIs
8. [Ponto Eletrônico](#8-ponto-eletrônico-apiponto) - 6 APIs
9. [Notificações](#9-notificações-apinotificacoes) - 8 APIs
10. [Avaliações](#10-avaliações-apiavaliacoes) - 8 APIs
11. [Logs](#11-logs-apilogs) - 5 APIs
12. [Backup](#12-backup-apibackup) - 8 APIs

**TOTAL: 81 APIs**

---

# 1. AUTENTICAÇÃO (/api/auth)

## 1.1 Registrar Usuário

**Endpoint:** `POST /api/auth/register`  
**Autenticação:** ❌ Não requer  
**Descrição:** Cadastra novo usuário no sistema

### Requisição:
```json
{
  "nome_completo": "João Silva",
  "email": "joao@email.com",
  "celular": "11999999999",
  "senha": "senha123",
  "cpf_cnpj": "12345678901"
}
```

### Validações:
- Todos os campos são obrigatórios
- Email deve ser válido
- Telefone deve ter 10 ou 11 dígitos
- CPF/CNPJ deve ser válido
- Senha mínimo 6 caracteres
- CPF, email e telefone não podem estar cadastrados

### Resposta de Sucesso (201):
```json
{
  "success": true,
  "message": "Usuário cadastrado com sucesso",
  "data": {
    "usuario": {
      "id": 1,
      "nome_completo": "João Silva",
      "email": "joao@email.com",
      "cpf_cnpj": "12345678901"
    },
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
  },
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

### Respostas de Erro:

**400 - Validação:**
```json
{
  "success": false,
  "message": "Erro de validação",
  "errors": ["Email inválido"],
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

**409 - Conflito:**
```json
{
  "success": false,
  "message": "CPF/CNPJ já cadastrado no sistema",
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

---

## 1.2 Login

**Endpoint:** `POST /api/auth/login`  
**Autenticação:** ❌ Não requer  
**Descrição:** Faz login com CPF/CNPJ e senha

### Requisição:
```json
{
  "cpf_cnpj": "12345678901",
  "senha": "senha123"
}
```

### Resposta de Sucesso (200):
```json
{
  "success": true,
  "message": "Login realizado com sucesso",
  "data": {
    "usuario": {
      "id": 1,
      "nome_completo": "João Silva",
      "email": "joao@email.com",
      "cpf_cnpj": "12345678901",
      "perfil_verificado": false,
      "media_avaliacao": 0.00
    },
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
  },
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

### Respostas de Erro:

**401 - Não autorizado:**
```json
{
  "success": false,
  "message": "CPF/CNPJ ou senha incorretos",
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

---

## 1.3 Solicitar Recuperação de Senha

**Endpoint:** `POST /api/auth/recuperar-senha`  
**Autenticação:** ❌ Não requer  
**Descrição:** Gera token temporário para recuperação de senha

### Requisição:
```json
{
  "nome_completo": "João Silva"
}
```

### Resposta de Sucesso (200):
```json
{
  "success": true,
  "message": "Token de recuperação gerado com sucesso. Use-o para redefinir sua senha",
  "data": {
    "token_recuperacao": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "usuario": {
      "id": 1,
      "nome_completo": "João Silva",
      "email": "jo***@email.com"
    }
  },
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

**Nota:** Token válido por 1 hora

---

## 1.4 Redefinir Senha

**Endpoint:** `POST /api/auth/redefinir-senha`  
**Autenticação:** ❌ Não requer  
**Descrição:** Redefine senha usando token temporário

### Requisição:
```json
{
  "token_recuperacao": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "nova_senha": "novaSenha123"
}
```

### Resposta de Sucesso (200):
```json
{
  "success": true,
  "message": "Senha redefinida com sucesso",
  "data": {
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
  },
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

### Respostas de Erro:

**401 - Token inválido:**
```json
{
  "success": false,
  "message": "Token inválido ou expirado",
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

---

## 1.5 Logout

**Endpoint:** `POST /api/auth/logout`  
**Autenticação:** ✅ Requer token  
**Descrição:** Invalida o token atual

### Headers:
```
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

### Resposta de Sucesso (200):
```json
{
  "success": true,
  "message": "Logout realizado com sucesso",
  "data": null,
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

---

## 1.6 Obter Dados do Usuário Logado

**Endpoint:** `GET /api/auth/me`  
**Autenticação:** ✅ Requer token  
**Descrição:** Retorna dados do usuário autenticado

### Headers:
```
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

### Resposta de Sucesso (200):
```json
{
  "success": true,
  "message": "Dados do usuário obtidos com sucesso",
  "data": {
    "id": 1,
    "nome_completo": "João Silva",
    "email": "joao@email.com",
    "celular": "11999999999",
    "cpf_cnpj": "12345678901",
    "perfil_verificado": false,
    "media_avaliacao": 0.00,
    "foto_perfil_id": null,
    "data_cadastro": "2024-01-15T10:00:00.000Z"
  },
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

---

# 2. USUÁRIOS (/api/usuarios)

**Todas as rotas requerem autenticação**

## 2.1 Listar Usuários

**Endpoint:** `GET /api/usuarios`  
**Autenticação:** ✅ Requer token  
**Descrição:** Lista todos os usuários com paginação

### Query Parameters:
- `page` (opcional) - Número da página (padrão: 1)
- `limit` (opcional) - Itens por página (padrão: 10)
- `verificado` (opcional) - Filtrar por verificado (true/false)

### Exemplo:
```
GET /api/usuarios?page=1&limit=20&verificado=true
Authorization: Bearer TOKEN
```

### Resposta de Sucesso (200):
```json
{
  "success": true,
  "message": "Operação realizada com sucesso",
  "data": {
    "usuarios": [
      {
        "id": 1,
        "nome_completo": "João Silva",
        "email": "joao@email.com",
        "celular": "11999999999",
        "cpf_cnpj": "12345678901",
        "perfil_verificado": true,
        "media_avaliacao": 4.85,
        "data_cadastro": "2024-01-15T10:00:00.000Z"
      }
    ],
    "paginacao": {
      "total": 50,
      "pagina_atual": 1,
      "total_paginas": 3,
      "itens_por_pagina": 20
    }
  },
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

---

## 2.2 Obter Usuário por ID

**Endpoint:** `GET /api/usuarios/:id`  
**Autenticação:** ✅ Requer token  
**Descrição:** Retorna dados de um usuário específico

### Exemplo:
```
GET /api/usuarios/1
Authorization: Bearer TOKEN
```

### Resposta de Sucesso (200):
```json
{
  "success": true,
  "message": "Operação realizada com sucesso",
  "data": {
    "id": 1,
    "nome_completo": "João Silva",
    "email": "joao@email.com",
    "celular": "11999999999",
    "cpf_cnpj": "12345678901",
    "perfil_verificado": true,
    "media_avaliacao": 4.85,
    "foto_perfil_id": null,
    "data_cadastro": "2024-01-15T10:00:00.000Z"
  },
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

### Respostas de Erro:

**404 - Não encontrado:**
```json
{
  "success": false,
  "message": "Usuário não encontrado",
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

---

## 2.3 Atualizar Usuário

**Endpoint:** `PUT /api/usuarios/:id`  
**Autenticação:** ✅ Requer token  
**Descrição:** Atualiza dados do usuário (só pode atualizar próprio perfil)

### Requisição:
```json
{
  "nome_completo": "João Silva Santos",
  "email": "joao.novo@email.com",
  "celular": "11988888888"
}
```

### Resposta de Sucesso (200):
```json
{
  "success": true,
  "message": "Usuário atualizado com sucesso",
  "data": {
    "id": 1,
    "nome_completo": "João Silva Santos",
    "email": "joao.novo@email.com",
    "celular": "11988888888",
    "cpf_cnpj": "12345678901",
    "perfil_verificado": true,
    "media_avaliacao": 4.85,
    "foto_perfil_id": null,
    "data_cadastro": "2024-01-15T10:00:00.000Z"
  },
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

### Respostas de Erro:

**403 - Acesso negado:**
```json
{
  "success": false,
  "message": "Você só pode atualizar seu próprio perfil",
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

**409 - Conflito:**
```json
{
  "success": false,
  "message": "Email já cadastrado",
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

---

## 2.4 Alterar Senha

**Endpoint:** `PUT /api/usuarios/:id/senha`  
**Autenticação:** ✅ Requer token  
**Descrição:** Altera senha do usuário

### Requisição:
```json
{
  "senha_atual": "senha123",
  "nova_senha": "novaSenha456"
}
```

### Resposta de Sucesso (200):
```json
{
  "success": true,
  "message": "Senha alterada com sucesso",
  "data": null,
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

### Respostas de Erro:

**401 - Senha incorreta:**
```json
{
  "success": false,
  "message": "Senha atual incorreta",
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

---

## 2.5 Deletar Usuário

**Endpoint:** `DELETE /api/usuarios/:id`  
**Autenticação:** ✅ Requer token  
**Descrição:** Deleta usuário (só pode deletar próprio perfil)

### Exemplo:
```
DELETE /api/usuarios/1
Authorization: Bearer TOKEN
```

### Resposta de Sucesso (200):
```json
{
  "success": true,
  "message": "Usuário deletado com sucesso",
  "data": null,
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

---

# 3. PRESTADORES (/api/prestadores)

**Todas as rotas requerem autenticação**

## 3.1 Listar Prestadores

**Endpoint:** `GET /api/prestadores`  
**Autenticação:** ✅ Requer token  
**Descrição:** Lista prestadores com filtros avançados

### Query Parameters:
- `page` (opcional) - Página (padrão: 1)
- `limit` (opcional) - Itens por página (padrão: 20)
- `verificado` (opcional) - Filtrar verificados (true/false)
- `avaliacao_minima` (opcional) - Avaliação mínima (0-5)
- `ordenar_por` (opcional) - Ordenação (media_avaliacao, data_cadastro, nome_completo)

### Exemplo:
```
GET /api/prestadores?verificado=true&avaliacao_minima=4.0&ordenar_por=media_avaliacao
Authorization: Bearer TOKEN
```

### Resposta de Sucesso (200):
```json
{
  "success": true,
  "message": "Operação realizada com sucesso",
  "data": {
    "prestadores": [
      {
        "id": 2,
        "nome_completo": "Maria Santos",
        "email": "maria@email.com",
        "celular": "11988887777",
        "cpf_cnpj": "98765432100",
        "perfil_verificado": true,
        "media_avaliacao": 4.85,
        "foto_perfil_id": null,
        "data_cadastro": "2024-01-10T08:00:00.000Z",
        "total_servicos_realizados": 23,
        "total_avaliacoes": 20
      }
    ],
    "paginacao": {
      "total": 15,
      "pagina_atual": 1,
      "total_paginas": 1,
      "itens_por_pagina": 20
    }
  },
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

---

## 3.2 Listar Prestadores Verificados

**Endpoint:** `GET /api/prestadores/verificados`  
**Autenticação:** ✅ Requer token  
**Descrição:** Lista apenas prestadores com perfil verificado

### Query Parameters:
- `avaliacao_minima` (opcional) - Avaliação mínima (padrão: 0)
- `limit` (opcional) - Limite de resultados (padrão: 20)

### Exemplo:
```
GET /api/prestadores/verificados?avaliacao_minima=4.5&limit=10
Authorization: Bearer TOKEN
```

### Resposta de Sucesso (200):
```json
{
  "success": true,
  "message": "Operação realizada com sucesso",
  "data": {
    "total": 8,
    "prestadores": [
      {
        "id": 2,
        "nome_completo": "Maria Santos",
        "email": "maria@email.com",
        "celular": "11988887777",
        "media_avaliacao": 4.85,
        "foto_perfil_id": null,
        "data_cadastro": "2024-01-10T08:00:00.000Z",
        "total_servicos_realizados": 23
      }
    ]
  },
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

---

## 3.3 Buscar Prestadores

**Endpoint:** `GET /api/prestadores/buscar`  
**Autenticação:** ✅ Requer token  
**Descrição:** Busca prestadores por nome, email ou telefone

### Query Parameters:
- `termo` (obrigatório) - Termo de busca
- `verificado_apenas` (opcional) - Apenas verificados (true/false)

### Exemplo:
```
GET /api/prestadores/buscar?termo=Maria&verificado_apenas=true
Authorization: Bearer TOKEN
```

### Resposta de Sucesso (200):
```json
{
  "success": true,
  "message": "Operação realizada com sucesso",
  "data": {
    "total": 3,
    "resultados": [
      {
        "id": 2,
        "nome_completo": "Maria Santos",
        "email": "maria@email.com",
        "celular": "11988887777",
        "cpf_cnpj": "98765432100",
        "perfil_verificado": true,
        "media_avaliacao": 4.85,
        "foto_perfil_id": null
      }
    ]
  },
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

---

## 3.4 Obter Prestador por ID

**Endpoint:** `GET /api/prestadores/:id`  
**Autenticação:** ✅ Requer token  
**Descrição:** Retorna dados completos do prestador

### Exemplo:
```
GET /api/prestadores/2
Authorization: Bearer TOKEN
```

### Resposta de Sucesso (200):
```json
{
  "success": true,
  "message": "Operação realizada com sucesso",
  "data": {
    "id": 2,
    "nome_completo": "Maria Santos",
    "email": "maria@email.com",
    "celular": "11988887777",
    "cpf_cnpj": "98765432100",
    "perfil_verificado": true,
    "media_avaliacao": 4.85,
    "foto_perfil_id": null,
    "data_cadastro": "2024-01-10T08:00:00.000Z",
    "total_servicos_realizados": 23,
    "total_avaliacoes": 20,
    "ultimas_avaliacoes": [
      {
        "id": 5,
        "nota_estrelas": 5,
        "comentario": "Excelente profissional!",
        "avaliador_nome": "João Silva",
        "servico_nome": "Instalação Elétrica",
        "data_avaliacao": "2024-01-14T15:00:00.000Z"
      }
    ],
    "documentos": [
      {
        "tipo_documento": "CNH",
        "status": "Aprovado",
        "data_envio": "2024-01-10T09:00:00.000Z",
        "data_validacao": "2024-01-11T10:00:00.000Z"
      }
    ]
  },
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

---

## 3.5 Listar Serviços do Prestador

**Endpoint:** `GET /api/prestadores/:id/servicos`  
**Autenticação:** ✅ Requer token  
**Descrição:** Lista serviços realizados pelo prestador

### Query Parameters:
- `status_servico` (opcional) - Filtrar por status
- `page` (opcional) - Página (padrão: 1)
- `limit` (opcional) - Itens por página (padrão: 10)

### Exemplo:
```
GET /api/prestadores/2/servicos?status_servico=Concluído&page=1&limit=10
Authorization: Bearer TOKEN
```

### Resposta de Sucesso (200):
```json
{
  "success": true,
  "message": "Operação realizada com sucesso",
  "data": {
    "servicos": [
      {
        "id": 5,
        "id_prestador": 2,
        "id_solicitante": 1,
        "servico_nome": "Instalação Elétrica",
        "servico_descricao": "Instalação de tomadas",
        "valor_acordado": 250.00,
        "status_pagamento": "Pago",
        "status_servico": "Concluído",
        "data_contrato": "2024-01-12T10:00:00.000Z",
        "data_conclusao": "2024-01-13T16:00:00.000Z",
        "solicitante_nome": "João Silva"
      }
    ],
    "paginacao": {
      "total": 23,
      "pagina_atual": 1,
      "total_paginas": 3,
      "itens_por_pagina": 10
    }
  },
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

---

## 3.6 Obter Estatísticas do Prestador

**Endpoint:** `GET /api/prestadores/:id/estatisticas`  
**Autenticação:** ✅ Requer token  
**Descrição:** Retorna estatísticas completas do prestador

### Exemplo:
```
GET /api/prestadores/2/estatisticas
Authorization: Bearer TOKEN
```

### Resposta de Sucesso (200):
```json
{
  "success": true,
  "message": "Operação realizada com sucesso",
  "data": {
    "servicos_concluidos": 23,
    "servicos_andamento": 2,
    "servicos_agendados": 1,
    "total_avaliacoes": 20,
    "media_avaliacoes": "4.85",
    "valor_total_servicos": "5750.00"
  },
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

---

# 4. VERIFICAÇÃO (/api/verificacao)

**Todas as rotas requerem autenticação**

## 4.1 Listar Usuários Verificados

**Endpoint:** `GET /api/verificacao/usuarios/verificados`  
**Autenticação:** ✅ Requer token  
**Descrição:** Lista usuários com perfil verificado

### Query Parameters:
- `page` (opcional) - Página (padrão: 1)
- `limit` (opcional) - Itens por página (padrão: 20)

### Exemplo:
```
GET /api/verificacao/usuarios/verificados?page=1&limit=20
Authorization: Bearer TOKEN
```

### Resposta de Sucesso (200):
```json
{
  "success": true,
  "message": "Operação realizada com sucesso",
  "data": {
    "usuarios": [
      {
        "id": 2,
        "nome_completo": "Maria Santos",
        "email": "maria@email.com",
        "celular": "11988887777",
        "media_avaliacao": 4.85,
        "foto_perfil_id": null,
        "data_cadastro": "2024-01-10T08:00:00.000Z"
      }
    ],
    "paginacao": {
      "total": 15,
      "pagina_atual": 1,
      "total_paginas": 1,
      "itens_por_pagina": 20
    }
  },
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

---

## 4.2 Listar Usuários Pendentes

**Endpoint:** `GET /api/verificacao/usuarios/pendentes`  
**Autenticação:** ✅ Requer token  
**Descrição:** Lista usuários com documentos pendentes de validação

### Exemplo:
```
GET /api/verificacao/usuarios/pendentes
Authorization: Bearer TOKEN
```

### Resposta de Sucesso (200):
```json
{
  "success": true,
  "message": "Operação realizada com sucesso",
  "data": {
    "total": 5,
    "usuarios": [
      {
        "id": 3,
        "nome_completo": "Carlos Souza",
        "email": "carlos@email.com",
        "celular": "11977776666",
        "data_cadastro": "2024-01-14T12:00:00.000Z",
        "total_documentos_pendentes": 2
      }
    ]
  },
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

---

## 4.3 Verificar Status do Usuário

**Endpoint:** `GET /api/verificacao/usuario/:id/status`  
**Autenticação:** ✅ Requer token  
**Descrição:** Retorna status completo de verificação do usuário

### Exemplo:
```
GET /api/verificacao/usuario/1/status
Authorization: Bearer TOKEN
```

### Resposta de Sucesso (200):
```json
{
  "success": true,
  "message": "Operação realizada com sucesso",
  "data": {
    "usuario": {
      "id": 1,
      "nome_completo": "João Silva",
      "email": "joao@email.com",
      "perfil_verificado": false
    },
    "documentos": {
      "total": 2,
      "pendentes": 1,
      "aprovados": 1,
      "rejeitados": 0,
      "lista": [
        {
          "id": 1,
          "tipo_documento": "CNH",
          "status": "Aprovado",
          "data_envio": "2024-01-14T10:00:00.000Z",
          "data_validacao": "2024-01-15T09:00:00.000Z",
          "motivo_rejeicao": null
        },
        {
          "id": 2,
          "tipo_documento": "RG",
          "status": "Pendente",
          "data_envio": "2024-01-14T10:05:00.000Z",
          "data_validacao": null,
          "motivo_rejeicao": null
        }
      ]
    },
    "biometria": {
      "cadastrada": false,
      "data_cadastro": null
    },
    "pode_usar_sistema": false
  },
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

---

## 4.4 Verificar Biometria

**Endpoint:** `GET /api/verificacao/usuario/:id/biometria`  
**Autenticação:** ✅ Requer token  
**Descrição:** Verifica se usuário tem biometria cadastrada

### Exemplo:
```
GET /api/verificacao/usuario/1/biometria
Authorization: Bearer TOKEN
```

### Resposta de Sucesso (200):
```json
{
  "success": true,
  "message": "Operação realizada com sucesso",
  "data": {
    "tem_biometria": true,
    "data_cadastro": "2024-01-14T11:00:00.000Z"
  },
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

---

## 4.5 Cadastrar Biometria

**Endpoint:** `POST /api/verificacao/usuario/:id/biometria`  
**Autenticação:** ✅ Requer token  
**Descrição:** Cadastra ou atualiza biometria do usuário

### Requisição:
```json
{
  "dados_biometria": "BASE64_ENCODED_BIOMETRIC_DATA"
}
```

### Resposta de Sucesso (201):
```json
{
  "success": true,
  "message": "Biometria cadastrada com sucesso",
  "data": {
    "id": 1
  },
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

### Respostas de Erro:

**403 - Acesso negado:**
```json
{
  "success": false,
  "message": "Você só pode cadastrar sua própria biometria",
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

---

## 4.6 Remover Biometria

**Endpoint:** `DELETE /api/verificacao/usuario/:id/biometria`  
**Autenticação:** ✅ Requer token  
**Descrição:** Remove biometria do usuário

### Exemplo:
```
DELETE /api/verificacao/usuario/1/biometria
Authorization: Bearer TOKEN
```

### Resposta de Sucesso (200):
```json
{
  "success": true,
  "message": "Biometria removida com sucesso",
  "data": null,
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

---

# 5. DOCUMENTOS (/api/documentos)

**Todas as rotas requerem autenticação**

## 5.1 Criar Documento

**Endpoint:** `POST /api/documentos`  
**Autenticação:** ✅ Requer token  
**Descrição:** Cria novo documento para validação

### Requisição:
```json
{
  "usuario_id": 1,
  "arquivo_id": 5,
  "tipo_documento": "CNH"
}
```

**Tipos de documento válidos:** CNH, RG, Antecedentes, Comprovante Residência

### Resposta de Sucesso (201):
```json
{
  "success": true,
  "message": "Documento enviado para validação",
  "data": {
    "id": 1
  },
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

---

## 5.2 Listar Documentos Pendentes

**Endpoint:** `GET /api/documentos/pendentes`  
**Autenticação:** ✅ Requer token  
**Descrição:** Lista todos os documentos pendentes de validação

### Exemplo:
```
GET /api/documentos/pendentes
Authorization: Bearer TOKEN
```

### Resposta de Sucesso (200):
```json
{
  "success": true,
  "message": "Operação realizada com sucesso",
  "data": {
    "total": 8,
    "documentos": [
      {
        "id": 2,
        "usuario_id": 1,
        "arquivo_id": 6,
        "tipo_documento": "RG",
        "status": "Pendente",
        "motivo_rejeicao": null,
        "data_envio": "2024-01-14T10:05:00.000Z",
        "data_validacao": null,
        "nome_completo": "João Silva",
        "email": "joao@email.com",
        "mime_type": "image/jpeg",
        "tamanho_kb": 245.67
      }
    ]
  },
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

---

## 5.3 Listar Documentos Aprovados

**Endpoint:** `GET /api/documentos/aprovados`  
**Autenticação:** ✅ Requer token  
**Descrição:** Lista documentos aprovados

### Query Parameters:
- `usuario_id` (opcional) - Filtrar por usuário

### Exemplo:
```
GET /api/documentos/aprovados?usuario_id=1
Authorization: Bearer TOKEN
```

### Resposta de Sucesso (200):
```json
{
  "success": true,
  "message": "Operação realizada com sucesso",
  "data": {
    "total": 15,
    "documentos": [
      {
        "id": 1,
        "usuario_id": 1,
        "arquivo_id": 5,
        "tipo_documento": "CNH",
        "status": "Aprovado",
        "motivo_rejeicao": null,
        "data_envio": "2024-01-14T10:00:00.000Z",
        "data_validacao": "2024-01-15T09:00:00.000Z",
        "nome_completo": "João Silva",
        "mime_type": "image/jpeg",
        "tamanho_kb": 312.45
      }
    ]
  },
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

---

## 5.4 Listar Documentos Rejeitados

**Endpoint:** `GET /api/documentos/rejeitados`  
**Autenticação:** ✅ Requer token  
**Descrição:** Lista documentos rejeitados

### Query Parameters:
- `usuario_id` (opcional) - Filtrar por usuário

### Exemplo:
```
GET /api/documentos/rejeitados?usuario_id=1
Authorization: Bearer TOKEN
```

### Resposta de Sucesso (200):
```json
{
  "success": true,
  "message": "Operação realizada com sucesso",
  "data": {
    "total": 2,
    "documentos": [
      {
        "id": 3,
        "usuario_id": 1,
        "arquivo_id": 7,
        "tipo_documento": "RG",
        "status": "Rejeitado",
        "motivo_rejeicao": "Documento ilegível",
        "data_envio": "2024-01-13T14:00:00.000Z",
        "data_validacao": "2024-01-14T10:00:00.000Z",
        "nome_completo": "João Silva",
        "mime_type": "image/jpeg",
        "tamanho_kb": 189.23
      }
    ]
  },
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

---

## 5.5 Listar Documentos por Usuário

**Endpoint:** `GET /api/documentos/usuario/:usuario_id`  
**Autenticação:** ✅ Requer token  
**Descrição:** Lista todos os documentos de um usuário

### Query Parameters:
- `status` (opcional) - Filtrar por status (Pendente, Aprovado, Rejeitado)

### Exemplo:
```
GET /api/documentos/usuario/1?status=Pendente
Authorization: Bearer TOKEN
```

### Resposta de Sucesso (200):
```json
{
  "success": true,
  "message": "Operação realizada com sucesso",
  "data": [
    {
      "id": 2,
      "usuario_id": 1,
      "arquivo_id": 6,
      "tipo_documento": "RG",
      "status": "Pendente",
      "motivo_rejeicao": null,
      "data_envio": "2024-01-14T10:05:00.000Z",
      "data_validacao": null,
      "mime_type": "image/jpeg",
      "tamanho_kb": 245.67
    }
  ],
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

---

## 5.6 Obter Documento por ID

**Endpoint:** `GET /api/documentos/:id`  
**Autenticação:** ✅ Requer token  
**Descrição:** Retorna dados de um documento específico

### Exemplo:
```
GET /api/documentos/1
Authorization: Bearer TOKEN
```

### Resposta de Sucesso (200):
```json
{
  "success": true,
  "message": "Operação realizada com sucesso",
  "data": {
    "id": 1,
    "usuario_id": 1,
    "arquivo_id": 5,
    "tipo_documento": "CNH",
    "status": "Aprovado",
    "motivo_rejeicao": null,
    "data_envio": "2024-01-14T10:00:00.000Z",
    "data_validacao": "2024-01-15T09:00:00.000Z",
    "nome_completo": "João Silva",
    "email": "joao@email.com",
    "mime_type": "image/jpeg",
    "tamanho_kb": 312.45
  },
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

---

## 5.7 Atualizar Status do Documento

**Endpoint:** `PUT /api/documentos/:id/status`  
**Autenticação:** ✅ Requer token  
**Descrição:** Atualiza status do documento (aprovar/rejeitar)

### Requisição:
```json
{
  "status": "Aprovado"
}
```

**Ou para rejeitar:**
```json
{
  "status": "Rejeitado",
  "motivo_rejeicao": "Documento ilegível"
}
```

**Status válidos:** Pendente, Aprovado, Rejeitado

### Resposta de Sucesso (200):
```json
{
  "success": true,
  "message": "Status do documento atualizado com sucesso",
  "data": null,
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

**Nota:** Se todos os documentos do usuário forem aprovados, o perfil é marcado como verificado automaticamente.

---

## 5.8 Obter Estatísticas de Documentos

**Endpoint:** `GET /api/documentos/estatisticas`  
**Autenticação:** ✅ Requer token  
**Descrição:** Retorna estatísticas de documentos

### Query Parameters:
- `usuario_id` (opcional) - Filtrar por usuário

### Exemplo:
```
GET /api/documentos/estatisticas?usuario_id=1
Authorization: Bearer TOKEN
```

### Resposta de Sucesso (200):
```json
{
  "success": true,
  "message": "Operação realizada com sucesso",
  "data": {
    "total": 3,
    "pendentes": 1,
    "aprovados": 1,
    "rejeitados": 1
  },
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

---

# 6. ARQUIVOS (/api/arquivos)

**Todas as rotas requerem autenticação**

## 6.1 Upload de Arquivo

**Endpoint:** `POST /api/arquivos/upload`  
**Autenticação:** ✅ Requer token  
**Descrição:** Faz upload de arquivo (armazenado como BLOB no banco)

### Requisição (multipart/form-data):
```
Content-Type: multipart/form-data
Authorization: Bearer TOKEN

arquivo: [ARQUIVO BINÁRIO]
```

**Limite:** 10 MB

### Resposta de Sucesso (201):
```json
{
  "success": true,
  "message": "Arquivo enviado com sucesso",
  "data": {
    "id": 5,
    "mime_type": "image/jpeg",
    "tamanho_kb": 312.45
  },
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

### Respostas de Erro:

**400 - Nenhum arquivo:**
```json
{
  "success": false,
  "message": "Erro de validação",
  "errors": ["Nenhum arquivo foi enviado"],
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

---

## 6.2 Download de Arquivo

**Endpoint:** `GET /api/arquivos/:id/download`  
**Autenticação:** ✅ Requer token  
**Descrição:** Faz download do arquivo

### Exemplo:
```
GET /api/arquivos/5/download
Authorization: Bearer TOKEN
```

### Resposta de Sucesso (200):
Retorna o arquivo binário com headers apropriados

### Respostas de Erro:

**403 - Acesso negado:**
```json
{
  "success": false,
  "message": "Você não tem permissão para acessar este arquivo",
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

---

## 6.3 Visualizar Arquivo

**Endpoint:** `GET /api/arquivos/:id/visualizar`  
**Autenticação:** ✅ Requer token  
**Descrição:** Visualiza arquivo inline (sem download)

### Exemplo:
```
GET /api/arquivos/5/visualizar
Authorization: Bearer TOKEN
```

### Resposta de Sucesso (200):
Retorna o arquivo binário com Content-Disposition: inline

---

## 6.4 Listar Arquivos

**Endpoint:** `GET /api/arquivos`  
**Autenticação:** ✅ Requer token  
**Descrição:** Lista arquivos do usuário logado

### Query Parameters:
- `page` (opcional) - Página (padrão: 1)
- `limit` (opcional) - Itens por página (padrão: 20)

### Exemplo:
```
GET /api/arquivos?page=1&limit=20
Authorization: Bearer TOKEN
```

### Resposta de Sucesso (200):
```json
{
  "success": true,
  "message": "Operação realizada com sucesso",
  "data": {
    "arquivos": [
      {
        "id": 5,
        "mime_type": "image/jpeg",
        "tamanho_kb": 312.45,
        "data_upload": "2024-01-14T10:00:00.000Z"
      }
    ],
    "paginacao": {
      "total": 8,
      "pagina_atual": 1,
      "total_paginas": 1,
      "itens_por_pagina": 20
    }
  },
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

---

## 6.5 Obter Informações do Arquivo

**Endpoint:** `GET /api/arquivos/:id/info`  
**Autenticação:** ✅ Requer token  
**Descrição:** Retorna informações do arquivo (sem o BLOB)

### Exemplo:
```
GET /api/arquivos/5/info
Authorization: Bearer TOKEN
```

### Resposta de Sucesso (200):
```json
{
  "success": true,
  "message": "Operação realizada com sucesso",
  "data": {
    "id": 5,
    "usuario_id": 1,
    "mime_type": "image/jpeg",
    "tamanho_kb": 312.45,
    "data_upload": "2024-01-14T10:00:00.000Z"
  },
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

---

## 6.6 Deletar Arquivo

**Endpoint:** `DELETE /api/arquivos/:id`  
**Autenticação:** ✅ Requer token  
**Descrição:** Deleta arquivo (não pode deletar se estiver em uso)

### Exemplo:
```
DELETE /api/arquivos/5
Authorization: Bearer TOKEN
```

### Resposta de Sucesso (200):
```json
{
  "success": true,
  "message": "Arquivo deletado com sucesso",
  "data": null,
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

### Respostas de Erro:

**409 - Conflito:**
```json
{
  "success": false,
  "message": "Arquivo está sendo usado em um documento e não pode ser deletado",
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

---

## 6.7 Obter Estatísticas de Armazenamento

**Endpoint:** `GET /api/arquivos/estatisticas`  
**Autenticação:** ✅ Requer token  
**Descrição:** Retorna estatísticas de armazenamento do usuário

### Exemplo:
```
GET /api/arquivos/estatisticas
Authorization: Bearer TOKEN
```

### Resposta de Sucesso (200):
```json
{
  "success": true,
  "message": "Operação realizada com sucesso",
  "data": {
    "total_arquivos": 8,
    "espaco_usado_kb": "2456.78",
    "espaco_usado_mb": "2.40",
    "tamanho_medio_kb": "307.10"
  },
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

---

# 7. CONTRATAÇÕES (/api/contratacoes)

**Todas as rotas requerem autenticação**

## 7.1 Criar Contratação

**Endpoint:** `POST /api/contratacoes`  
**Autenticação:** ✅ Requer token  
**Descrição:** Cria nova contratação de serviço

### Requisição:
```json
{
  "id_prestador": 2,
  "id_solicitante": 1,
  "servico_nome": "Instalação Elétrica",
  "servico_descricao": "Instalação de tomadas e interruptores",
  "valor_acordado": 250.00
}
```

### Resposta de Sucesso (201):
```json
{
  "success": true,
  "message": "Contratação criada com sucesso",
  "data": {
    "id": 5
  },
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

**Nota:** Cria notificações automáticas para prestador e solicitante.

---

## 7.2 Listar Todas as Contratações

**Endpoint:** `GET /api/contratacoes`  
**Autenticação:** ✅ Requer token  
**Descrição:** Lista todas as contratações com filtros

### Query Parameters:
- `status_servico` (opcional) - Agendado, Em Andamento, Concluído, Cancelado
- `status_pagamento` (opcional) - Pendente, Pago, Cancelado
- `page` (opcional) - Página (padrão: 1)
- `limit` (opcional) - Itens por página (padrão: 10)

### Exemplo:
```
GET /api/contratacoes?status_servico=Concluído&status_pagamento=Pago&page=1&limit=10
Authorization: Bearer TOKEN
```

### Resposta de Sucesso (200):
```json
{
  "success": true,
  "message": "Operação realizada com sucesso",
  "data": {
    "contratacoes": [
      {
        "id": 5,
        "id_prestador": 2,
        "id_solicitante": 1,
        "servico_nome": "Instalação Elétrica",
        "servico_descricao": "Instalação de tomadas",
        "valor_acordado": 250.00,
        "status_pagamento": "Pago",
        "status_servico": "Concluído",
        "data_contrato": "2024-01-12T10:00:00.000Z",
        "data_conclusao": "2024-01-13T16:00:00.000Z",
        "prestador_nome": "Maria Santos",
        "solicitante_nome": "João Silva"
      }
    ],
    "paginacao": {
      "total": 45,
      "pagina_atual": 1,
      "total_paginas": 5,
      "itens_por_pagina": 10
    }
  },
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

---

## 7.3 Listar Contratações do Prestador

**Endpoint:** `GET /api/contratacoes/prestador/:id_prestador`  
**Autenticação:** ✅ Requer token  
**Descrição:** Lista contratações onde o usuário é prestador

### Query Parameters:
- `status_servico` (opcional)
- `status_pagamento` (opcional)

### Exemplo:
```
GET /api/contratacoes/prestador/2?status_servico=Em Andamento
Authorization: Bearer TOKEN
```

### Resposta de Sucesso (200):
```json
{
  "success": true,
  "message": "Operação realizada com sucesso",
  "data": {
    "total": 3,
    "contratacoes": [
      {
        "id": 6,
        "id_prestador": 2,
        "id_solicitante": 3,
        "servico_nome": "Manutenção Hidráulica",
        "servico_descricao": "Troca de torneira",
        "valor_acordado": 150.00,
        "status_pagamento": "Pendente",
        "status_servico": "Em Andamento",
        "data_contrato": "2024-01-15T08:00:00.000Z",
        "data_conclusao": null,
        "solicitante_nome": "Carlos Souza"
      }
    ]
  },
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

---

## 7.4 Listar Contratações do Solicitante

**Endpoint:** `GET /api/contratacoes/solicitante/:id_solicitante`  
**Autenticação:** ✅ Requer token  
**Descrição:** Lista contratações onde o usuário é solicitante

### Query Parameters:
- `status_servico` (opcional)
- `status_pagamento` (opcional)

### Exemplo:
```
GET /api/contratacoes/solicitante/1?status_servico=Agendado
Authorization: Bearer TOKEN
```

### Resposta de Sucesso (200):
```json
{
  "success": true,
  "message": "Operação realizada com sucesso",
  "data": {
    "total": 2,
    "contratacoes": [
      {
        "id": 7,
        "id_prestador": 2,
        "id_solicitante": 1,
        "servico_nome": "Pintura",
        "servico_descricao": "Pintura de sala",
        "valor_acordado": 500.00,
        "status_pagamento": "Pendente",
        "status_servico": "Agendado",
        "data_contrato": "2024-01-15T09:00:00.000Z",
        "data_conclusao": null,
        "prestador_nome": "Maria Santos",
        "media_avaliacao": 4.85
      }
    ]
  },
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

---

## 7.5 Obter Contratação por ID

**Endpoint:** `GET /api/contratacoes/:id`  
**Autenticação:** ✅ Requer token  
**Descrição:** Retorna dados completos da contratação

### Exemplo:
```
GET /api/contratacoes/5
Authorization: Bearer TOKEN
```

### Resposta de Sucesso (200):
```json
{
  "success": true,
  "message": "Operação realizada com sucesso",
  "data": {
    "id": 5,
    "id_prestador": 2,
    "id_solicitante": 1,
    "servico_nome": "Instalação Elétrica",
    "servico_descricao": "Instalação de tomadas",
    "valor_acordado": 250.00,
    "status_pagamento": "Pago",
    "status_servico": "Concluído",
    "data_contrato": "2024-01-12T10:00:00.000Z",
    "data_conclusao": "2024-01-13T16:00:00.000Z",
    "prestador_nome": "Maria Santos",
    "prestador_email": "maria@email.com",
    "solicitante_nome": "João Silva",
    "solicitante_email": "joao@email.com"
  },
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

---

## 7.6 Atualizar Contratação

**Endpoint:** `PUT /api/contratacoes/:id`  
**Autenticação:** ✅ Requer token  
**Descrição:** Atualiza dados da contratação

### Requisição:
```json
{
  "servico_nome": "Instalação Elétrica Completa",
  "servico_descricao": "Instalação de tomadas, interruptores e luminárias",
  "valor_acordado": 350.00
}
```

### Resposta de Sucesso (200):
```json
{
  "success": true,
  "message": "Contratação atualizada com sucesso",
  "data": null,
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

---

## 7.7 Atualizar Status do Serviço

**Endpoint:** `PUT /api/contratacoes/:id/status-servico`  
**Autenticação:** ✅ Requer token  
**Descrição:** Atualiza status do serviço

### Requisição:
```json
{
  "status_servico": "Em Andamento"
}
```

**Status válidos:** Agendado, Em Andamento, Concluído, Cancelado

### Resposta de Sucesso (200):
```json
{
  "success": true,
  "message": "Status do serviço atualizado com sucesso",
  "data": null,
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

**Nota:** Cria notificações automáticas para ambas as partes.

---

## 7.8 Atualizar Status do Pagamento

**Endpoint:** `PUT /api/contratacoes/:id/status-pagamento`  
**Autenticação:** ✅ Requer token  
**Descrição:** Atualiza status do pagamento

### Requisição:
```json
{
  "status_pagamento": "Pago"
}
```

**Status válidos:** Pendente, Pago, Cancelado

### Resposta de Sucesso (200):
```json
{
  "success": true,
  "message": "Status do pagamento atualizado com sucesso",
  "data": null,
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

---

# 8. PONTO ELETRÔNICO (/api/ponto)

**Todas as rotas requerem autenticação**

## 8.1 Registrar Ponto

**Endpoint:** `POST /api/ponto/registrar`  
**Autenticação:** ✅ Requer token  
**Descrição:** Registra ponto de entrada ou saída com GPS

### Requisição:
```json
{
  "contratacao_id": 5,
  "tipo_registro": "ENTRADA",
  "latitude": "-23.550520",
  "longitude": "-46.633308"
}
```

**Tipos válidos:** ENTRADA, SAIDA

### Resposta de Sucesso (201):
```json
{
  "success": true,
  "message": "Ponto registrado com sucesso",
  "data": {
    "id": 10,
    "tipo_registro": "ENTRADA",
    "data_hora": "2024-01-15T10:30:00.000Z"
  },
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

**Notas:**
- Apenas o prestador pode registrar ponto
- ENTRADA atualiza status do serviço para "Em Andamento"
- Cria notificações automáticas

---

## 8.2 Listar Registros por Contratação

**Endpoint:** `GET /api/ponto/contratacao/:contratacao_id`  
**Autenticação:** ✅ Requer token  
**Descrição:** Lista registros de ponto da contratação

### Exemplo:
```
GET /api/ponto/contratacao/5
Authorization: Bearer TOKEN
```

### Resposta de Sucesso (200):
```json
{
  "success": true,
  "message": "Operação realizada com sucesso",
  "data": {
    "contratacao_id": 5,
    "total_registros": 4,
    "tempo_total_minutos": 480,
    "tempo_total_horas": "8.00",
    "registros": [
      {
        "id": 10,
        "contratacao_id": 5,
        "tipo_registro": "ENTRADA",
        "latitude": "-23.550520",
        "longitude": "-46.633308",
        "data_hora": "2024-01-13T08:00:00.000Z"
      },
      {
        "id": 11,
        "contratacao_id": 5,
        "tipo_registro": "SAIDA",
        "latitude": "-23.550520",
        "longitude": "-46.633308",
        "data_hora": "2024-01-13T12:00:00.000Z"
      }
    ]
  },
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

---

## 8.3 Obter Último Registro

**Endpoint:** `GET /api/ponto/contratacao/:contratacao_id/ultimo`  
**Autenticação:** ✅ Requer token  
**Descrição:** Retorna último registro de ponto da contratação

### Exemplo:
```
GET /api/ponto/contratacao/5/ultimo
Authorization: Bearer TOKEN
```

### Resposta de Sucesso (200):
```json
{
  "success": true,
  "message": "Operação realizada com sucesso",
  "data": {
    "id": 14,
    "contratacao_id": 5,
    "tipo_registro": "SAIDA",
    "latitude": "-23.550520",
    "longitude": "-46.633308",
    "data_hora": "2024-01-13T16:00:00.000Z"
  },
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

---

## 8.4 Listar Registros por Prestador

**Endpoint:** `GET /api/ponto/prestador/:id_prestador`  
**Autenticação:** ✅ Requer token  
**Descrição:** Lista todos os registros do prestador

### Query Parameters:
- `data_inicio` (opcional) - Data inicial (YYYY-MM-DD)
- `data_fim` (opcional) - Data final (YYYY-MM-DD)

### Exemplo:
```
GET /api/ponto/prestador/2?data_inicio=2024-01-01&data_fim=2024-01-15
Authorization: Bearer TOKEN
```

### Resposta de Sucesso (200):
```json
{
  "success": true,
  "message": "Operação realizada com sucesso",
  "data": {
    "total": 28,
    "registros": [
      {
        "id": 14,
        "contratacao_id": 5,
        "tipo_registro": "SAIDA",
        "latitude": "-23.550520",
        "longitude": "-46.633308",
        "data_hora": "2024-01-13T16:00:00.000Z",
        "servico_nome": "Instalação Elétrica",
        "id_solicitante": 1
      }
    ]
  },
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

---

## 8.5 Relatório de Horas

**Endpoint:** `GET /api/ponto/prestador/:id_prestador/relatorio`  
**Autenticação:** ✅ Requer token  
**Descrição:** Gera relatório de horas trabalhadas

### Query Parameters:
- `mes` (opcional) - Mês (1-12)
- `ano` (opcional) - Ano (YYYY)

### Exemplo:
```
GET /api/ponto/prestador/2/relatorio?mes=1&ano=2024
Authorization: Bearer TOKEN
```

### Resposta de Sucesso (200):
```json
{
  "success": true,
  "message": "Operação realizada com sucesso",
  "data": {
    "periodo": "1/2024",
    "total_dias": 12,
    "dados": [
      {
        "data": "2024-01-13",
        "servico_nome": "Instalação Elétrica",
        "contratacao_id": 5,
        "registros": "ENTRADA:2024-01-13 08:00:00,SAIDA:2024-01-13 16:00:00"
      }
    ]
  },
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

---

## 8.6 Deletar Registro

**Endpoint:** `DELETE /api/ponto/:id`  
**Autenticação:** ✅ Requer token  
**Descrição:** Deleta registro de ponto

### Exemplo:
```
DELETE /api/ponto/10
Authorization: Bearer TOKEN
```

### Resposta de Sucesso (200):
```json
{
  "success": true,
  "message": "Registro deletado com sucesso",
  "data": null,
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

---

# 9. NOTIFICAÇÕES (/api/notificacoes)

**Todas as rotas requerem autenticação**

## 9.1 Criar Notificação

**Endpoint:** `POST /api/notificacoes`  
**Autenticação:** ✅ Requer token  
**Descrição:** Cria nova notificação

### Requisição:
```json
{
  "usuario_id": 1,
  "mensagem": "Você tem um novo serviço agendado",
  "link_acao": "/contratacoes/5"
}
```

### Resposta de Sucesso (201):
```json
{
  "success": true,
  "message": "Notificação criada com sucesso",
  "data": {
    "id": 15
  },
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

---

## 9.2 Listar Notificações do Usuário

**Endpoint:** `GET /api/notificacoes/usuario/:usuario_id`  
**Autenticação:** ✅ Requer token  
**Descrição:** Lista notificações do usuário

### Query Parameters:
- `lida` (opcional) - Filtrar por lida (true/false)
- `limit` (opcional) - Limite de resultados (padrão: 50)

### Exemplo:
```
GET /api/notificacoes/usuario/1?lida=false&limit=20
Authorization: Bearer TOKEN
```

### Resposta de Sucesso (200):
```json
{
  "success": true,
  "message": "Operação realizada com sucesso",
  "data": {
    "total": 8,
    "nao_lidas": 5,
    "notificacoes": [
      {
        "id": 15,
        "usuario_id": 1,
        "mensagem": "Você tem um novo serviço agendado",
        "lida": false,
        "link_acao": "/contratacoes/5",
        "data_criacao": "2024-01-15T10:30:00.000Z"
      }
    ]
  },
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

---

## 9.3 Listar Notificações Não Lidas

**Endpoint:** `GET /api/notificacoes/nao-lidas`  
**Autenticação:** ✅ Requer token  
**Descrição:** Lista apenas notificações não lidas do usuário logado

### Exemplo:
```
GET /api/notificacoes/nao-lidas
Authorization: Bearer TOKEN
```

### Resposta de Sucesso (200):
```json
{
  "success": true,
  "message": "Operação realizada com sucesso",
  "data": {
    "total": 5,
    "notificacoes": [
      {
        "id": 15,
        "usuario_id": 1,
        "mensagem": "Você tem um novo serviço agendado",
        "lida": false,
        "link_acao": "/contratacoes/5",
        "data_criacao": "2024-01-15T10:30:00.000Z"
      }
    ]
  },
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

---

## 9.4 Obter Contagem de Notificações

**Endpoint:** `GET /api/notificacoes/contagem`  
**Autenticação:** ✅ Requer token  
**Descrição:** Retorna contagem de notificações do usuário logado

### Exemplo:
```
GET /api/notificacoes/contagem
Authorization: Bearer TOKEN
```

### Resposta de Sucesso (200):
```json
{
  "success": true,
  "message": "Operação realizada com sucesso",
  "data": {
    "total": 12,
    "nao_lidas": 5,
    "lidas": 7
  },
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

---

## 9.5 Marcar Notificação como Lida

**Endpoint:** `PUT /api/notificacoes/:id/marcar-lida`  
**Autenticação:** ✅ Requer token  
**Descrição:** Marca notificação como lida

### Exemplo:
```
PUT /api/notificacoes/15/marcar-lida
Authorization: Bearer TOKEN
```

### Resposta de Sucesso (200):
```json
{
  "success": true,
  "message": "Notificação marcada como lida",
  "data": null,
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

---

## 9.6 Marcar Todas como Lidas

**Endpoint:** `PUT /api/notificacoes/marcar-todas-lidas`  
**Autenticação:** ✅ Requer token  
**Descrição:** Marca todas as notificações do usuário como lidas

### Exemplo:
```
PUT /api/notificacoes/marcar-todas-lidas
Authorization: Bearer TOKEN
```

### Resposta de Sucesso (200):
```json
{
  "success": true,
  "message": "Todas as notificações foram marcadas como lidas",
  "data": {
    "marcadas": 5
  },
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

---

## 9.7 Deletar Notificação

**Endpoint:** `DELETE /api/notificacoes/:id`  
**Autenticação:** ✅ Requer token  
**Descrição:** Deleta notificação

### Exemplo:
```
DELETE /api/notificacoes/15
Authorization: Bearer TOKEN
```

### Resposta de Sucesso (200):
```json
{
  "success": true,
  "message": "Notificação deletada com sucesso",
  "data": null,
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

---

## 9.8 Deletar Notificações Lidas

**Endpoint:** `DELETE /api/notificacoes/lidas/limpar`  
**Autenticação:** ✅ Requer token  
**Descrição:** Deleta todas as notificações lidas do usuário

### Exemplo:
```
DELETE /api/notificacoes/lidas/limpar
Authorization: Bearer TOKEN
```

### Resposta de Sucesso (200):
```json
{
  "success": true,
  "message": "Notificações lidas deletadas com sucesso",
  "data": {
    "deletadas": 7
  },
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

---

# 10. AVALIAÇÕES (/api/avaliacoes)

**Todas as rotas requerem autenticação**

## 10.1 Criar Avaliação

**Endpoint:** `POST /api/avaliacoes`  
**Autenticação:** ✅ Requer token  
**Descrição:** Cria avaliação (só para serviços concluídos)

### Requisição:
```json
{
  "contratacao_id": 5,
  "id_avaliador": 1,
  "id_avaliado": 2,
  "nota_estrelas": 5,
  "comentario": "Excelente profissional! Trabalho impecável."
}
```

**Nota:** 1 a 5 estrelas

### Resposta de Sucesso (201):
```json
{
  "success": true,
  "message": "Avaliação criada com sucesso",
  "data": {
    "id": 8
  },
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

**Notas:**
- Só pode avaliar serviços concluídos
- Recalcula média automaticamente
- Cria notificação para o avaliado
- Não permite avaliações duplicadas

### Respostas de Erro:

**409 - Conflito:**
```json
{
  "success": false,
  "message": "Só é possível avaliar serviços concluídos",
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

---

## 10.2 Listar Avaliações do Usuário

**Endpoint:** `GET /api/avaliacoes/usuario/:usuario_id`  
**Autenticação:** ✅ Requer token  
**Descrição:** Lista avaliações recebidas pelo usuário

### Query Parameters:
- `page` (opcional) - Página (padrão: 1)
- `limit` (opcional) - Itens por página (padrão: 10)

### Exemplo:
```
GET /api/avaliacoes/usuario/2?page=1&limit=10
Authorization: Bearer TOKEN
```

### Resposta de Sucesso (200):
```json
{
  "success": true,
  "message": "Operação realizada com sucesso",
  "data": {
    "avaliacoes": [
      {
        "id": 8,
        "contratacao_id": 5,
        "id_avaliador": 1,
        "id_avaliado": 2,
        "nota_estrelas": 5,
        "comentario": "Excelente profissional!",
        "data_avaliacao": "2024-01-15T10:30:00.000Z",
        "avaliador_nome": "João Silva",
        "servico_nome": "Instalação Elétrica"
      }
    ],
    "estatisticas": {
      "media": "4.85",
      "total_avaliacoes": 20,
      "distribuicao": {
        "5": 15,
        "4": 4,
        "3": 1,
        "2": 0,
        "1": 0
      }
    },
    "paginacao": {
      "total": 20,
      "pagina_atual": 1,
      "total_paginas": 2,
      "itens_por_pagina": 10
    }
  },
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

---

## 10.3 Listar Avaliações Feitas

**Endpoint:** `GET /api/avaliacoes/usuario/:usuario_id/feitas`  
**Autenticação:** ✅ Requer token  
**Descrição:** Lista avaliações feitas pelo usuário

### Exemplo:
```
GET /api/avaliacoes/usuario/1/feitas
Authorization: Bearer TOKEN
```

### Resposta de Sucesso (200):
```json
{
  "success": true,
  "message": "Operação realizada com sucesso",
  "data": {
    "total": 5,
    "avaliacoes": [
      {
        "id": 8,
        "contratacao_id": 5,
        "id_avaliador": 1,
        "id_avaliado": 2,
        "nota_estrelas": 5,
        "comentario": "Excelente profissional!",
        "data_avaliacao": "2024-01-15T10:30:00.000Z",
        "avaliado_nome": "Maria Santos",
        "servico_nome": "Instalação Elétrica"
      }
    ]
  },
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

---

## 10.4 Listar Avaliações da Contratação

**Endpoint:** `GET /api/avaliacoes/contratacao/:contratacao_id`  
**Autenticação:** ✅ Requer token  
**Descrição:** Lista avaliações de uma contratação específica

### Exemplo:
```
GET /api/avaliacoes/contratacao/5
Authorization: Bearer TOKEN
```

### Resposta de Sucesso (200):
```json
{
  "success": true,
  "message": "Operação realizada com sucesso",
  "data": {
    "total": 2,
    "avaliacoes": [
      {
        "id": 8,
        "contratacao_id": 5,
        "id_avaliador": 1,
        "id_avaliado": 2,
        "nota_estrelas": 5,
        "comentario": "Excelente profissional!",
        "data_avaliacao": "2024-01-15T10:30:00.000Z",
        "avaliador_nome": "João Silva",
        "avaliado_nome": "Maria Santos"
      }
    ]
  },
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

---

## 10.5 Obter Top Prestadores

**Endpoint:** `GET /api/avaliacoes/top-prestadores`  
**Autenticação:** ✅ Requer token  
**Descrição:** Lista top prestadores por avaliação

### Query Parameters:
- `limit` (opcional) - Limite de resultados (padrão: 10)

### Exemplo:
```
GET /api/avaliacoes/top-prestadores?limit=5
Authorization: Bearer TOKEN
```

### Resposta de Sucesso (200):
```json
{
  "success": true,
  "message": "Operação realizada com sucesso",
  "data": [
    {
      "id": 2,
      "nome_completo": "Maria Santos",
      "email": "maria@email.com",
      "media_avaliacao": 4.95,
      "total_avaliacoes": 25
    },
    {
      "id": 4,
      "nome_completo": "Pedro Oliveira",
      "email": "pedro@email.com",
      "media_avaliacao": 4.85,
      "total_avaliacoes": 18
    }
  ],
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

---

## 10.6 Obter Avaliação por ID

**Endpoint:** `GET /api/avaliacoes/:id`  
**Autenticação:** ✅ Requer token  
**Descrição:** Retorna dados de uma avaliação específica

### Exemplo:
```
GET /api/avaliacoes/8
Authorization: Bearer TOKEN
```

### Resposta de Sucesso (200):
```json
{
  "success": true,
  "message": "Operação realizada com sucesso",
  "data": {
    "id": 8,
    "contratacao_id": 5,
    "id_avaliador": 1,
    "id_avaliado": 2,
    "nota_estrelas": 5,
    "comentario": "Excelente profissional!",
    "data_avaliacao": "2024-01-15T10:30:00.000Z",
    "avaliador_nome": "João Silva",
    "avaliado_nome": "Maria Santos",
    "servico_nome": "Instalação Elétrica"
  },
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

---

## 10.7 Atualizar Avaliação

**Endpoint:** `PUT /api/avaliacoes/:id`  
**Autenticação:** ✅ Requer token  
**Descrição:** Atualiza avaliação (só pode editar próprias avaliações)

### Requisição:
```json
{
  "nota_estrelas": 4,
  "comentario": "Bom profissional, mas poderia ser mais pontual."
}
```

### Resposta de Sucesso (200):
```json
{
  "success": true,
  "message": "Avaliação atualizada com sucesso",
  "data": null,
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

**Nota:** Recalcula média automaticamente se nota foi alterada.

---

## 10.8 Deletar Avaliação

**Endpoint:** `DELETE /api/avaliacoes/:id`  
**Autenticação:** ✅ Requer token  
**Descrição:** Deleta avaliação (só pode deletar próprias avaliações)

### Exemplo:
```
DELETE /api/avaliacoes/8
Authorization: Bearer TOKEN
```

### Resposta de Sucesso (200):
```json
{
  "success": true,
  "message": "Avaliação deletada com sucesso",
  "data": null,
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

**Nota:** Recalcula média automaticamente.

---

# 11. LOGS (/api/logs)

**Todas as rotas requerem autenticação**

## 11.1 Listar Logs do Usuário

**Endpoint:** `GET /api/logs/usuario/:usuario_id`  
**Autenticação:** ✅ Requer token  
**Descrição:** Lista logs de acesso do usuário

### Query Parameters:
- `status_login` (opcional) - Filtrar por status
- `page` (opcional) - Página (padrão: 1)
- `limit` (opcional) - Itens por página (padrão: 20)

### Exemplo:
```
GET /api/logs/usuario/1?status_login=Sucesso&page=1&limit=20
Authorization: Bearer TOKEN
```

### Resposta de Sucesso (200):
```json
{
  "success": true,
  "message": "Operação realizada com sucesso",
  "data": {
    "logs": [
      {
        "id": 25,
        "usuario_id": 1,
        "ip_origem": "192.168.1.100",
        "dispositivo": "Mozilla/5.0...",
        "status_login": "Sucesso",
        "data_hora": "2024-01-15T10:30:00.000Z"
      }
    ],
    "paginacao": {
      "total": 45,
      "pagina_atual": 1,
      "total_paginas": 3,
      "itens_por_pagina": 20
    }
  },
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

---

## 11.2 Obter Último Acesso

**Endpoint:** `GET /api/logs/usuario/:usuario_id/ultimo`  
**Autenticação:** ✅ Requer token  
**Descrição:** Retorna último acesso bem-sucedido do usuário

### Exemplo:
```
GET /api/logs/usuario/1/ultimo
Authorization: Bearer TOKEN
```

### Resposta de Sucesso (200):
```json
{
  "success": true,
  "message": "Operação realizada com sucesso",
  "data": {
    "id": 25,
    "usuario_id": 1,
    "ip_origem": "192.168.1.100",
    "dispositivo": "Mozilla/5.0...",
    "status_login": "Sucesso",
    "data_hora": "2024-01-15T10:30:00.000Z"
  },
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

---

## 11.3 Listar Todos os Logs

**Endpoint:** `GET /api/logs/todos`  
**Autenticação:** ✅ Requer token  
**Descrição:** Lista todos os logs do sistema

### Query Parameters:
- `status_login` (opcional) - Filtrar por status
- `data_inicio` (opcional) - Data inicial (YYYY-MM-DD)
- `data_fim` (opcional) - Data final (YYYY-MM-DD)
- `page` (opcional) - Página (padrão: 1)
- `limit` (opcional) - Itens por página (padrão: 50)

### Exemplo:
```
GET /api/logs/todos?status_login=Falha&data_inicio=2024-01-01&data_fim=2024-01-15
Authorization: Bearer TOKEN
```

### Resposta de Sucesso (200):
```json
{
  "success": true,
  "message": "Operação realizada com sucesso",
  "data": {
    "logs": [
      {
        "id": 23,
        "usuario_id": 3,
        "ip_origem": "192.168.1.105",
        "dispositivo": "Mozilla/5.0...",
        "status_login": "Falha - Senha incorreta",
        "data_hora": "2024-01-14T15:20:00.000Z",
        "nome_completo": "Carlos Souza",
        "email": "carlos@email.com"
      }
    ],
    "paginacao": {
      "total": 125,
      "pagina_atual": 1,
      "total_paginas": 3,
      "itens_por_pagina": 50
    }
  },
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

---

## 11.4 Obter Estatísticas de Acesso

**Endpoint:** `GET /api/logs/estatisticas`  
**Autenticação:** ✅ Requer token  
**Descrição:** Retorna estatísticas de acesso

### Query Parameters:
- `usuario_id` (opcional) - Filtrar por usuário

### Exemplo:
```
GET /api/logs/estatisticas?usuario_id=1
Authorization: Bearer TOKEN
```

### Resposta de Sucesso (200):
```json
{
  "success": true,
  "message": "Operação realizada com sucesso",
  "data": {
    "estatisticas": {
      "total_acessos": 45,
      "acessos_sucesso": 42,
      "acessos_falha": 3
    },
    "ultimos_acessos": [
      {
        "id": 25,
        "usuario_id": 1,
        "ip_origem": "192.168.1.100",
        "dispositivo": "Mozilla/5.0...",
        "status_login": "Sucesso",
        "data_hora": "2024-01-15T10:30:00.000Z"
      }
    ]
  },
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

---

## 11.5 Limpar Logs Antigos

**Endpoint:** `POST /api/logs/limpar`  
**Autenticação:** ✅ Requer token  
**Descrição:** Deleta logs com mais de X dias

### Requisição:
```json
{
  "dias": 90
}
```

### Resposta de Sucesso (200):
```json
{
  "success": true,
  "message": "Logs com mais de 90 dias foram deletados",
  "data": {
    "deletados": 234
  },
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

---

# 12. BACKUP (/api/backup)

## 12.1 Login de Administrador

**Endpoint:** `POST /api/backup/admin/login`  
**Autenticação:** ❌ Não requer  
**Descrição:** Faz login de administrador do sistema de backup

### Requisição:
```json
{
  "nome_usuario": "admin",
  "senha": "senha123"
}
```

### Resposta de Sucesso (200):
```json
{
  "success": true,
  "message": "Login de administrador realizado com sucesso",
  "data": {
    "admin": {
      "id": 1,
      "nome_usuario": "admin"
    },
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
  },
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

**Nota:** Token válido por 24 horas

---

## 12.2 Criar Administrador

**Endpoint:** `POST /api/backup/admin/criar`  
**Autenticação:** ❌ Não requer  
**Descrição:** Cria novo administrador de backup

### Requisição:
```json
{
  "nome_usuario": "admin",
  "senha": "senha123"
}
```

### Resposta de Sucesso (201):
```json
{
  "success": true,
  "message": "Administrador criado com sucesso",
  "data": {
    "id": 1,
    "nome_usuario": "admin"
  },
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

---

## 12.3 Criar Backup

**Endpoint:** `POST /api/backup/criar`  
**Autenticação:** ✅ Requer token de admin  
**Descrição:** Cria backup do banco de dados

### Headers:
```
Authorization: Bearer TOKEN_ADMIN
```

### Resposta de Sucesso (200):
```json
{
  "success": true,
  "message": "Backup criado com sucesso",
  "data": {
    "arquivo": "backup_2024-01-15T10-30-00-000Z.db",
    "caminho": "/home/ubuntu/sistema-servicos/database/backups/backup_2024-01-15T10-30-00-000Z.db",
    "tamanho_mb": 2.45,
    "data_criacao": "2024-01-15T10:30:00.000Z"
  },
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

---

## 12.4 Listar Backups

**Endpoint:** `GET /api/backup/listar`  
**Autenticação:** ✅ Requer token de admin  
**Descrição:** Lista todos os backups disponíveis

### Headers:
```
Authorization: Bearer TOKEN_ADMIN
```

### Resposta de Sucesso (200):
```json
{
  "success": true,
  "message": "Operação realizada com sucesso",
  "data": {
    "total": 5,
    "backups": [
      {
        "nome": "backup_2024-01-15T10-30-00-000Z.db",
        "tamanho_mb": "2.45",
        "data_criacao": "2024-01-15T10:30:00.000Z",
        "data_modificacao": "2024-01-15T10:30:00.000Z"
      }
    ]
  },
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

---

## 12.5 Restaurar Backup

**Endpoint:** `POST /api/backup/restaurar`  
**Autenticação:** ✅ Requer token de admin  
**Descrição:** Restaura backup do banco de dados

### Requisição:
```json
{
  "nome_arquivo": "backup_2024-01-15T10-30-00-000Z.db"
}
```

### Resposta de Sucesso (200):
```json
{
  "success": true,
  "message": "Backup restaurado com sucesso",
  "data": {
    "backup_restaurado": "backup_2024-01-15T10-30-00-000Z.db",
    "backup_anterior": "pre_restore_2024-01-15T11-00-00-000Z.db"
  },
  "timestamp": "2024-01-15T11:00:00.000Z"
}
```

**Nota:** Cria backup automático antes de restaurar

---

## 12.6 Download de Backup

**Endpoint:** `GET /api/backup/download/:nome_arquivo`  
**Autenticação:** ✅ Requer token de admin  
**Descrição:** Faz download do arquivo de backup

### Exemplo:
```
GET /api/backup/download/backup_2024-01-15T10-30-00-000Z.db
Authorization: Bearer TOKEN_ADMIN
```

### Resposta de Sucesso (200):
Retorna o arquivo de backup para download

---

## 12.7 Deletar Backup

**Endpoint:** `DELETE /api/backup/:nome_arquivo`  
**Autenticação:** ✅ Requer token de admin  
**Descrição:** Deleta arquivo de backup

### Exemplo:
```
DELETE /api/backup/backup_2024-01-15T10-30-00-000Z.db
Authorization: Bearer TOKEN_ADMIN
```

### Resposta de Sucesso (200):
```json
{
  "success": true,
  "message": "Backup deletado com sucesso",
  "data": null,
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

---

## 12.8 Obter Estatísticas do Sistema

**Endpoint:** `GET /api/backup/estatisticas`  
**Autenticação:** ✅ Requer token de admin  
**Descrição:** Retorna estatísticas gerais do sistema

### Headers:
```
Authorization: Bearer TOKEN_ADMIN
```

### Resposta de Sucesso (200):
```json
{
  "success": true,
  "message": "Operação realizada com sucesso",
  "data": {
    "total_usuarios": 50,
    "total_contratacoes": 125,
    "total_avaliacoes": 98,
    "total_documentos": 145,
    "total_arquivos": 234,
    "espaco_usado_mb": "125.45",
    "tamanho_banco_mb": "2.45"
  },
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

---

# 📝 CÓDIGOS DE STATUS HTTP

| Código | Descrição |
|--------|-----------|
| 200 | OK - Operação bem-sucedida |
| 201 | Created - Recurso criado com sucesso |
| 400 | Bad Request - Erro de validação |
| 401 | Unauthorized - Não autorizado (token inválido) |
| 403 | Forbidden - Acesso negado (sem permissão) |
| 404 | Not Found - Recurso não encontrado |
| 409 | Conflict - Conflito de dados (ex: CPF já existe) |
| 500 | Internal Server Error - Erro interno do servidor |

---

# 🔒 SEGURANÇA

## Chave Secreta JWT
**Valor:** 1526105

## Validade dos Tokens
- **Token normal:** 7 dias
- **Token de recuperação:** 1 hora
- **Token de admin:** 24 horas

## Proteções Implementadas
- ✅ Senhas com hash bcrypt (salt 10)
- ✅ Validação de CPF/CNPJ
- ✅ Validação de email e telefone
- ✅ Proteção contra SQL Injection (prepared statements)
- ✅ Logs de auditoria
- ✅ Verificação de permissões
- ✅ Tokens com expiração
- ✅ CORS configurado

---

# 📊 FORMATO DE RESPOSTAS

## Sucesso
```json
{
  "success": true,
  "message": "Mensagem de sucesso",
  "data": { ... },
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

## Erro
```json
{
  "success": false,
  "message": "Mensagem de erro",
  "errors": ["Detalhes do erro"],
  "timestamp": "2024-01-15T10:30:00.000Z"
}
```

---

**Sistema 100% completo com 81 APIs funcionais!**  
**Todas as respostas padronizadas e com tratamento de erros!**  
**Pronto para produção!** 🚀
